"""
This module defines MOM6-style supergrid classes and associated utilities. It sits underneath the mom6_forge.grid class and fills the roll of calculating the grid geometry: angle_dx, area, dx, dy, x, and y.

Classes defined here:
- SupergridBase: Base class defining the MOM6-style supergrid interface.
- UniformSphericalSupergrid: MOM6-style supergrid with constant-degree spacing (lon/lat grid).
- RectilinearCartesianSupergrid: MOM6-style supergrid with (as close to) uniform Cartesian spacing (still a lat/lon grid).
- ProjectedSupergrid: MOM6-style supergrid built from a pyproj map projection. Use this
  for polar domains (e.g., EPSG:3995/3031) or rotated regional grids (e.g., estuary-aligned).

The code for these classes does not originally come from mom6_forge, but was adapted: UniformSphericalSupergrid by Mathew Harrison in MIDAS (https://github.com/mjharriso/MIDAS) and RectilinearCartesianSupergrid by Ashley Barnes in regional_mom6 (https://github.com/COSIMA/regional-mom6).
"""

import numpy as np
import xarray as xr
from datetime import datetime
from typing import Optional

_DEFAULT_RADIUS = 6.371e6  # mean radius of the Earth (IUGG), in metres
from pyproj import CRS, Transformer
from mom6_forge.utils import normalize_deg, is_mesh_cyclic_x, get_mesh_dimensions


def _max_adjacent_diff(x):
    """Largest abs diff between adjacent values of a 2D array (detects dateline jumps)."""
    max_diff = 0.0
    if x.shape[1] > 1:
        max_diff = max(max_diff, np.abs(np.diff(x, axis=1)).max())
    if x.shape[0] > 1:
        max_diff = max(max_diff, np.abs(np.diff(x, axis=0)).max())
    return max_diff


class SupergridBase:
    """Base class defining the MOM6-style supergrid interface."""

    @property
    def is_cyclic_x(self):
        return np.allclose(
            normalize_deg(self.x[:, 0]),
            normalize_deg(self.x[:, -1]),
            rtol=1e-5,
        )

    @property
    def is_tripolar(self):
        return SupergridBase.x_is_tripolar(self.x)

    @staticmethod
    def x_is_tripolar(x) -> bool:
        """Return whether an ``x`` coordinate array is that of a tripolar grid.

        A tripolar grid's top row runs along the seam joining its two poles, so
        the longitude there holds steady over three stretches of the row. ``x``
        can come from a supergrid or straight from an hgrid dataset.
        """

        x = np.asarray(x)
        same_as_next = x[-1, :-1] == x[-1, 1:]
        # count the stretches, i.e. the places where one starts
        starts = same_as_next.copy()
        starts[1:] &= ~same_as_next[:-1]
        return int(np.count_nonzero(starts)) == 3

    @property
    def lenx(self):
        return self.x.max() - self.x.min()

    @property
    def leny(self):
        return self.y.max() - self.y.min()

    def __init__(
        self,
        x,
        y,
        dx,
        dy,
        area,
        angle_dx,
        axis_units,
        grid_type,
        R=_DEFAULT_RADIUS,
        dx_dy_calc_type="smallangle",
    ):
        """
        Initialize a generic supergrid.

        Parameters
        ----------
        x, y : 2D arrays
            Grid point longitudes and latitudes (or x/y positions).
        dx, dy : 2D arrays
            Cell widths in x and y directions.
        area : 2D array
            Grid cell areas.
        angle : 2D array
            Local grid angle relative to east.
        axis_units : str
            Units of x and y (e.g. "degrees" or "meters").
        grid_type : str
            the type of grid being created
        R : float, optional
            Sphere radius in metres the metrics were computed with.
        dx_dy_calc_type : str, optional
            The method dx/dy were computed with (smallangle or haversine).

        ``R`` and ``dx_dy_calc_type`` describe how the metrics passed in were
        produced, so that expand() can rebuild them the same way. ``to_ds``
        records both, so a grid round-tripped through a dataset keeps them; a
        dataset written before they were recorded falls back to the defaults.
        """
        self.x = x
        self.y = y
        self.dx = dx
        self.dy = dy
        self.area = area
        self.angle_dx = angle_dx
        self.axis_units = axis_units
        self.grid_type = grid_type
        self._R = R
        self._dx_dy_calc_type = dx_dy_calc_type

    def __eq__(self, other):
        if not isinstance(other, SupergridBase):
            return NotImplemented
        return (self.x == other.x).all() and (self.y == other.y).all()

    @staticmethod
    def _calc_dx_dy(x, y, R=_DEFAULT_RADIUS, type="smallangle"):
        """Compute supergrid dx and dy from coordinate arrays.

        Parameters
        ----------
        x, y : 2D arrays
            Supergrid longitude and latitude in degrees, shape (2*ny+1, 2*nx+1).
        R : float, optional
            Sphere radius in metres. Defaults to Earth's IUGG mean radius.
        type: str, optional
            The method to use to calculate dx and dy (smallangle or haversine)


        Returns
        -------
        dx : 2D array, shape (2*ny+1, 2*nx)
            Arc lengths between horizontally adjacent nodes, in metres.
        dy : 2D array, shape (2*ny, 2*nx+1)
            Arc lengths between vertically adjacent nodes, in metres.
        """
        if type == "smallangle":
            # Use small angle approximation for dx, which is faster to compute and not much different
            dx = R * np.cos(np.deg2rad(y[:, :-1])) * np.deg2rad(np.diff(x, axis=1))
            dy = R * np.deg2rad(np.diff(y, axis=0))
        elif type == "haversine":
            dx = haversine(y[:, :-1], x[:, :-1], y[:, 1:], x[:, 1:], R)
            dy = haversine(y[:-1, :], x[:-1, :], y[1:, :], x[1:, :], R)
        else:
            raise ValueError(f"Unrecognized dx/dy calc type: {type}")
        return dx, dy

    @staticmethod
    def _check_edge_midpoints(x, y, R=_DEFAULT_RADIUS, tolerance=3.0):
        """Raise if supergrid edge midpoints are grossly off the edges they halve.

        A supergrid's u/v points sit partway along a cell edge, so walking from
        one corner to the midpoint and on to the next corner should not be far
        longer than going straight between the corners. By the triangle
        inequality the two legs are never shorter; a midpoint flung off the edge
        makes them very much longer. Recovering midpoints by averaging longitude
        and latitude does exactly that where an edge crosses a pole, since the
        average of two longitudes on opposite sides lands halfway around the
        world instead of at the pole.

        The legs are measured here with haversine rather than taken from dx/dy,
        so the ratio reflects only where the midpoint sits. Reading them from a
        smallangle dx would fold in the convention as well: the same tx2_3v3
        grid measures 1.03 with haversine legs and 6.14 with smallangle ones.

        This only catches gross failures, and deliberately so. Measured with
        haversine legs, lat/lon meshes sit at 1.00-1.01 and the tripolar
        tx2_3v3 and tx0.66v1 at 1.03-1.05, but the gx1v6 displaced-pole grid
        reaches 1.12 in x and 1.56 in y purely from the curvature of its cells
        near the displaced pole. A polar-cap mesh averaged across the pole
        reaches 40. Since a legitimate 1.56 outranks that broken mesh's own x
        ratio of 1.24, no threshold separates the two in x; the tolerance is set
        to clear the curviest real grid with room to spare and still catch a
        midpoint thrown to the far side of the globe.
        """
        qlon, qlat = x[::2, ::2], y[::2, ::2]
        vlon, vlat = x[::2, 1::2], y[::2, 1::2]
        ulon, ulat = x[1::2, ::2], y[1::2, ::2]

        checks = (
            (
                "x",
                haversine(qlat[:, :-1], qlon[:, :-1], vlat, vlon, R)
                + haversine(vlat, vlon, qlat[:, 1:], qlon[:, 1:], R),
                haversine(qlat[:, :-1], qlon[:, :-1], qlat[:, 1:], qlon[:, 1:], R),
            ),
            (
                "y",
                haversine(qlat[:-1, :], qlon[:-1, :], ulat, ulon, R)
                + haversine(ulat, ulon, qlat[1:, :], qlon[1:, :], R),
                haversine(qlat[:-1, :], qlon[:-1, :], qlat[1:, :], qlon[1:, :], R),
            ),
        )
        for axis, legs, direct in checks:
            usable = direct > 0.0
            if not np.any(usable):
                continue
            ratio = np.where(usable, legs / np.where(usable, direct, 1.0), 1.0)
            worst = float(np.nanmax(ratio))
            if worst > tolerance:
                j, i = np.unravel_index(int(np.nanargmax(ratio)), ratio.shape)
                raise ValueError(
                    f"Supergrid {axis} edge midpoints are not on their edges: at "
                    f"corner ({j}, {i}) the two half-edges total {worst:.1f} times "
                    "the direct corner-to-corner distance. This usually means the "
                    "midpoints were recovered by averaging longitude and latitude "
                    "across a pole, which the resulting dx/dy and area would "
                    "silently carry."
                )

    @staticmethod
    def _calc_dx_dy_checked(x, y, R=_DEFAULT_RADIUS, type="smallangle"):
        """Compute dx/dy, falling back to haversine if smallangle breaks down.

        smallangle differences adjacent longitudes and latitudes, which is only
        valid while the grid lines follow parallels and meridians. A curvilinear
        grid crossing a pole breaks that: y stops varying monotonically with row
        index, so np.diff(y) flips sign and the metrics come out negative.

        Negative metrics are the direct symptom, so testing for them keys off
        the geometry rather than a proxy for it. Latitude is the wrong trigger
        in both directions: it would convert a rectilinear grid merely touching
        a pole, where smallangle is exactly MOM6's along-parallel convention,
        and it would miss a curvilinear grid that encircles a pole while all of
        its nodes stay below the threshold.

        Returns
        -------
        dx, dy : 2D arrays
        type : str
            The method actually used, for the caller to record.
        """
        dx, dy = SupergridBase._calc_dx_dy(x, y, R=R, type=type)
        if type == "smallangle" and (np.nanmin(dx) < 0.0 or np.nanmin(dy) < 0.0):
            type = "haversine"
            dx, dy = SupergridBase._calc_dx_dy(x, y, R=R, type=type)
        return dx, dy, type

    @staticmethod
    def _calc_area(x, y, R=_DEFAULT_RADIUS):
        """Compute supergrid cell areas from coordinate arrays.

        Parameters
        ----------
        x, y : 2D arrays
            Supergrid longitude and latitude in degrees, shape (2*ny+1, 2*nx+1).
        R : float, optional
            Sphere radius in metres. Defaults to Earth's IUGG mean radius.

        Returns
        -------
        area : 2D array, shape (2*ny, 2*nx)
            Cell areas in square metres.
        """
        return quadrilateral_areas(y, x, R)

    @classmethod
    def _init_from_xy(
        cls,
        x,
        y,
        grid_type=None,
        R=_DEFAULT_RADIUS,
        angles_are_zero=False,
        dx_dy_calc_type="smallangle",
    ):
        """Build supergrid metrics from y/x arrays. Should not really be called directly by users (unless experienced); use from_* method instead

        Parameters
        ----------
        x, y : np.ndarray, shape (2*ny+1, 2*nx+1)
            Geographic coordinates of all supergrid nodes in degrees.
        grid_type : str
            The type of grid being created
        radius : float, optional
            Sphere radius in metres. Defaults to Earth's IUGG mean radius.
        angles_are_zero: bool, optional
            Angle calculation is an approximation for regional grids.
            If angles are known to be zero, we can skip angle calculation (which may be slighly off from zero)
            and set angles to zero
        dx_dy_calc_type: str, optional
            The method to use to calculate dx and dy (smallangle or haversine)
        """
        # Clamp to valid geographic range (floating-point overshoot from projection in some cases)
        y = np.clip(y, -90.0, 90.0)

        # Fix raw dateline-wrap discontinuities in x before differencing for dx/dy/area/angle.
        center_lon = x[x.shape[0] // 2, x.shape[1] // 2]
        if _max_adjacent_diff(x) > 180.0:
            repaired = modulo_around_point(x, center_lon, 360)
            # Re-centering can leave the grid a whole turn away from the
            # convention its center was written in, so shift it back. Both
            # lines stay inside the seam test: a grid with no seam keeps the
            # exact longitude convention it was handed.
            repaired = repaired - np.floor(center_lon / 360) * 360
            # A domain that encircles a pole spans all 360 degrees of
            # longitude, so no 360-wide window can remove its seam:
            # re-centering only moves the seam elsewhere, while pushing x out
            # of range and scrambling angle_dx across the new seam. Checking
            # the result is what rules that out -- and it rules it out for any
            # geometry, so the repair needs no latitude guard in front of it.
            # A guard there would only make the outcome depend on whether the
            # caller stored a pole-adjacent grid in [0, 360) or [-180, 180].
            if _max_adjacent_diff(repaired) <= 180.0:
                x = repaired

        # dx, dy, area: use base class consistent calculation methods
        dx, dy, dx_dy_calc_type = SupergridBase._calc_dx_dy_checked(
            x, y, R=R, type=dx_dy_calc_type
        )
        area = SupergridBase._calc_area(x, y, R=R)

        if angles_are_zero:
            angle_dx = np.zeros_like(x)
        else:
            angle_dx = SupergridBase.calc_supergrid_rotation_angles_using_expanded_supergrid_method(
                x, y
            )
        return cls(
            x,
            y,
            dx,
            dy,
            area,
            angle_dx,
            "degrees",
            grid_type=grid_type,
            R=R,
            dx_dy_calc_type=dx_dy_calc_type,
        )

    def summary(self):
        """Print a short summary of the grid geometry (shape and dx/dy ranges)."""
        print(
            f"{self.__class__.__name__}: shape={self.x.shape}, "
            f"dx=({self.dx.min()}–{self.dx.max()}), "
            f"dy=({self.dy.min()}–{self.dy.max()})"
        )

    def to_ds(self, name=None, author: Optional[str] = None) -> xr.Dataset:
        """
        Export the supergrid to an xarray.Dataset compatible with MOM6.

        Parameters
        ----------
        author : str, optional
            If provided, stored as metadata in the output dataset.
        """
        ds = xr.Dataset()

        # ---- Metadata ----
        ds.attrs["type"] = "MOM6 supergrid"
        if self.grid_type is not None:
            ds.attrs["grid_type"] = self.grid_type
        if name is not None:
            ds.attrs["name"] = name
        ds.attrs["Created"] = datetime.now().isoformat()
        if author:
            ds.attrs["Author"] = author
        # Record how the metrics below were produced, so that a grid reloaded
        # with from_ds can rebuild them the same way (see expand()).
        ds.attrs["radius"] = self._R
        ds.attrs["dx_dy_calc_type"] = self._dx_dy_calc_type

        # ---- Data variables ----
        ds["y"] = xr.DataArray(
            self.y, dims=["nyp", "nxp"], attrs={"units": self.axis_units}
        )
        ds["x"] = xr.DataArray(
            self.x, dims=["nyp", "nxp"], attrs={"units": self.axis_units}
        )
        ds["dy"] = xr.DataArray(self.dy, dims=["ny", "nxp"], attrs={"units": "meters"})
        ds["dx"] = xr.DataArray(self.dx, dims=["nyp", "nx"], attrs={"units": "meters"})
        ds["area"] = xr.DataArray(self.area, dims=["ny", "nx"], attrs={"units": "m2"})
        ds["angle_dx"] = xr.DataArray(
            self.angle_dx, dims=["nyp", "nxp"], attrs={"units": "radians"}
        )

        return ds

    @staticmethod
    def _collapse_pole_node_rows(
        node_coords, element_conn, node_row_width, start_index=1, tol=1e-10
    ):
        """Collapse a full coincident pole node row into a single shared node.

        When a logically-rectangular lat-lon grid reaches a geographic pole, the
        first (south) or last (north) node row consists of nodes that are
        geometrically the same point (lat = -90 or +90) but carry distinct
        longitudes. ESMF treats these as separate coincident nodes, which defeats
        its pole-aware regridding (e.g. POLEMETHOD_ALLAVG). This helper merges such
        a row into one shared node and remaps the element connectivity accordingly.
        Affected cells keep four connectivity entries (degenerate quads with a
        repeated apex), so ``numElementConn`` stays 4.

        Parameters
        ----------
        node_coords : np.ndarray, shape (nnodes, 2)
            Node (lon, lat) coordinates in degrees, row-major (south row first).
        element_conn : np.ndarray, shape (ncells, maxNodePElement)
            Element connectivity using ``start_index``-based node ids.
        node_row_width : int
            Number of nodes per logical row (``nx`` for cyclic, ``nx+1`` otherwise).
        start_index : int, optional
            Base index of ``element_conn`` (1 for ESMF meshes). Default 1.
        tol : float, optional
            Absolute tolerance (degrees) for detecting nodes at a pole. Default 1e-10.

        Returns
        -------
        new_node_coords : np.ndarray
            Node table with the redundant pole-row nodes removed.
        new_element_conn : np.ndarray
            Connectivity remapped onto ``new_node_coords`` (same dtype/start_index).
        collapsed : list of (str, int)
            One ``(pole_name, n_merged)`` entry per pole that was collapsed; empty
            if neither edge row lies on a pole (i.e. this was a no-op).
        """

        lat = node_coords[:, 1]
        nnodes = node_coords.shape[0]
        remap = np.arange(nnodes)  # old idx -> representative old idx
        keep = np.ones(nnodes, dtype=bool)
        collapsed = []

        south_row = np.arange(0, node_row_width)
        north_row = np.arange(nnodes - node_row_width, nnodes)
        for row, pole_val, name in (
            (south_row, -90.0, "south"),
            (north_row, 90.0, "north"),
        ):
            # Only collapse when the *whole* edge row sits on the pole.
            if row.size > 1 and np.all(
                np.isclose(lat[row], pole_val, rtol=0, atol=tol)
            ):
                rep = row[0]  # keep the first node of the fan
                remap[row] = rep
                keep[row[1:]] = False
                collapsed.append((name, int(row.size)))

        if not collapsed:
            return node_coords, element_conn, []

        # Compact the kept nodes and build an old->new index map.
        old_to_new = np.cumsum(keep) - 1  # new 0-based index for kept nodes
        final_old_to_new = old_to_new[remap]  # collapsed nodes -> their rep's new index

        new_node_coords = node_coords[keep]
        conn0 = element_conn - start_index
        new_element_conn = (final_old_to_new[conn0] + start_index).astype(
            element_conn.dtype
        )

        return new_node_coords, new_element_conn, collapsed

    @staticmethod
    def _wrap_column(qlon_inner):
        """The cyclic wrap column: column 0 on the branch that continues the row.

        The wrap node is the same point on the sphere as column 0, so it differs
        from it by a whole number of turns. Which one depends on the row: a row
        that sweeps the globe west to east arrives one turn east of where it
        started, but a row curling around a displaced pole -- gx1v6's top 18
        rows -- ends up back where it began. Adding 360 unconditionally puts
        those nodes a turn away (680 instead of 320 on gx1v6), and the edge
        midpoints interpolated against them land off the globe.
        """
        step = qlon_inner[:, -1] - qlon_inner[:, -2]
        target = qlon_inner[:, -1] + step
        turns = np.round((target - qlon_inner[:, 0]) / 360.0)
        return (qlon_inner[:, 0] + 360.0 * turns)[:, np.newaxis]

    @staticmethod
    def _unwrap_lon_rows(qlon):
        """Remove the [0, 360) branch cut from each row of a q-longitude array.

        ESMF mesh files normalize node longitudes to [0, 360), which puts a
        discontinuity inside the row whenever the grid's first node column does
        not sit on the prime meridian -- the ERA5 N640 mesh, for instance, starts
        at 359.859375 and jumps to 0.140625 in the next column. Such a row cannot
        be used as a supergrid coordinate: the edge midpoints interpolated from it
        in :meth:`reconstruct_from_esmf_mesh` land on the far side of the globe,
        which corrupts the metrics (dx, dy, area) of the cells straddling the cut
        and can even make their areas negative.

        Adding whole multiples of 360 to the offending entries makes each row
        monotonic again without moving any point on the sphere. Rows that are
        already free of a cut are returned bit-for-bit unchanged, so this is a
        no-op for grids whose node longitudes start at (or near) zero.

        Parameters
        ----------
        qlon : np.ndarray, shape (nrows, ncols)
            Node longitudes in degrees, one logical node row per row.

        Returns
        -------
        np.ndarray
            ``qlon`` with each row made monotonically increasing.
        """

        unwrapped = np.unwrap(qlon, period=360.0, axis=-1)
        # np.unwrap pins the first entry and lifts the rest, which would leave a
        # row that merely started late (ERA5's 359.859375) sitting almost a full
        # turn high. Drop the array back onto the branch it arrived on so the
        # reconstructed grid keeps the input's longitude range.
        #
        # The shift is one turn count for the whole array, not one per row. A
        # per-row count lands neighbouring rows on different branches wherever
        # the in-row cut sits at different columns -- on gx1v6 rows 0-366 come
        # back a turn below rows 367-384 -- and the u-points averaged between
        # two such rows land half a world away.
        # Take the branch most rows arrived on. A median would do for a lopsided
        # split, but it is not one of the turn counts when an even number of
        # rows splits evenly between two of them -- it returns 0.5, and the
        # array shifts by half a turn, which is the cross-branch corruption this
        # is here to prevent. The mode is always one of the counts.
        per_row = np.round((unwrapped.mean(axis=-1) - qlon.mean(axis=-1)) / 360.0)
        values, counts = np.unique(per_row, return_counts=True)
        turns = values[np.argmax(counts)]
        return unwrapped - 360.0 * turns

    @staticmethod
    def _expand_pole_node_rows(
        node_lon, node_lat, node_row_width, n_node_rows, tol=1e-10
    ):
        """Re-expand a collapsed pole node into a full row of nodes.

        Partial inverse of :meth:`_collapse_pole_node_rows` for the node table,
        used when reading a mesh back: it restores the rectangular
        ``(n_node_rows, node_row_width)`` node layout that the reshape logic in
        :meth:`reconstruct_from_esmf_mesh` requires. Longitudes for the restored
        row are taken from the adjacent interior node row -- each column of a
        logically-rectangular lat-lon grid shares one longitude, so this recovers
        the original values exactly for such grids.

        Parameters
        ----------
        node_lon, node_lat : np.ndarray, shape (nnodes,)
            Flattened node longitudes and latitudes, row-major (south row first).
        node_row_width : int
            Number of nodes per logical row (``nx`` for cyclic, ``nx+1`` otherwise).
        n_node_rows : int
            Number of logical node rows in the uncollapsed table (``ny+1``).
        tol : float, optional
            Absolute tolerance (degrees) for detecting nodes at a pole. Default 1e-10.

        Returns
        -------
        node_lon, node_lat : np.ndarray
            Node arrays with any collapsed pole row restored.
        expanded : list of str
            Names of the poles that were expanded; empty if this was a no-op.
        """

        w = node_row_width
        expanded = []
        if w <= 1:
            return node_lon, node_lat, expanded

        # Number of collapsed pole rows, from the node count alone.
        missing = w * n_node_rows - node_lat.size
        if missing <= 0 or missing % (w - 1) != 0:
            return node_lon, node_lat, expanded
        n_collapsed = missing // (w - 1)
        if n_collapsed > 2:
            return node_lon, node_lat, expanded

        def _is_apex(i, j):
            # Node i sits on a pole and its neighbour j in the adjacent row does
            # not share its latitude, i.e. node i is a collapsed fan's apex.
            return np.isclose(
                abs(node_lat[i]), 90.0, rtol=0, atol=tol
            ) and not np.isclose(node_lat[j], node_lat[i], rtol=0, atol=tol)

        # South pole: the apex is node 0, with the interior row right after it.
        # North pole: the apex is the final node, with the interior row before it.
        at_south = node_lat.size > w and _is_apex(0, 1)
        at_north = node_lat.size > w and _is_apex(-1, -2)
        if int(at_south) + int(at_north) != n_collapsed:
            return node_lon, node_lat, expanded

        if at_south:
            apex_lat = node_lat[0]
            lon_row = node_lon[1 : 1 + w]  # interior row above the apex
            node_lon = np.concatenate([lon_row, node_lon[1:]])
            node_lat = np.concatenate([np.full(w, apex_lat), node_lat[1:]])
            expanded.append("south")

        if at_north:
            apex_lat = node_lat[-1]
            lon_row = node_lon[-1 - w : -1]  # interior row below the apex
            node_lon = np.concatenate([node_lon[:-1], lon_row])
            node_lat = np.concatenate([node_lat[:-1], np.full(w, apex_lat)])
            expanded.append("north")

        return node_lon, node_lat, expanded

    def to_esmf_mesh(self, file_path, mask, title=None):
        """
        Write the supergrid as an ESMF mesh file.

        Parameters
        ----------
        file_path : str
            Path to write the ESMF mesh NetCDF file.
        mask : 2D array or "all_unmasked"
            Element mask in MOM6/ESMF convention (1=ocean/unmasked, 0=land/masked).
            Pass the literal string "all_unmasked" to write a mask of all ones.
        title : str, optional
            Optional title global attribute.
        """

        # --- Pull corner and center points from supergrid ---
        # Supergrid layout: corners at even indices, centers at odd indices
        # qlon has shape (ny+1, nx+1); for cyclic grids the last column is the wrap-around
        qlon = self.x[::2, ::2]
        qlat = self.y[::2, ::2]
        tlon = self.x[1::2, 1::2]  # shape (ny, nx)
        tlat = self.y[1::2, 1::2]

        ny, nx = tlon.shape
        ncells = ny * nx

        # --- Element area: sum the 4 supergrid sub-cells that make each MOM6 cell ---
        # self.area has shape (2*ny, 2*nx); sub-cells are at even pairs
        sub_area = self.area.reshape(ny, 2, nx, 2)
        tarea = sub_area.sum(axis=(1, 3))  # shape (ny, nx)

        # --- Node coordinates ---
        # Flatten corner arrays. Handle cyclic x: ESMF needs the wrap-around
        # column dropped since connectivity encodes the periodicity.

        # --- Element connectivity (1-based) ---
        i0 = 1  # ESMF start index

        # Width of a logical node row, set per branch. Left None for the tripolar
        # branch to disable the pole-row collapse (its folded north seam has bespoke
        # connectivity that must not be touched); the other branches set it.
        pole_node_row_width = None

        if self.is_tripolar:
            # Tripolar fold: top row of nodes is collapsed — the second half
            # of the top row folds back, so we drop the redundant nodes.
            qlon_flat = qlon[:, :-1].flatten()[: -(nx // 2 - 1)]
            qlat_flat = qlat[:, :-1].flatten()[: -(nx // 2 - 1)]
            nnodes = len(qlon_flat)
            assert nnodes + (nx // 2 - 1) == nx * (ny + 1)

            def get_element_conn(i):
                is_final_column = (i + 1) % nx == 0
                on_top_row = i // nx == ny - 1
                on_second_half_of_stitch = on_top_row and (i % nx) >= nx // 2

                ll = i0 + i % nx + (i // nx) * nx

                lr = ll + 1
                if is_final_column:
                    lr -= nx

                ur = lr + nx
                if on_second_half_of_stitch and not is_final_column:
                    ur -= 2 * (i % nx + 1 - nx // 2)

                ul = ll + nx
                if on_second_half_of_stitch:
                    ul = ur + 1

                return [ll, lr, ur, ul]

        elif self.is_cyclic_x:
            # Wrap-around: last column of elements connects back to column 0
            qlon_flat = (
                qlon[:, :-1].flatten() if qlon.shape[1] == nx + 1 else qlon.flatten()
            )
            qlat_flat = (
                qlat[:, :-1].flatten() if qlat.shape[1] == nx + 1 else qlat.flatten()
            )
            nnodes = len(qlon_flat)
            pole_node_row_width = nx

            def get_element_conn(i):
                row, col = divmod(i, nx)
                ll = i0 + col + row * nx
                lr = i0 + (col + 1) % nx + row * nx
                ur = i0 + (col + 1) % nx + (row + 1) * nx
                ul = i0 + col + (row + 1) * nx
                return [ll, lr, ur, ul]

        else:
            qlon_flat = qlon.flatten()
            qlat_flat = qlat.flatten()
            nnodes = len(qlon_flat)
            pole_node_row_width = nx + 1

            def get_element_conn(i):
                row, col = divmod(i, nx)
                ll = i0 + col + row * (nx + 1)
                lr = i0 + col + 1 + row * (nx + 1)
                ur = i0 + col + 1 + (row + 1) * (nx + 1)
                ul = i0 + col + (row + 1) * (nx + 1)
                return [ll, lr, ur, ul]

        node_coords = np.column_stack((qlon_flat, qlat_flat))
        element_conn = np.array(
            [get_element_conn(i) for i in range(ncells)], dtype=np.int32
        )

        # Collapse a pole-coincident edge node row into a single shared node (needed
        # by ESMF for pole-aware regridding). A no-op unless a full edge row lies on
        # a pole; skipped entirely for tripolar grids (width is None).
        collapsed = []
        if pole_node_row_width is not None:
            node_coords, element_conn, collapsed = self._collapse_pole_node_rows(
                node_coords, element_conn, pole_node_row_width, start_index=i0
            )
            for name, n_merged in collapsed:
                print(
                    f"Collapsed {n_merged} coincident {name}-pole nodes into a "
                    "single shared node (for ESMF pole detection)."
                )

        # --- Build dataset ---
        ds = xr.Dataset()

        ds.attrs["gridType"] = "unstructured mesh"
        ds.attrs["date_created"] = datetime.now().isoformat()
        ds.attrs["grid_topology"] = (
            "tripolar"
            if self.is_tripolar
            else "cyclic" if self.is_cyclic_x else "non_cyclic"
        )
        if title:
            ds.attrs["title"] = title
        if collapsed:
            ds.attrs["history"] = (
                f"{datetime.now().isoformat()}: collapsed pole node rows to "
                "a single node per pole for ESMF pole detection"
            )

        ds["nodeCoords"] = xr.DataArray(
            node_coords,
            dims=["nodeCount", "coordDim"],
            attrs={"units": self.axis_units},
        )

        ds["centerCoords"] = xr.DataArray(
            np.column_stack((tlon.flatten(), tlat.flatten())),
            dims=["elementCount", "coordDim"],
            attrs={"units": self.axis_units},
        )

        ds["numElementConn"] = xr.DataArray(
            np.full(ncells, 4, dtype=np.int8),
            dims=["elementCount"],
            attrs={"long_name": "Number of nodes per element"},
        )

        ds["elementConn"] = xr.DataArray(
            element_conn,
            dims=["elementCount", "maxNodePElement"],
            attrs={
                "long_name": "Node indices that define the element connectivity",
                "start_index": np.int32(i0),
            },
        )

        ds["elementArea"] = xr.DataArray(
            tarea.flatten(),
            dims=["elementCount"],
            attrs={"units": "m2"},
        )

        if isinstance(mask, str) and mask == "all_unmasked":
            esmf_mask = np.ones((ny, nx), dtype=np.int32)
        else:
            esmf_mask = np.asarray(mask).astype(np.int32)
        ds["elementMask"] = xr.DataArray(
            esmf_mask.flatten(),
            dims=["elementCount"],
        )

        all_vars_encoding = {
            var: {"_FillValue": None} for var in ds.data_vars
        }  # disable _FillValue for all variables to avoid issues in ESMF

        ds.to_netcdf(file_path, format="NETCDF3_64BIT", encoding=all_vars_encoding)
        return ds

    @classmethod
    def reconstruct_from_esmf_mesh(
        cls, file_path, radius=_DEFAULT_RADIUS, return_mask=False
    ):
        """
        Approximate a SupergridBase from an ESMF mesh file.

        .. warning::
            This is **not** a lossless round-trip. The ESMF mesh format stores only
            corner (q) points and cell-center (t) points. Edge midpoints (u/v-points)
            are re-derived here by linear interpolation of adjacent corners, so the
            reconstructed supergrid will differ from the original for any non-uniform
            grid. Metrics (dx, dy, area, angle_dx) are also recomputed from the
            recovered coordinates rather than read from file. If you need the exact
            original supergrid, load it from the source supergrid NetCDF file.

        Parameters
        ----------
        file_path : str or xr.Dataset
            Path to an ESMF mesh NetCDF file written by to_esmf_mesh(), or an already-opened Dataset.
        radius : float, optional
            Sphere radius in metres used for metric calculations.
        return_mask : bool, optional
            If True, also return the element mask as a 2D numpy array in MOM6 convention
            (1=ocean/unmasked, 0=land/masked). Raises ValueError if the mesh has no elementMask.
            Default False.

        Returns
        -------
        SupergridBase or tuple(SupergridBase, np.ndarray)
            Approximate supergrid with q-points and t-points recovered exactly,
            u/v-points linearly interpolated, and metrics recomputed. If return_mask=True,
            returns (supergrid, mask).
        """

        if isinstance(file_path, xr.Dataset):
            ds = file_path
        else:
            ds = xr.open_dataset(file_path)

        topology = ds.attrs.get("grid_topology", None)
        is_cyclic = is_mesh_cyclic_x(ds)
        nx, ny = get_mesh_dimensions(ds)

        # to_esmf_mesh records the topology, but meshes written by other tools (the
        # CESM tx2_3v3 mesh, for one) carry no such attribute. Read it off the node
        # count instead of assuming a plain lat-lon layout.
        inferred_topology = topology is None
        if inferred_topology:
            n_nodes = ds["nodeCoords"].shape[0]
            if not is_cyclic:
                topology = "non_cyclic"
            elif nx >= 2 and n_nodes == nx * (ny + 1) - (nx // 2 - 1):
                topology = "tripolar"
            else:
                topology = "cyclic"

        # --- Recover corner (q) points from nodeCoords ---
        node_lon = ds["nodeCoords"].values[:, 0]
        node_lat = ds["nodeCoords"].values[:, 1]
        axis_units = ds["nodeCoords"].attrs.get("units", "degrees")

        if topology != "tripolar":
            # to_esmf_mesh() collapses a pole-coincident edge node row to a single
            # shared node; restore the full row so the reshapes below line up.
            node_lon, node_lat, _ = cls._expand_pole_node_rows(
                node_lon, node_lat, nx if is_cyclic else nx + 1, ny + 1
            )

        if topology == "tripolar":
            # Nodes stored without wrap column and with fold duplicates removed.
            # Rows 0..ny-1 have nx nodes each; top row has nx//2+1 nodes stored
            # (the fold point is a mirror line, so the nodes past nx//2 are exact
            # duplicates of the nodes before it and were dropped).
            # Recover the missing nx//2-1 nodes by mirroring: qlon[ny, nx//2+j] = qlon[ny, nx//2-j],
            # adding 360 where needed so the row stays monotonically increasing.
            rows_except_top_lon = node_lon[: ny * nx].reshape(ny, nx)
            rows_except_top_lat = node_lat[: ny * nx].reshape(ny, nx)
            top_stored_lon = node_lon[ny * nx :]  # length nx//2 + 1
            top_stored_lat = node_lat[ny * nx :]

            top_full_lon = np.empty(nx)
            top_full_lat = np.empty(nx)
            top_full_lon[: nx // 2 + 1] = top_stored_lon
            top_full_lat[: nx // 2 + 1] = top_stored_lat
            # Fold: right-half values mirror the left half reversed.
            # Values below the fold-point longitude need +360 to stay on the
            # upper branch and preserve the monotone-increasing top row.
            fold_lon = top_stored_lon[nx // 2]
            mirrors = top_stored_lon[nx // 2 - 1 : 0 : -1]  # reversed, length nx//2-1
            top_full_lon[nx // 2 + 1 :] = np.where(
                mirrors < fold_lon, mirrors + 360.0, mirrors
            )
            top_full_lat[nx // 2 + 1 :] = top_stored_lat[nx // 2 - 1 : 0 : -1]

            qlon_inner = cls._unwrap_lon_rows(
                np.vstack([rows_except_top_lon, top_full_lon[np.newaxis, :]])
            )
            qlat_inner = np.vstack([rows_except_top_lat, top_full_lat[np.newaxis, :]])
            # Tripolar grids are periodic in x — add wrap column
            qlon = np.hstack([qlon_inner, cls._wrap_column(qlon_inner)])
            qlat = np.hstack([qlat_inner, qlat_inner[:, :1]])
        elif is_cyclic:
            # nodes stored without wrap column; add it back by repeating column 0
            qlon_inner = cls._unwrap_lon_rows(node_lon.reshape(ny + 1, nx))
            qlat_inner = node_lat.reshape(ny + 1, nx)
            qlon = np.hstack([qlon_inner, cls._wrap_column(qlon_inner)])
            qlat = np.hstack([qlat_inner, qlat_inner[:, :1]])
        else:
            qlon = cls._unwrap_lon_rows(node_lon.reshape(ny + 1, nx + 1))
            qlat = node_lat.reshape(ny + 1, nx + 1)

        if return_mask:
            if "elementMask" not in ds:
                raise ValueError(
                    "return_mask=True but no elementMask variable found in dataset"
                )
            mask = ds["elementMask"].values.reshape(ny, nx)

        # --- Recover center (t) points from centerCoords ---
        tlon = ds["centerCoords"].values[:, 0].reshape(ny, nx)
        tlat = ds["centerCoords"].values[:, 1].reshape(ny, nx)

        # Centers are stored normalized to [0, 360) just like the nodes, so shift
        # each one into the same 360-degree branch as its own four corners (which
        # _unwrap_lon_rows may have moved). Without this the supergrid mixes
        # branches, and the degree differences behind dx come out ~360 too large.
        # A no-op wherever a center already agrees with its corners.
        # Halfway between two longitudes, going the short way round. Averaging
        # them directly assumes both sit on the same 360-degree branch; where
        # they do not -- across a branch cut the node rows could not be
        # unwrapped out of, as on gx1v6 -- the plain average lands half a world
        # from the edge it is meant to halve.
        def _mid_lon(a, b):
            return a + 0.5 * (((b - a) + 180.0) % 360.0 - 180.0)

        def _gc_mid(lon_a, lat_a, lon_b, lat_b):
            """Great-circle midpoint of two points, as (lon, lat) in degrees.

            Averaging longitude and latitude assumes the edge is a straight line
            in the lat/lon plane. It is not: across a branch cut the average
            lands half a world away, and across a pole it lands 90 degrees off
            at a latitude that is nowhere near the pole. Averaging the two unit
            vectors and renormalising gives the point actually halfway along the
            edge, with no branch to get wrong and the pole handled exactly.
            """
            la, lb = np.deg2rad(lat_a), np.deg2rad(lat_b)
            oa, ob = np.deg2rad(lon_a), np.deg2rad(lon_b)
            vx = np.cos(la) * np.cos(oa) + np.cos(lb) * np.cos(ob)
            vy = np.cos(la) * np.sin(oa) + np.cos(lb) * np.sin(ob)
            vz = np.sin(la) + np.sin(lb)
            n = np.sqrt(vx * vx + vy * vy + vz * vz)
            # Antipodal corners have no unique midpoint; fall back to the
            # lat/lon average there rather than dividing by zero.
            degenerate = n < 1e-12
            n = np.where(degenerate, 1.0, n)
            lat = np.rad2deg(np.arcsin(np.clip(vz / n, -1.0, 1.0)))
            lon = np.rad2deg(np.arctan2(vy, vx))
            # Put the result on the same branch as the first corner so the
            # assembled supergrid keeps one longitude convention.
            lon = lon_a + ((lon - lon_a) + 180.0) % 360.0 - 180.0
            lon = np.where(degenerate, _mid_lon(lon_a, lon_b), lon)
            lat = np.where(degenerate, 0.5 * (lat_a + lat_b), lat)
            # Averaging longitude and latitude is exact for the two edges a
            # rectilinear grid is made of: along a parallel (both corners at
            # one latitude, midpoint on that parallel) and along a meridian
            # (both at one longitude, where the great circle IS the meridian).
            # Use it there so such a grid round-trips bit for bit, as it did
            # before, and keep the vector midpoint for genuinely curved edges.
            rectilinear = np.isclose(lat_a, lat_b, rtol=0.0, atol=1e-9) | np.isclose(
                ((lon_b - lon_a) + 180.0) % 360.0 - 180.0, 0.0, rtol=0.0, atol=1e-9
            )
            return (
                np.where(rectilinear, _mid_lon(lon_a, lon_b), lon),
                np.where(rectilinear, 0.5 * (lat_a + lat_b), lat),
            )

        qmid = _mid_lon(
            _mid_lon(qlon[:-1, :-1], qlon[:-1, 1:]),
            _mid_lon(qlon[1:, :-1], qlon[1:, 1:]),
        )
        tlon = tlon + 360.0 * np.round((qmid - tlon) / 360.0)

        # --- Interpolate edge midpoints ---
        # U-points: midpoint of west/east edges (between vertically adjacent corners)
        ulon, ulat = _gc_mid(
            qlon[:-1, :], qlat[:-1, :], qlon[1:, :], qlat[1:, :]
        )  # shape (ny, nx+1)

        # V-points: midpoint of south/north edges (between horizontally adjacent corners)
        vlon, vlat = _gc_mid(
            qlon[:, :-1], qlat[:, :-1], qlon[:, 1:], qlat[:, 1:]
        )  # shape (ny+1, nx)

        # --- Assemble full supergrid (2*ny+1, 2*nx+1) ---
        # Layout:
        #   even rows, even cols -> q points (corners)
        #   even rows, odd  cols -> v points (N/S edge midpoints)
        #   odd  rows, even cols -> u points (E/W edge midpoints)
        #   odd  rows, odd  cols -> t points (centers)
        sny = 2 * ny + 1
        snx = 2 * nx + 1

        x = np.empty((sny, snx))
        y = np.empty((sny, snx))

        x[::2, ::2] = qlon
        x[::2, 1::2] = vlon
        x[1::2, ::2] = ulon
        x[1::2, 1::2] = tlon

        y[::2, ::2] = qlat
        y[::2, 1::2] = vlat
        y[1::2, ::2] = ulat
        y[1::2, 1::2] = tlat

        # --- Recompute metrics ---
        # Use the checked variant: a mesh can describe a polar grid, where the
        # smallangle default yields negative dx/dy. Record what was actually
        # used so that a later expand() or slice rebuilds it the same way.
        dx, dy, dx_dy_calc_type = cls._calc_dx_dy_checked(x, y, R=radius)

        # The u/v points above are averages of the corner longitudes and
        # latitudes, which is wrong wherever an edge crosses a pole. That
        # produces large positive metrics rather than negative ones, so the
        # check above cannot see it; verify the midpoints themselves before
        # handing back numbers that look plausible and are not.
        cls._check_edge_midpoints(x, y, R=radius)
        area = cls._calc_area(x, y, R=radius)
        angle_dx = cls.calc_supergrid_rotation_angles_using_expanded_supergrid_method(
            x, y
        )

        supergrid = cls(
            x,
            y,
            dx,
            dy,
            area,
            angle_dx,
            axis_units,
            grid_type="from_esmf_mesh",
            R=radius,
            dx_dy_calc_type=dx_dy_calc_type,
        )

        if inferred_topology and supergrid.is_tripolar != (topology == "tripolar"):
            raise ValueError(
                f"Inferred a {topology!r} topology from the mesh's node count, but "
                f"the reconstructed supergrid reports is_tripolar="
                f"{supergrid.is_tripolar}. Set a 'grid_topology' global attribute "
                "on the mesh to state the topology explicitly."
            )

        if not return_mask:
            return supergrid
        else:
            return supergrid, mask

    @classmethod
    def from_ds(cls, ds: xr.Dataset) -> "SupergridBase":
        """Load a supergrid from a Dataset written by to_ds, returning a SupergridBase instance.

        Does not dispatch to subclasses
        """
        return cls(
            ds.x.data,
            ds.y.data,
            ds.dx.data,
            ds.dy.data,
            ds.area.data,
            ds.angle_dx.data,
            ds.x.attrs.get("units", "degrees"),
            grid_type=ds.attrs.get("grid_type"),
            R=float(ds.attrs.get("radius", _DEFAULT_RADIUS)),
            dx_dy_calc_type=ds.attrs.get("dx_dy_calc_type", "smallangle"),
        )

    @staticmethod
    def calc_supergrid_rotation_angles_using_expanded_supergrid_method(
        x,
        y,
    ) -> xr.Dataset:
        """
        Calculate the ``angle_dx`` (in degrees) from the true ``x`` direction (parallel to latitude)
        counter-clockwise and return as a dataarray.

        Parameters
        ----------
        supergrid: xr.Dataset
            The supergrid dataset

        Returns
        -------
        xr.DataArray
            The t-point angles
        """
        # Get expanded (pseudo) grid
        expanded_supergrid = SupergridBase._create_expanded_supergrid(x, y)

        point = xr.Dataset(
            {
                "x": (["nyp", "nxp"], x),
                "y": (["nyp", "nxp"], y),
            }
        )
        return mom6_angle_calculation_method(
            expanded_supergrid.x.max() - expanded_supergrid.x.min(),
            expanded_supergrid.isel(nyp=slice(2, None), nxp=slice(0, -2)),
            expanded_supergrid.isel(nyp=slice(2, None), nxp=slice(2, None)),
            expanded_supergrid.isel(nyp=slice(0, -2), nxp=slice(0, -2)),
            expanded_supergrid.isel(nyp=slice(0, -2), nxp=slice(2, None)),
            point,
        ).values

    @staticmethod
    def _create_expanded_supergrid(x, y, expansion_width=1) -> xr.Dataset:
        """
        Adds an additional boundary to the supergrid to allow for the calculation of the ``angle_dx`` for the boundary points using :func:`~mom6_angle_calculation_method`.
        """
        if expansion_width != 1:
            raise NotImplementedError("Only expansion_width = 1 is supported")

        ny, nx = x.shape
        pseudo_supergrid_x = np.full((ny + 2, nx + 2), np.nan)
        pseudo_supergrid_y = np.full((ny + 2, nx + 2), np.nan)

        ## Fill Boundaries
        pseudo_supergrid_x[1:-1, 1:-1] = x
        pseudo_supergrid_x[0, 1:-1] = x[0, :] - (x[1, :] - x[0, :])  # Bottom Fill
        pseudo_supergrid_x[-1, 1:-1] = x[-1, :] + (x[-1, :] - x[-2, :])  # Top Fill
        pseudo_supergrid_x[1:-1, 0] = x[:, 0] - (x[:, 1] - x[:, 0])  # Left Fill
        pseudo_supergrid_x[1:-1, -1] = x[:, -1] + (x[:, -1] - x[:, -2])  # Right Fill

        pseudo_supergrid_y[1:-1, 1:-1] = y
        pseudo_supergrid_y[0, 1:-1] = y[0, :] - (y[1, :] - y[0, :])  # Bottom Fill
        pseudo_supergrid_y[-1, 1:-1] = y[-1, :] + (y[-1, :] - y[-2, :])  # Top Fill
        pseudo_supergrid_y[1:-1, 0] = y[:, 0] - (y[:, 1] - y[:, 0])  # Left Fill
        pseudo_supergrid_y[1:-1, -1] = y[:, -1] + (y[:, -1] - y[:, -2])  # Right Fill

        ## Fill Corners
        pseudo_supergrid_x[0, 0] = x[0, 0] - (x[1, 1] - x[0, 0])  # Bottom Left
        pseudo_supergrid_x[-1, 0] = x[-1, 0] - (x[-2, 1] - x[-1, 0])  # Top Left
        pseudo_supergrid_x[0, -1] = x[0, -1] - (x[1, -2] - x[0, -1])  # Bottom Right
        pseudo_supergrid_x[-1, -1] = x[-1, -1] - (x[-2, -2] - x[-1, -1])  # Top Right

        pseudo_supergrid_y[0, 0] = y[0, 0] - (y[1, 1] - y[0, 0])  # Bottom Left
        pseudo_supergrid_y[-1, 0] = y[-1, 0] - (y[-2, 1] - y[-1, 0])  # Top Left
        pseudo_supergrid_y[0, -1] = y[0, -1] - (y[1, -2] - y[0, -1])  # Bottom Right
        pseudo_supergrid_y[-1, -1] = y[-1, -1] - (y[-2, -2] - y[-1, -1])  # Top Right

        pseudo_supergrid = xr.Dataset(
            {
                "x": (["nyp", "nxp"], pseudo_supergrid_x),
                "y": (["nyp", "nxp"], pseudo_supergrid_y),
            }
        )
        return pseudo_supergrid

    def expand(self, n_cells=1) -> "SupergridBase":
        """
        Return a new supergrid padded by ``n_cells`` T-cells of linear
        extrapolation on every side (a halo), by repeatedly applying
        :func:`_create_expanded_supergrid` (each call pads by half a T-cell
        per side) and rebuilding full grid metrics from the resulting x/y.
        """
        if self.is_cyclic_x or self.is_tripolar:
            raise NotImplementedError(
                "expand() is not supported for cyclic or tripolar grids"
            )
        assert n_cells >= 1, "n_cells must be a positive integer"
        x, y = self.x, self.y
        for _ in range(2 * n_cells):
            padded = self._create_expanded_supergrid(x, y)
            x, y = padded.x.values, padded.y.values
        assert (
            -90 <= y.min() and y.max() <= 90
        ), "Expanded supergrid exceeds ±90 degrees latitude; check the input grid and expansion width."
        return type(self)._init_from_xy(
            x,
            y,
            grid_type=self.grid_type,
            R=self._R,
            dx_dy_calc_type=self._dx_dy_calc_type,
        )


class UniformSphericalSupergrid(SupergridBase):
    """MOM6-style supergrid with constant-degree spacing (lon/lat grid)."""

    @classmethod
    def from_extents(
        cls, lon_min, len_x, lat_min, len_y, nx, ny, radius=_DEFAULT_RADIUS
    ):
        """Create a grid from domain extents (lon/lat degrees)."""
        x, y = cls._calc_xy_from_extents(lon_min, len_x, lat_min, len_y, nx, ny)
        return cls._init_from_xy(
            x, y, "uniform_spherical", radius, angles_are_zero=True
        )

    @classmethod
    def _calc_xy_from_extents(cls, lon_min, len_x, lat_min, len_y, nx, ny):
        """Compute full grid geometry for equal-degree spacing."""

        # ---------------------------------------------------------------------
        # Determine grid resolution and index arrays
        # ---------------------------------------------------------------------
        nx_total = nx * 2  # number of longitudinal cells
        ny_total = ny * 2  # number of latitudinal cells

        jindp = np.arange(ny_total + 1)  # latitude point indices (cell edges)
        iindp = np.arange(nx_total + 1)  # longitude point indices (cell edges)

        # ---------------------------------------------------------------------
        # Compute grid coordinates in degrees
        # ---------------------------------------------------------------------
        grid_y = lat_min + jindp * len_y / ny_total  # latitude edges
        grid_x = lon_min + iindp * len_x / nx_total  # longitude edges

        # Form full 2D coordinate arrays for all cell corners
        x = np.tile(grid_x, (ny_total + 1, 1))
        y = np.tile(grid_y.reshape((ny_total + 1, 1)), (1, nx_total + 1))

        return x, y


class RectilinearCartesianSupergrid(SupergridBase):
    """MOM6-style supergrid with uniform Cartesian spacing (x/y in meters). Originally by Ashley Barnes in regional_mom6"""

    @classmethod
    def from_extents(
        cls, lon_min, len_x, lat_min, len_y, resolution, radius=_DEFAULT_RADIUS
    ):
        x, y = cls._build_grid(lon_min, len_x, lat_min, len_y, resolution)
        return cls._init_from_xy(
            x, y, "rectilinear_cartesian", radius, angles_are_zero=True
        )

    @classmethod
    def _build_grid(self, lon_min, len_x, lat_min, len_y, resolution):
        """Compute x,y for even physical spacing."""
        lon_max = lon_min + len_x
        lat_max = lat_min + len_y

        nx = int(len_x / (resolution / 2))
        if nx % 2 != 1:
            nx += 1

        lons = np.linspace(lon_min, lon_max, nx)  # longitudes in degrees

        # Latitudes evenly spaced by dx * cos(central_latitude)
        central_latitude = np.mean([lat_min, lat_max])  # degrees
        latitudinal_resolution = resolution * np.cos(np.deg2rad(central_latitude))

        ny = int(len_y / (latitudinal_resolution / 2)) + 1

        if ny % 2 != 1:
            ny += 1
        lats = np.linspace(lat_min, lat_max, ny)  # latitudes in degrees

        assert np.all(
            np.diff(lons) > 0
        ), "longitudes array lons must be monotonically increasing"
        assert np.all(
            np.diff(lats) > 0
        ), "latitudes array lats must be monotonically increasing"

        # ensure that longitudes are uniformly spaced
        dlons = lons[1] - lons[0]
        assert np.allclose(
            np.diff(lons), dlons * np.ones(np.size(lons) - 1)
        ), "provided array of longitudes must be uniformly spaced"

        lon, lat = np.meshgrid(lons, lats)
        return lon, lat


class ProjectedSupergrid(SupergridBase):
    """MOM6-style supergrid built from a map projection.

    Constructs a uniform grid in a given pyproj CRS and reprojects node
    coordinates to geographic degrees for the MOM6 supergrid file. Grid metrics
    (dx, dy, area, angle_dx) are computed from exact great-circle geometry rather
    than the approximate cos(lat) scaling used by UniformSphericalSupergrid and
    RectilinearCartesianSupergrid.

    Use this instead of RectilinearCartesianSupergrid when:
    - The domain is near a pole (e.g., "EPSG:3995" Arctic / "EPSG:3031" Antarctic).
    - The grid needs to align with a non-lat/lon feature like an estuary mouth
      (use from_center with angle_deg).
    """

    @classmethod
    def from_crs(
        cls, crs, x_min, x_max, y_min, y_max, resolution_m, radius=_DEFAULT_RADIUS
    ):
        """Create a grid from projected coordinate extents.

        Parameters
        ----------
        crs : pyproj.CRS, int, or str
            Coordinate reference system. Accepts a pyproj.CRS object, an EPSG
            code (int or "EPSG:XXXX"), or a PROJ string.
            Examples:
                "EPSG:3995"  — Arctic Polar Stereographic
                "EPSG:3031"  — Antarctic Polar Stereographic
                "+proj=lcc +lat_1=33 +lat_2=45 +lat_0=39 +lon_0=-96"  — Lambert conformal
        x_min, x_max : float
            Projected x-coordinate extent in metres.
        y_min, y_max : float
            Projected y-coordinate extent in metres.
        resolution_m : float
            Grid resolution in metres, uniform in both projected x and y.
        radius : float, optional
            Sphere radius in metres. Defaults to Earth's IUGG mean radius.
        """

        if not isinstance(crs, CRS):
            crs = CRS.from_user_input(crs)

        nx = int((x_max - x_min) / resolution_m)
        ny = int((y_max - y_min) / resolution_m)

        x_sg = np.linspace(x_min, x_max, 2 * nx + 1)
        y_sg = np.linspace(y_min, y_max, 2 * ny + 1)
        xx, yy = np.meshgrid(x_sg, y_sg)

        transformer = Transformer.from_crs(crs, "EPSG:4326", always_xy=True)
        lon, lat = transformer.transform(xx, yy)

        # Use haversine (exact great-circle distance) rather than the smallangle
        # default: this domain can fully encircle a pole (e.g. any Arctic/Antarctic
        # polar-cap CRS), where adjacent supergrid nodes can land on opposite sides
        # of the antimeridian branch cut. Haversine needs no unwrapping to handle
        # that correctly, since sin(dlon/2)**2 is invariant under dlon -> dlon+360,
        # and it stays consistent with area's sphere-of-radius-R assumption.
        return cls._init_from_xy(
            lon, lat, "projected_crs", radius, dx_dy_calc_type="haversine"
        )

    @classmethod
    def from_center(
        cls,
        center_lat,
        center_lon,
        width_m,
        height_m,
        resolution_m,
        angle_deg=0.0,
        radius=_DEFAULT_RADIUS,
    ):
        """Create a rotated rectangular grid centered at a geographic point.

        Uses an azimuthal equidistant projection centred at (center_lat, center_lon)
        and rotates the domain by angle_deg clockwise from north. This is the right
        tool when one grid boundary needs to align with a feature like an estuary
        mouth: rotate until the southern (or northern) edge of the domain lies
        perpendicular to the channel axis.

        Parameters
        ----------
        center_lat, center_lon : float
            Geographic centre of the domain in degrees.
        width_m, height_m : float
            Domain width (x-direction) and height (y-direction) in metres.
        resolution_m : float
            Grid resolution in metres.
        angle_deg : float, optional
            Clockwise rotation from north in degrees. Default 0 (north-up).
            Example: angle_deg=45 rotates so that the x-axis points NE,
            useful for a NE-SW estuary mouth.
        radius : float, optional
            Sphere radius in metres. Defaults to Earth's IUGG mean radius.
        """

        proj_str = (
            f"+proj=aeqd +lat_0={center_lat} +lon_0={center_lon} "
            f"+x_0=0 +y_0=0 +datum=WGS84 +units=m"
        )
        crs = CRS.from_proj4(proj_str)

        nx = int(width_m / resolution_m)
        ny = int(height_m / resolution_m)

        xi = np.linspace(-width_m / 2, width_m / 2, 2 * nx + 1)
        yi = np.linspace(-height_m / 2, height_m / 2, 2 * ny + 1)
        xx, yy = np.meshgrid(xi, yi)

        # Rotate clockwise by angle_deg (standard compass bearing convention)
        theta = np.deg2rad(angle_deg)
        xx_rot = xx * np.cos(theta) + yy * np.sin(theta)
        yy_rot = -xx * np.sin(theta) + yy * np.cos(theta)

        transformer = Transformer.from_crs(crs, "EPSG:4326", always_xy=True)
        lon, lat = transformer.transform(xx_rot, yy_rot)

        # See from_crs: haversine handles a pole- or antimeridian-straddling
        # domain correctly with no unwrapping needed, unlike the smallangle default.
        return cls._init_from_xy(
            lon, lat, "projected_crs", radius, dx_dy_calc_type="haversine"
        )


def angle_between(v1, v2, v3):
    """Return the angle ``v2``-``v1``-``v3`` (in radians), where
    ``v1``, ``v2``, ``v3`` are 3-vectors. That is, the angle that
    is formed between vectors ``v2 - v1`` and vector ``v3 - v1``.

    Example:

        >>> from regional_mom6.utils import angle_between
        >>> v1 = (0, 0, 1)
        >>> v2 = (1, 0, 0)
        >>> v3 = (0, 1, 0)
        >>> angle_between(v1, v2, v3)
        1.5707963267948966
        >>> from numpy import rad2deg
        >>> rad2deg(angle_between(v1, v2, v3))
        90.0
    """

    v1xv2 = np.cross(v1, v2)
    v1xv3 = np.cross(v1, v3)

    norm_v1xv2 = np.sqrt(vecdot(v1xv2, v1xv2))
    norm_v1xv3 = np.sqrt(vecdot(v1xv3, v1xv3))

    with np.errstate(invalid="ignore", divide="ignore"):
        cosangle = vecdot(v1xv2, v1xv3) / (norm_v1xv2 * norm_v1xv3)

    # Thin cells can push the cosine a few ulps out of range; arccos would NaN.
    return np.arccos(np.clip(cosangle, -1.0, 1.0))


def vecdot(v1, v2):
    """Return the dot product of vectors ``v1`` and ``v2``.
    ``v1`` and ``v2`` can be either numpy vectors or numpy.ndarrays
    in which case the last dimension is considered the dimension
    over which the dot product is taken.
    """
    return np.sum(v1 * v2, axis=-1)


def latlon_to_cartesian(lat, lon, R=1):
    """Convert latitude and longitude (in degrees) to Cartesian coordinates on
    a sphere of radius ``R``. By default ``R = 1``.

    Arguments:
        lat (float): Latitude (in degrees).
        lon (float): Longitude (in degrees).
        R (float): The radius of the sphere; default: 1.

    Returns:
        tuple: Tuple with the Cartesian coordinates ``x, y, z``

    Examples:

        Find the Cartesian coordinates that correspond to point with
        ``(lat, lon) = (0, 0)`` on a sphere with unit radius.

        >>> from regional_mom6.utils import latlon_to_cartesian
        >>> latlon_to_cartesian(0, 0)
        (1.0, 0.0, 0.0)

        Now let's do the same on a sphere with Earth's radius

        >>> from regional_mom6.utils import latlon_to_cartesian
        >>> R = 6371e3
        >>> latlon_to_cartesian(0, 0, R)
        (6371000.0, 0.0, 0.0)
    """

    x = R * np.cos(np.deg2rad(lat)) * np.cos(np.deg2rad(lon))
    y = R * np.cos(np.deg2rad(lat)) * np.sin(np.deg2rad(lon))
    z = R * np.sin(np.deg2rad(lat))

    return x, y, z


def quadrilateral_areas(lat, lon, R=1):
    """Return the area of spherical quadrilaterals on a sphere of radius ``R``.
    By default, ``R = 1``. The quadrilaterals are formed by constant latitude and
    longitude lines on the ``lat``-``lon`` grid provided.

    Arguments:
        lat (numpy.array): Array of latitude points (in degrees).
        lon (numpy.array): Array of longitude points (in degrees).
        R (float): The radius of the sphere; default: 1.

    Returns:
        numpy.array: Array with the areas of the quadrilaterals defined by the ``lat``-``lon`` grid
        provided. If the provided ``lat``, ``lon`` arrays are of dimension *m* :math:`\\times` *n*
        then returned areas array is of dimension (*m-1*) :math:`\\times` (*n-1*).

    Example:

        Let's construct a lat-lon grid on the sphere with 60 degree spacing.
        Then we compute the areas of each grid cell and confirm that the
        sum of the areas gives us the total area of the sphere.

        >>> from regional_mom6.utils import quadrilateral_areas
        >>> import numpy as np
        >>> λ = np.linspace(0, 360, 7)
        >>> φ = np.linspace(-90, 90, 4)
        >>> lon, lat = np.meshgrid(λ, φ)
        >>> lon
        array([[  0.,  60., 120., 180., 240., 300., 360.],
               [  0.,  60., 120., 180., 240., 300., 360.],
               [  0.,  60., 120., 180., 240., 300., 360.],
               [  0.,  60., 120., 180., 240., 300., 360.]])
        >>> lat
        array([[-90., -90., -90., -90., -90., -90., -90.],
               [-30., -30., -30., -30., -30., -30., -30.],
               [ 30.,  30.,  30.,  30.,  30.,  30.,  30.],
               [ 90.,  90.,  90.,  90.,  90.,  90.,  90.]])
        >>> R = 6371e3
        >>> areas = quadrilateral_areas(lat, lon, R)
        >>> areas
        array([[1.96911611e+13, 1.96911611e+13, 1.96911611e+13, 1.96911611e+13,
                1.96911611e+13, 1.96911611e+13],
               [4.56284230e+13, 4.56284230e+13, 4.56284230e+13, 4.56284230e+13,
                4.56284230e+13, 4.56284230e+13],
               [1.96911611e+13, 1.96911611e+13, 1.96911611e+13, 1.96911611e+13,
                1.96911611e+13, 1.96911611e+13]])
        >>> np.isclose(areas.sum(), 4 * np.pi * R**2, atol=np.finfo(areas.dtype).eps)
        True
    """

    coords = np.dstack(latlon_to_cartesian(lat, lon, R))

    return quadrilateral_area(
        coords[:-1, :-1, :], coords[:-1, 1:, :], coords[1:, 1:, :], coords[1:, :-1, :]
    )


def _central_angle(u, v):
    """Return the angle between two points on a sphere, seen from its center.

    ``u`` and ``v`` are 3-vectors and the angle is in radians. This uses atan2
    rather than the arccosine of a dot product, which loses most of its accuracy
    when the two points are close together.
    """

    cross = np.cross(u, v)
    return np.arctan2(np.sqrt(vecdot(cross, cross)), vecdot(u, v))


def spherical_triangle_area(v1, v2, v3):
    """Return the area of a triangle on a sphere, given its three corners.

    The corners ``v1``, ``v2`` and ``v3`` are 3-vectors. The area is found with
    l'Huilier's theorem, which stays accurate however thin the triangle is.
    If two corners are the same point the triangle has no area, and the result is
    zero rather than NaN.
    """

    R = np.sqrt(vecdot(v1, v1))

    a = _central_angle(v2, v3)
    b = _central_angle(v3, v1)
    c = _central_angle(v1, v2)
    s = 0.5 * (a + b + c)

    tans = (
        np.tan(0.5 * s)
        * np.tan(0.5 * (s - a))
        * np.tan(0.5 * (s - b))
        * np.tan(0.5 * (s - c))
    )
    # Rounding can leave this product slightly negative for a flat triangle.
    return 4.0 * np.arctan(np.sqrt(np.maximum(tans, 0.0))) * R**2


def quadrilateral_area(v1, v2, v3, v4):
    """Return the area of a four-sided cell on a sphere, given its corners.

    The corners are the 3-vectors ``v1``, ``v2``, ``v3``, ``v4``, taken in
    counter-clockwise order. The cell is cut along a diagonal and the two
    triangles are added up (see :func:`spherical_triangle_area`).

    Example:

        Calculate the area that corresponds to half the Northern hemisphere
        of a sphere of radius *R*. This should be 1/4 of the sphere's total area,
        that is π *R*:sup:`2`.

        >>> from regional_mom6.utils import quadrilateral_area, latlon_to_cartesian
        >>> R = 434.3
        >>> v1 = latlon_to_cartesian(0, 0, R)
        >>> v2 = latlon_to_cartesian(0, 90, R)
        >>> v3 = latlon_to_cartesian(90, 0, R)
        >>> v4 = latlon_to_cartesian(0, -90, R)
        >>> quadrilateral_area(v1, v2, v3, v4)
        592556.1793298927
        >>> from numpy import pi
        >>> quadrilateral_area(v1, v2, v3, v4) == pi * R**2
        True
    """

    v1 = np.array(v1)
    v2 = np.array(v2)
    v3 = np.array(v3)
    v4 = np.array(v4)

    if not (
        np.all(np.isclose(vecdot(v1, v1), vecdot(v2, v2)))
        & np.all(np.isclose(vecdot(v1, v1), vecdot(v2, v2)))
        & np.all(np.isclose(vecdot(v1, v1), vecdot(v3, v3)))
        & np.all(np.isclose(vecdot(v1, v1), vecdot(v4, v4)))
    ):
        raise ValueError("vectors provided must have the same length")

    # Cut the quadrilateral along a diagonal and add the two halves; areas add up
    # on a sphere just as they do on a plane. Each half is still handled correctly
    # if the quadrilateral has collapsed into a triangle, which is what a collapsed
    # pole row and the tripolar fold seam both produce.
    return spherical_triangle_area(v1, v2, v3) + spherical_triangle_area(v1, v3, v4)


def mom6_angle_calculation_method(
    len_lon,
    top_left: xr.DataArray,
    top_right: xr.DataArray,
    bottom_left: xr.DataArray,
    bottom_right: xr.DataArray,
    point: xr.DataArray,
) -> xr.DataArray:
    """
    Calculate the angle of the grid point's local x-direction compared to East-West direction
    using the MOM6 method adapted from: https://github.com/mom-ocean/MOM6/blob/05d8cc395c1c3c04dd04885bf8dd6df50a86b862/src/initialization/MOM_shared_initialization.F90#L572-L587

    Note: this is exactly the same as the angle of the grid point's local y-direction compared to North-South direction.

    This method can handle vectorized computations.

    Parameters
    ----------
    len_lon: float
        The extent of the longitude of the regional domain (in degrees).
    top_left, top_right, bottom_left, bottom_right: xr.DataArray
        The four points around the point to calculate the angle from the ``supergrid``;
        requires both an ``x``` and ``y`` component (both in degrees).
    point: xr.DataArray
        The point to calculate the angle from the ``supergrid``

    Returns
    -------
    xr.DataArray
        The angle of the grid point's local ``x``-direction compared to East-West direction.
    """

    # Compute lonB for all points
    lonB = np.zeros((2, 2, len(point.nyp), len(point.nxp)))

    # Vectorized computation of lonB
    lonB[0][0] = modulo_around_point(bottom_left.x, point.x, len_lon)  # Bottom Left
    lonB[1][0] = modulo_around_point(top_left.x, point.x, len_lon)  # Top Left
    lonB[1][1] = modulo_around_point(top_right.x, point.x, len_lon)  # Top Right
    lonB[0][1] = modulo_around_point(bottom_right.x, point.x, len_lon)  # Bottom Right

    cos_meanlat = np.cos(
        np.deg2rad((bottom_left.y + bottom_right.y + top_right.y + top_left.y) / 4)
    )

    # Quadrilateral diagonals

    # top-left--bottom-right diagonal components
    TL_BR_diagonal_x = cos_meanlat * (lonB[1, 0] - lonB[0, 1])
    TL_BR_diagonal_y = top_left.y - bottom_right.y

    # top-right--bottom-left diagonal components
    TR_BL_diagonal_x = cos_meanlat * (lonB[1, 1] - lonB[0, 0])
    TR_BL_diagonal_y = top_right.y - bottom_left.y

    # Sum of diagonals components
    sum_of_diagonals_x = TR_BL_diagonal_x + TL_BR_diagonal_x
    sum_of_diagonals_y = TR_BL_diagonal_y + TL_BR_diagonal_y

    # Angle of sum-of-diagonals vector with the North-South direction
    # Note: the minus sign changes convention from clockwise to counter-clockwise
    angle = -np.arctan2(sum_of_diagonals_x, sum_of_diagonals_y)  # = - atan(x/y)

    # Convert to degrees and assign to angles_arr
    angles_arr = np.rad2deg(angle)

    # Assign angles_arr to supergrid
    t_angles = xr.DataArray(
        angles_arr,
        dims=["nyp", "nxp"],
        coords={
            "nyp": point.nyp.values,
            "nxp": point.nxp.values,
        },
    )
    return t_angles


def modulo_around_point(x, x0, L):
    """
    Returns the modulo-:math:`L` value of :math:`x` within the interval :math:`[x_0 - L/2, x_0 + L/2]`.
    If :math:`L ≤ 0`, then method returns :math:`x`.

    (Adapted from MOM6 code; https://github.com/mom-ocean/MOM6/blob/776be843e904d85c7035ffa00233b962a03bfbb4/src/initialization/MOM_shared_initialization.F90#L592-L606)

    Parameters
    ----------
    x: xr.DataArray
       Value(s) to which to apply modulo arithmetic
    x0: xr.DataArray
        Center(s) of modulo range
    L: float
       Modulo range width

    Returns
    -------
    float
        ``x`` shifted by an integer multiple of ``L`` to be closer to ``x0``, i.e., within the interval ``[x0 - L/2, x0 + L/2]``
    """
    if L <= 0:
        return x
    else:
        # Find that boundary point x0 + L/2
        edge_indexes = np.where((x == x0 + L / 2))

        # Modulo calculation
        calc = ((x - (x0 - L / 2)) % L) + (x0 - L / 2)

        # Find that boundary point x0 + L/2 does not flip to x0 - L/2
        calc[edge_indexes] = x[edge_indexes]

        return calc


def haversine(lat1, lon1, lat2, lon2, R):
    """Great-circle distance (metres) between arrays of points given in degrees."""
    dlat = np.deg2rad(lat2 - lat1)
    dlon = np.deg2rad(lon2 - lon1)
    a = (
        np.sin(dlat / 2) ** 2
        + np.cos(np.deg2rad(lat1)) * np.cos(np.deg2rad(lat2)) * np.sin(dlon / 2) ** 2
    )
    return (
        2
        * R
        * np.arctan2(np.sqrt(np.clip(a, 0.0, 1.0)), np.sqrt(np.clip(1.0 - a, 0.0, 1.0)))
    )
