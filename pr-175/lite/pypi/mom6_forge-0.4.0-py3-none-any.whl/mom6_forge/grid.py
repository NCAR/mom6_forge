import os
import copy
import warnings
from typing import Optional, Union
import numpy as np
import xarray as xr
from scipy.spatial import cKDTree
from mom6_forge._supergrid import (
    UniformSphericalSupergrid,
    RectilinearCartesianSupergrid,
    ProjectedSupergrid,
    SupergridBase,
    modulo_around_point,
)
from mom6_forge.utils import normalize_deg, renamed_kwargs


def _encircles_globe(lon_values):
    """Whether these longitudes wrap all the way around the globe.

    Reaching a pole is not the same question: the north edge of a narrow polar
    domain reaches 90 degrees while spanning only a few degrees of longitude,
    and a box that encircles a pole can keep every node well short of it.

    For a 2D domain the answer is exact. Walk the boundary accumulating the
    shortest-way longitude step at each node; around a closed loop that total
    is 360 degrees times an integer winding number, 1 if the boundary goes
    around a pole and 0 if not. Measured 1.0000 for polar caps from 25 to 6561
    nodes -- square, rectangular, offset, both hemispheres -- and 0.0000 for
    every band, independent of resolution.

    A single edge encloses no area, so it has no winding to count; the 2D test
    run on one would answer backwards (0 for a polar cap's north edge, 1 for a
    band's middle row). Edges instead compare the two largest gaps between
    neighbouring longitudes: a band has one void and so a lone outlier, while a
    set spread around the circle does not.

    That fallback does depend on resolution -- it reads a band as encircling
    once the node spacing exceeds half the void, e.g. a 350-degree band sampled
    every 10 degrees. It errs toward reporting the full circle, so a caller
    over-fetches rather than silently dropping data, and a real grid's edges
    stay far from the limit. Only a coarse near-global domain approaches it,
    and for one of those the winding test above already decides.
    """
    lon = np.asarray(lon_values, dtype=float)

    if lon.ndim == 2 and min(lon.shape) >= 2:
        loop = np.concatenate(
            [lon[0, :], lon[1:, -1], lon[-1, -2::-1], lon[-2:0:-1, 0], lon[:1, 0]]
        )
        step = (np.diff(loop) + 180.0) % 360.0 - 180.0
        return abs(float(step.sum())) > 180.0

    lon = np.unique(normalize_deg(np.ravel(lon)))
    if lon.size < 3:
        return False
    # Gaps between neighbouring longitudes on the circle, including the wrap.
    gaps = np.sort(np.append(np.diff(lon), lon[0] + 360.0 - lon[-1]))[::-1]
    largest, second = float(gaps[0]), float(gaps[1])
    if second <= 0.0:
        return False
    return largest < 2.0 * second


class Grid:
    """
    Horizontal MOM6 grid. The first step of constructing a MOM6 grid within
    the CESM simpler models framework is to create a Grid instance.

    Attributes
    ----------
    tlon: xr.DataArray
        array of t-grid longitudes
    tlat: xr.DataArray
        array of t-grid latitudes
    ulon: xr.DataArray
        array of u-grid longitudes
    ulat: xr.DataArray
        array of u-grid latitudes
    vlon: xr.DataArray
        array of v-grid longitudes
    vlat: xr.DataArray
        array of v-grid latitudes
    qlon: xr.DataArray
        array of corner longitudes
    qlat: xr.DataArray
        array of corner latitudes
    dxt: xr.DataArray
        x-distance between U points, centered at t
    dyt: xr.DataArray
        y-distance between V points, centered at t
    dxCv: xr.DataArray
        x-distance between q points, centered at v
    dyCu: xr.DataArray
        y-distance between q points, centered at u
    dxCu: xr.DataArray
        x-distance between y points, centered at u
    dyCv: xr.DataArray
        y-distance between t points, centered at v
    angle: xr.DataArray
        angle grid makes with latitude line
    angle_q: xr.DataArray
        angle q-grid makes with latitude line
    tarea: xr.DataArray
        T-cell area

    """

    def __init__(
        self,
        lenx: float,
        leny: float,
        nx: int = None,
        ny: int = None,
        resolution: Optional[float] = None,
        xstart: float = 0.0,
        ystart: Optional[float] = None,
        cyclic_x: bool = False,
        name: Optional[str] = None,
        type: str = "uniform_spherical",
    ) -> None:
        """
        Grid instance constructor.

        Parameters
        ----------
        lenx : float
            grid length in x direction, e.g., 360.0 (degrees)
        leny : float
            grid length in y direction, e.g., 160.0 (degrees)
        nx : int, optional
            Number of grid points in x direction
        ny : int, optional
            Number of grid points in y direction
        resolution : float, optional
            grid resolution in degrees. If provided, the grid
            dimensions are computed based on the resolution:
            nx = int(lenx / resolution) and ny = int(leny / resolution)
        xstart : float, optional
            starting x coordinate. 0.0 by default.
        ystart : float, optional
            starting y coordinate. -0.5*leny by default.
        cyclic_x : bool, optional
            flag to make the grid cyclic in x direction. False by default.
        name : str, optional
            name of the grid. None by default.
        type : str, optional
            If not specified, creates an uniform_degree grid.
            Options are uniform_degree or rectilinear_cartesian
        """

        # default ystart value (centers the domain at the Equator)
        if ystart is None:
            ystart = -0.5 * leny

        if nx is not None or ny is not None:
            assert (
                nx is not None and ny is not None
            ), "nx and ny must be provided together"
            assert resolution is None, "resolution cannot be provided with nx and ny"
        else:
            assert (
                resolution is not None
            ), "resolution must be provided if nx and ny are not"
            nx = int(round(lenx / resolution))
            ny = int(round(leny / resolution))

        if type == "rectilinear_cartesian" and resolution is None:
            raise ValueError(
                "resolution must be provided for rectilinear_cartesian grid type"
            )

        # consistency checks for constructor arguments
        assert nx > 0, "nx must be a positive integer"
        assert ny > 0, "ny must be a positive integer"
        assert (
            not cyclic_x or lenx == 360.0
        ), "cyclic_x is only supported for 360 degree domains."
        assert 0 < lenx <= 360.0, "lenx must be in the range (0, 360]"
        assert 0 < leny <= 180.0, "leny must be in the range (0, 180]"
        assert -90.0 <= ystart <= 90.0, "ystart must be in the range [-90, 90]"
        assert leny + ystart <= 90.0, "leny + ystart must be less than 90"
        self.name = name
        self.cyclic_x = cyclic_x

        if type == "uniform_spherical":
            self.supergrid = UniformSphericalSupergrid.from_extents(
                lon_min=xstart, len_x=lenx, lat_min=ystart, len_y=leny, nx=nx, ny=ny
            )
        elif type == "rectilinear_cartesian":
            self.supergrid = RectilinearCartesianSupergrid.from_extents(
                lon_min=xstart,
                len_x=lenx,
                lat_min=ystart,
                len_y=leny,
                resolution=resolution,
            )
        else:
            raise ValueError(f"Unsupported grid type: {type}")

    @property
    def name(self) -> str:
        """Name of the grid."""
        return self._name

    @property
    def kdtree(self) -> cKDTree:
        """KDTree for fast nearest neighbor search."""
        if not hasattr(self, "_kdtree") or self._kdtree is None:
            self._kdtree = cKDTree(
                np.column_stack(
                    (self.tlat.values.flatten(), self.tlon.values.flatten())
                )
            )
        return self._kdtree

    @name.setter
    def name(self, new_name: str) -> None:
        assert (
            new_name is None or new_name.replace("_", "").isalnum()
        ), "Grid name must be alphanumeric"
        self._name = new_name

    def __getitem__(self, slices) -> xr.DataArray:
        """
        Get a subgrid copy based on the provided slices.

        Parameters
        ----------
        slices : tuple
            A tuple of two slices, e.g., [A:B:C, D:E:F]
            The first slice A:B:C corresponds to the j-axis (y-axis) and the second
            slice D:E:F corresponds to the i-axis (x-axis). Examples:
            grid[0:10, 0:20] or grid[:, 0:20] or grid[0:10, :].

        Returns
        -------
        Grid
            A new Grid instance representing the subgrid defined by the slices.
        """

        # Check if args are a tuple of two slices
        assert (
            isinstance(slices, tuple)
            and len(slices) == 2
            and all(isinstance(s, slice) for s in slices)
        ), (
            "Must provide both j and i slices when indexing the grid. "
            "Examples: grid[0:10, 0:20] or grid[:, 0:20] or grid[0:10, :]."
        )

        j_slice, i_slice = slices

        # If both slices are None, return a deep copy of the grid
        if j_slice == slice(None) and i_slice == slice(None):
            return copy.deepcopy(self)

        # Get the slice bounds and steps
        j_low, j_high, j_step = (
            j_slice.start or 0,
            j_slice.stop or self.ny,
            j_slice.step or 1,
        )
        i_low, i_high, i_step = (
            i_slice.start or 0,
            i_slice.stop or self.nx,
            i_slice.step or 1,
        )

        # Negative indices to positive indices
        if j_low < 0:
            j_low = (j_low + self.ny) % self.ny
        if i_low < 0:
            i_low = (i_low + self.nx) % self.nx
        if j_high < 0:
            j_high = (j_high + self.ny) % self.ny
        if i_high < 0:
            i_high = (i_high + self.nx) % self.nx

        # Sanity checks for slice bounds and steps
        assert j_low >= 0, "Lower j slice bound must be non-negative"
        assert i_low >= 0, "Lower i slice bound must be non-negative"
        assert j_step > 0, "j slice step must be positive"
        assert i_step > 0, "i slice step must be positive"
        assert j_low < self.ny, "Lower j slice bound exceeds the grid's ny dimension"
        assert i_low < self.nx, "Lower i slice bound exceeds the grid's nx dimension"
        assert (
            j_high > j_low
        ), "Upper j slice bound must be greater than lower j slice bound"
        assert (
            i_high > i_low
        ), "Upper i slice bound must be greater than lower i slice bound"
        assert j_high <= self.ny, "Upper j slice bound exceeds the grid's ny dimension"
        assert i_high <= self.nx, "Upper i slice bound exceeds the grid's nx dimension"

        srefine = 2  # supergrid refinement factor

        # Periodicity checks:

        cyclic_x = self.cyclic_x and (i_low == 0) and (i_high == self.nx)

        # Cyclic Y and tripolar are still TODO (these were not supported previously)
        # cyclic_y = (
        #     self.supergrid.dict["cyclic_y"] and (j_low == 0) and (j_high == self.ny)
        # )
        # tripolar_n = (
        #     self.supergrid.dict["tripolar_n"]
        #     and (i_low == 0)
        #     and (i_high == self.nx)
        #     and (j_high == self.ny)
        # )

        # supergrid slicing:
        s_j_low = j_low * srefine
        s_j_high = (j_high) * srefine + 1
        s_i_low = i_low * srefine
        s_i_high = (i_high) * srefine + 1

        sub_supergrid = SupergridBase._init_from_xy(
            x=self.supergrid.x[s_j_low:s_j_high:j_step, s_i_low:s_i_high:i_step],
            y=self.supergrid.y[s_j_low:s_j_high:j_step, s_i_low:s_i_high:i_step],
            grid_type=self.supergrid.grid_type,
            # Rebuild the metrics the way the parent's were built. Without this
            # a projected grid silently drops back to the smallangle default,
            # and a non-default radius is lost.
            R=self.supergrid._R,
            dx_dy_calc_type=self.supergrid._dx_dy_calc_type,
        )

        # Create a name for the subgrid based on the slices
        # This may (and should) be overriden by the user later
        name = self.name or "subgrid"
        if j_low > 0 or j_high < self.ny:
            name += f"_jb{j_low}_je{j_high}"
        if i_low > 0 or i_high < self.nx:
            name += f"_ib{i_low}_ie{i_high}"

        # Create a new Grid instance for the subgrid and return it
        sub_grid = Grid(
            nx=int((i_high - i_low) / i_step),
            ny=int((j_high - j_low) / j_step),
            lenx=sub_supergrid.lenx,
            leny=sub_supergrid.leny,
            cyclic_x=cyclic_x,
            name=name,
        )
        sub_grid.supergrid = sub_supergrid
        sub_grid._compute_MOM6_grid_metrics()

        # check if the grid property shapes are consistent with the new grid dimensions
        nx, ny = sub_grid.nx, sub_grid.ny
        nxp, nyp = nx + 1, ny + 1
        assert (
            sub_grid.tlon.shape == (ny, nx)
            and sub_grid.tlat.shape == (ny, nx)
            and sub_grid.ulon.shape == (ny, nxp)
            and sub_grid.ulat.shape == (ny, nxp)
            and sub_grid.vlon.shape == (nyp, nx)
            and sub_grid.vlat.shape == (nyp, nx)
            and sub_grid.qlon.shape == (nyp, nxp)
            and sub_grid.qlat.shape == (nyp, nxp)
        ), (
            "Grid property shapes are inconsistent with the new grid dimensions after slicing. "
            "Try a different slicing specification."
        )

        return sub_grid

    @staticmethod
    def check_supergrid(supergrid: xr.Dataset) -> None:
        """
        Check if a given supergrid contains the necessary attributes
        and has consistent units.

        Parameters
        ----------
        supergrid : xarray.Dataset
            MOM6 Supergrid dataset
        """
        for attr in ["x", "y", "dx", "dy", "area"]:  # todo: add angle_dx
            assert attr in supergrid, f"Cannot find '{attr}' in supergrid dataset."
        assert (
            "units" in supergrid.x.attrs
        ), "units attribute for x coordinate is missing in supergrid dataset."
        assert (
            "units" in supergrid.y.attrs
        ), "units attribute for y coordinate is missing in supergrid dataset."
        assert supergrid.x.units == supergrid.y.units or (
            "degree" in supergrid.x.units and "degree" in supergrid.y.units
        ), "Different units in x and y coordinates not supported"

    @staticmethod
    def is_cyclic_x(supergrid) -> bool:
        """
        Check if a given supergrid x coordinate array is cyclic along the x-axis.

        Parameters
        ----------
        supergrid : xr.DataArray or np.array or SupergridBase
            Supergrid to check for cyclic x.
        """
        return np.allclose(
            normalize_deg(supergrid.x[:, 0]),
            normalize_deg(supergrid.x[:, -1]),
            rtol=1e-5,
        )

    @staticmethod
    def is_tripolar(supergrid) -> bool:
        """Check if the given supergrid x coordinates form a tripolar grid.

        Parameters
        ----------
        supergrid : xr.Dataset or xr.DataArray or np.array or SupergridBase
            Supergrid to check if tripolar. Anything carrying a 2D ``x``
            coordinate array will do, matching is_cyclic_x above.
        """

        return SupergridBase.x_is_tripolar(supergrid.x)

    def is_rectangular(self, atol=1e-3) -> bool:
        """Check if the grid is a rectangular lat-lon grid by comparing the
        first and last rows and columns of the tlon and tlat arrays.

        Parameters
        ----------
        atol : float, optional
            Absolute tolerance in degrees for the lat/lon comparisons. An
            absolute (rather than relative) tolerance is used because the
            coordinates are angles: the acceptable deviation must not scale
            with longitude/latitude magnitude.
        """

        return (
            np.allclose(self.tlon[:, 0], self.tlon[0, 0], atol=atol, rtol=0)
            and np.allclose(self.tlon[:, -1], self.tlon[0, -1], atol=atol, rtol=0)
            and np.allclose(self.tlat[0, :], self.tlat[0, 0], atol=atol, rtol=0)
            and np.allclose(self.tlat[-1, :], self.tlat[-1, 0], atol=atol, rtol=0)
        )

    @classmethod
    def get_bounding_boxes(cls, hgrid):
        """
        Extract lat/lon bounding boxes for each edge of a regional MOM6 grid.
        This function is used when subsetting global datasets (e.g. GLORYS)
        down to the lat/lon ranges required for efficient regridding:
            • north, south, east, west boundaries
            • Entire domain initial condition files
        Parameters
        ----------
        hgrid : Grid or xarray.Dataset in the supergrid format

        Returns
        -------
        dict
            A dictionary containing bounding boxes for:
                • "east"
                • "west"
                • "north"
                • "south"
                • "ic" (full domain for initial conditions)

            Each box is ``{"lon_min", "lon_max", "lat_min", "lat_max",
            "crosses_antimeridian"}``. ``lon_min`` is always a longitude in
            [-180, 180) and ``lon_max`` is ``lon_min`` plus the width of the
            box, so the pair always names a contiguous eastward arc and
            ``lon_max - lon_min`` is its width.

            A box straddling the antimeridian therefore carries
            ``lon_max > 180`` -- 170 to 190, say -- and sets
            ``crosses_antimeridian``. A caller selecting with
            ``lon_min <= lon <= lon_max`` from a source on [-180, 180] has to
            branch on that flag and take the two pieces separately. Wrapping
            ``lon_max`` down to -170 first and comparing would select nothing.

            On a cyclic-x grid, such as a band that wraps all the way around
            the globe, the "ic", "north" and "south" boxes always span the
            full circle, -180 to 180, wherever the grid starts. "east" and
            "west" are then the same seam meridian.
        """
        if type(hgrid) == Grid:
            hgrid = hgrid._supergrid.to_ds()
        # Decide cyclic once, up front. The 2D winding test reads a band as not
        # encircling, and re-centering points that span exactly 360 degrees
        # can drop the seam cell to float round-off.
        cyclic = Grid.is_cyclic_x(hgrid)

        def _lon_lat_bounds(lon_values, lat_values, full_circle=False):
            if full_circle or _encircles_globe(lon_values):
                # This edge surrounds every longitude -- no re-centering can
                # tighten it, so report the full circle.
                lon_min, lon_max = -180.0, 180.0
            else:
                # Re-center around one of this edge's own points before min/max,
                # so a seam crossing gives a tight range, not a huge raw span.
                center = np.ravel(lon_values)[np.ravel(lon_values).size // 2]
                wrapped = modulo_around_point(lon_values, center, 360)
                lon_min, lon_max = float(wrapped.min()), float(wrapped.max())
                # Re-centering leaves the interval wherever this edge's own
                # values happened to sit, which need not be anywhere a reader
                # would recognise: a grid stored in [0, 360) gives 350 to 370
                # for the arc that -10 to 10 names just as exactly. Slide the
                # interval so it starts at a real longitude. Both ends move
                # together, so the width, and the arc, are unchanged -- a box
                # that genuinely crosses the antimeridian still ends past 180,
                # because no in-range pair of ends can describe it.
                anchored = ((lon_min + 180.0) % 360.0) - 180.0
                lon_max += anchored - lon_min
                lon_min = anchored
            return {
                "lon_min": lon_min,
                "lon_max": lon_max,
                "lat_min": float(lat_values.min()),
                "lat_max": float(lat_values.max()),
                "crosses_antimeridian": lon_max > 180.0,
            }

        init_result = _lon_lat_bounds(hgrid.x.values, hgrid.y.values, cyclic)
        east_result = _lon_lat_bounds(
            hgrid.x.isel(nxp=-1).values, hgrid.y.isel(nxp=-1).values
        )
        west_result = _lon_lat_bounds(
            hgrid.x.isel(nxp=0).values, hgrid.y.isel(nxp=0).values
        )
        south_result = _lon_lat_bounds(
            hgrid.x.isel(nyp=0).values, hgrid.y.isel(nyp=0).values, cyclic
        )
        north_result = _lon_lat_bounds(
            hgrid.x.isel(nyp=-1).values, hgrid.y.isel(nyp=-1).values, cyclic
        )
        return {
            "east": east_result,
            "west": west_result,
            "north": north_result,
            "south": south_result,
            "ic": init_result,
        }

    @classmethod
    def from_projection(
        cls,
        crs,
        x_min: float,
        x_max: float,
        y_min: float,
        y_max: float,
        resolution_m: float,
        name: Optional[str] = None,
    ) -> "Grid":
        """Create a Grid from projected coordinate extents.

        Builds a uniform grid in the given pyproj CRS (e.g., polar stereographic,
        Lambert conformal) and reprojects to geographic coordinates. Grid metrics
        are computed using exact great-circle geometry, making this accurate at high
        latitudes where RectilinearCartesianSupergrid degrades.

        Parameters
        ----------
        crs : pyproj.CRS, int, or str
            Map projection. Examples:
                "EPSG:3995"  — Arctic Polar Stereographic
                "EPSG:3031"  — Antarctic Polar Stereographic
        x_min, x_max : float
            Projected x extent in metres.
        y_min, y_max : float
            Projected y extent in metres.
        resolution_m : float
            Grid resolution in metres.
        name : str, optional
            Name of the grid.

        Returns
        -------
        Grid
        """
        sg = ProjectedSupergrid.from_crs(crs, x_min, x_max, y_min, y_max, resolution_m)
        return Grid.from_supergrid_ds(sg.to_ds(), name=name)

    @classmethod
    def from_center(
        cls,
        center_lat: float,
        center_lon: float,
        width_m: float,
        height_m: float,
        resolution_m: float,
        angle_deg: float = 0.0,
        name: Optional[str] = None,
    ) -> "Grid":
        """Create a rotated rectangular grid centred at a geographic point.

        Uses an azimuthal equidistant projection centred at (center_lat, center_lon)
        and rotates the domain by angle_deg clockwise from north. Useful for aligning
        a regional domain with a coastline feature — for example, placing one grid
        boundary perpendicular to an estuary mouth.

        Parameters
        ----------
        center_lat, center_lon : float
            Geographic centre of the domain in degrees.
        width_m, height_m : float
            Domain width (x) and height (y) in metres.
        resolution_m : float
            Grid resolution in metres.
        angle_deg : float, optional
            Clockwise rotation from north in degrees. Default 0 (north-up).
            Example: angle_deg=45 places the x-axis along a NE–SW estuary mouth.
        name : str, optional
            Name of the grid.

        Returns
        -------
        Grid
        """
        sg = ProjectedSupergrid.from_center(
            center_lat, center_lon, width_m, height_m, resolution_m, angle_deg
        )
        return Grid.from_supergrid_ds(sg.to_ds(), name=name)

    @classmethod
    def from_supergrid_file(cls, file_path: str, name: Optional[str] = None) -> "Grid":
        """Create a Grid instance from a supergrid file.

        Parameters
        ----------
        file_path : str
            Path to the supergrid file to be read
        name : str, optional
            Name of the new grid. If provided, it will be used as the name of the grid.
            If not provided, the name will be derived from the file name.

        Returns
        -------
        Grid
            The Grid instance created from the supergrid file.
        """
        ds = xr.open_dataset(file_path)
        name = (
            name or os.path.basename(file_path).replace(".nc", "")
            if os.path.basename(file_path).endswith(".nc")
            else os.path.basename(file_path)
        )
        return Grid.from_supergrid_ds(ds, name)

    @classmethod
    def from_esmf_mesh_file(
        cls, file_path: Union[str, xr.Dataset], name: Optional[str] = None
    ) -> "Grid":
        """Create a Grid instance from an ESMF mesh file.

        Parameters
        ----------
        file_path : str or xr.Dataset
            Path to the ESMF mesh file to be read, or an already-opened Dataset.
        name : str, optional
            Name of the new grid. If provided, it will be used as the name of the grid.
            If not provided, the name will be derived from the file name.

        Returns
        -------
        Grid
            The Grid instance created from the ESMF mesh file.
        """
        sg = SupergridBase.reconstruct_from_esmf_mesh(file_path)
        return Grid.from_supergrid_ds(sg.to_ds(), name)

    @classmethod
    def from_supergrid_ds(cls, ds: xr.Dataset, name: Optional[str] = None) -> "Grid":
        """Create a Grid instance from a supergrid file.

        Parameters
        ----------
        ds : xr.Dataset
            xarray Dataset of the supergrid file to be written
        name : str, optional
            Name of the new grid. If provided, it will be used as the name of the grid.

        Returns
        -------
        Grid
            The Grid instance created from the supergrid file.
        """

        # read supergrid dataset
        assert (
            ds.x.units == ds.y.units and "degree" in ds.x.units
        ), "Only degrees units are supported in supergrid files"

        # check supergrid
        Grid.check_supergrid(ds)

        srefine = 2  # supergrid refinement factor

        # create an initial Grid object:
        obj = cls(
            nx=int(len(ds.nx) / srefine),
            ny=int(len(ds.ny) / srefine),
            lenx=(ds.x.max() - ds.x.min()).item(),
            leny=(ds.y.max() - ds.y.min()).item(),
            cyclic_x=Grid.is_cyclic_x(ds),
            name=name,
        )

        obj.supergrid = SupergridBase.from_ds(ds)

        # update the MOM6 grid metrics based on the supergrid data
        obj._compute_MOM6_grid_metrics()

        return obj

    @classmethod
    @renamed_kwargs(path="file_path")
    def subgrid_from_supergrid(
        cls,
        file_path: str,
        llc: tuple[float, float],
        urc: tuple[float, float],
        name: str,
    ) -> "Grid":
        """Create a Grid instance from a subset of a supergrid file.

        Parameters
        ----------
        file_path : str
            Path to the full supergrid file to be carved out.
        llc : tuple[float, float]
            Lower left corner coordinates (lat, lon) of the subdomain to extract
        urc : tuple[float, float]
            Upper right corner coordinates (lat, lon) of the subset to extract
        name : str
            Name of the subgrid

        Returns
        -------
        Grid
            The Grid instance created from the supergrid file.
        """

        full_grid = cls.from_supergrid_file(file_path)

        assert len(llc) == 2, "llc must be a tuple of two floats"
        assert len(urc) == 2, "urc must be a tuple of two floats"

        # subgrid indices
        llc_j, llc_i = full_grid.get_indices(llc[0], llc[1])
        urc_j, urc_i = full_grid.get_indices(urc[0], urc[1])

        assert llc_j < urc_j, "Lower left corner must be below upper right corner"
        assert (
            llc_i < urc_i
        ), "Lower left corner must be to the left of upper right corner"

        # create a subgrid from the full grid
        subgrid = full_grid[llc_j:urc_j, llc_i:urc_i]
        subgrid.name = name
        return subgrid

    @property
    def supergrid(self) -> SupergridBase:
        """MOM6 supergrid contains the grid metrics and the areas at twice the
        nominal resolution (by default) of the actual computational grid."""
        return self._supergrid

    @property
    def lenx(self) -> float:
        """Length of the grid in the x-direction."""
        return self.supergrid.lenx

    @property
    def leny(self) -> float:
        """Length of the grid in the y-direction."""
        return self.supergrid.leny

    @supergrid.setter
    def supergrid(self, new_supergrid: SupergridBase) -> None:
        self._supergrid = new_supergrid
        self._compute_MOM6_grid_metrics()

    @property
    def nx(self):
        """Number of cells in x-direction."""
        return self.tlon.shape[1]

    @property
    def ny(self):
        """Number of cells in y-direction."""
        return self.tlon.shape[0]

    def _compute_MOM6_grid_metrics(self):
        """Compute the MOM6 grid metrics from the supergrid metrics. These
        include the tlon, tlat, ulon, ulat, vlon, vlat, qlon, qlat, dxt, dyt,
        dxCv, dyCu, dxCu, dyCv, angle, angle_q, and tarea."""

        sg = self._supergrid
        sg_units = sg.axis_units
        if sg_units == "m":
            sg_units = "meters"

        # T coords
        units = "degrees_east" if sg_units == "degrees" else sg_units
        self.tlon = xr.DataArray(
            sg.x[1::2, 1::2],
            dims=["ny", "nx"],
            attrs={"name": "array of t-grid longitudes", "units": units},
        )
        units = "degrees_north" if sg_units == "degrees" else sg_units
        self.tlat = xr.DataArray(
            sg.y[1::2, 1::2],
            dims=["ny", "nx"],
            attrs={"name": "array of t-grid latitudes", "units": units},
        )

        # U coords
        units = "degrees_east" if sg_units == "degrees" else sg_units
        self.ulon = xr.DataArray(
            sg.x[1::2, ::2],
            dims=["ny", "nxp"],
            attrs={"name": "array of u-grid longitudes", "units": units},
        )
        units = "degrees_north" if sg_units == "degrees" else sg_units
        self.ulat = xr.DataArray(
            sg.y[1::2, ::2],
            dims=["ny", "nxp"],
            attrs={"name": "array of u-grid latitudes", "units": units},
        )

        # V coords
        units = "degrees_east" if sg_units == "degrees" else sg_units
        self.vlon = xr.DataArray(
            sg.x[::2, 1::2],
            dims=["nyp", "nx"],
            attrs={"name": "array of v-grid longitudes", "units": units},
        )
        units = "degrees_north" if sg_units == "degrees" else sg_units
        self.vlat = xr.DataArray(
            sg.y[::2, 1::2],
            dims=["nyp", "nx"],
            attrs={"name": "array of v-grid latitudes", "units": units},
        )

        # Corner coords
        units = "degrees_east" if sg_units == "degrees" else sg_units
        self.qlon = xr.DataArray(
            sg.x[::2, ::2],
            dims=["nyp", "nxp"],
            attrs={"name": "array of q-grid longitudes", "units": units},
        )
        units = "degrees_north" if sg_units == "degrees" else sg_units
        self.qlat = xr.DataArray(
            sg.y[::2, ::2],
            dims=["nyp", "nxp"],
            attrs={"name": "array of q-grid latitudes", "units": units},
        )

        # x-distance between U points, centered at t
        self.dxt = xr.DataArray(
            sg.dx[1::2, ::2] + sg.dx[1::2, 1::2],
            dims=["ny", "nx"],
            attrs={
                "name": "x-distance between u-points, centered at t",
                "units": "meters",
            },
        )
        # y-distance between V points, centered at t
        self.dyt = xr.DataArray(
            sg.dy[::2, 1::2] + sg.dy[1::2, 1::2],
            dims=["ny", "nx"],
            attrs={
                "name": "y-distance between v-points, centered at t",
                "units": "meters",
            },
        )

        # x-distance between q points, centered at v
        self.dxCv = xr.DataArray(
            sg.dx[2::2, ::2] + sg.dx[2::2, 1::2],
            dims=["ny", "nx"],
            attrs={
                "name": "x-distance between q-points, centered at v",
                "units": "meters",
            },
        )

        # y-distance between q points, centered at u
        self.dyCu = xr.DataArray(
            sg.dy[::2, 2::2] + sg.dy[1::2, 2::2],
            dims=["ny", "nx"],
            attrs={
                "name": "y-distance between q-points, centered at u",
                "units": "meters",
            },
        )

        # x-distance between y points, centered at u"
        # East half of T(i) plus west half of T(i+1). The last column has no
        # T(i+1): on a cyclic grid it wraps to T(0)'s west half, otherwise it
        # repeats its own east half.
        east_half = sg.dx[1::2, 1::2]
        west_half_of_next = sg.dx[1::2, 2::2]  # T(1) .. T(nx-1)
        last = sg.dx[1::2, :1] if sg.is_cyclic_x else east_half[:, -1:]
        self.dxCu = xr.DataArray(
            east_half + np.concatenate([west_half_of_next, last], axis=1),
            dims=["ny", "nx"],
            attrs={
                "name": "x-distance between t-points, centered at u",
                "units": "meters",
            },
        )

        # y-distance between t points, centered at v"
        # North half of T(j) plus south half of T(j+1); the top row repeats its
        # own north half.
        north_half = sg.dy[1::2, 1::2]
        south_half_of_next = sg.dy[2::2, 1::2]  # T(1) .. T(ny-1)
        self.dyCv = xr.DataArray(
            north_half + np.concatenate([south_half_of_next, north_half[-1:]], axis=0),
            dims=["ny", "nx"],
            attrs={
                "name": "y-distance between t-points, centered at v",
                "units": "meters",
            },
        )

        # angle:
        self.angle = xr.DataArray(
            sg.angle_dx[1::2, 1::2],
            dims=["ny", "nx"],
            attrs={"name": "angle grid makes with latitude line", "units": "degrees"},
        )

        # q angle
        self.angle_q = xr.DataArray(
            sg.angle_dx[::2, ::2],
            dims=["nyp", "nxp"],
            attrs={"name": "angle q-grid makes with latitude line", "units": "degrees"},
        )
        # T area: each T-cell spans a 2x2 block of supergrid cells, so its area
        # is the block sum.
        self.tarea = xr.DataArray(
            sg.area.reshape(self.ny, 2, self.nx, 2).sum(axis=(1, 3)),
            dims=["ny", "nx"],
            attrs={"name": "area of t-cells", "units": "meters^2"},
        )

        # reset _kdtree such that it is recomputed when self.kdtree is accessed again
        self._kdtree = None

    def get_indices(self, tlat: float, tlon: float) -> tuple[int, int]:
        """
        Get the i, j indices of a given tlat and tlon pair.

        Parameters
        ----------
        tlat : float
            The latitude value.
        tlon : float
            The longitude value.

        Returns
        -------
        Tuple[int, int]
            The j, i indices of the given tlat and tlon pair.
        """

        max_tlon = self.tlon.max()
        min_tlon = self.tlon.min()

        # Try to adjust the longitude to the range of the grid (if possible)
        if tlon > max_tlon and (tlon - 360.0) > min_tlon:
            tlon -= 360.0
        elif tlon < min_tlon and (tlon + 360.0) < max_tlon:
            tlon += 360.0

        dist, indices = self.kdtree.query([tlat, tlon])
        j, i = np.unravel_index(indices, self.tlat.shape)
        return int(j), int(i)

    def plot(self, property_name):
        """
        Plot a given grid property using cartopy.
        Warning: cartopy module must be installed seperately

        Parameters
        ----------
        property_name : str
            The name of the grid property to plot, e.g., 'tlat'.
        """

        import matplotlib.pyplot as plt

        try:
            import cartopy.crs as ccrs
        except ImportError:
            print(
                "Cannot import the cartopy library, which is required to run this method."
            )
            return

        if property_name not in self.__dict__:
            print("ERROR: not a valid MOM6 grid property")
            return

        data = self.__dict__[property_name]

        # determine staggering
        if data.shape == self.tlon.shape:
            lons, lats = self.tlon, self.tlat
        elif data.shape == self.ulon.shape:
            lons, lats = self.ulon, self.ulat
        elif data.shape == self.vlon.shape:
            lons, lats = self.vlon, self.vlat
        elif data.shape == self.qlon.shape:
            lons, lats = self.qlon, self.qlat
        else:
            print("ERROR: cannot determine property staggering")
            return

        data = self.__dict__[property_name]

        fig = plt.figure()  # figsize=(10, 5))
        ax = fig.add_subplot(1, 1, 1, projection=ccrs.PlateCarree())
        ax.pcolormesh(
            lons,
            lats,
            data,
            transform=ccrs.PlateCarree(central_longitude=-180),
            cmap="nipy_spectral",
        )
        ax.gridlines(
            crs=ccrs.PlateCarree(),
            draw_labels=True,
            linewidth=2,
            color="gray",
            alpha=0.5,
            linestyle="--",
        )
        # ax.coastlines()
        ax.set_global()
        plt.show()

    def plot_cross_section(self, property_name, iy=None, ix=None):
        """
        Plot the cross-section of a given grid metric.

        Parameters
        ----------
        property_name : str
            The name of the grid property to plot, e.g., 'tlat'.
        iy: int
            y-index of the cross section
        ix: int
            x-inted of the cross section
        """

        import matplotlib.pyplot as plt

        assert (iy is None) or (ix is None), "Cannot provide both iy and ix"

        if property_name not in self.__dict__:
            print("ERROR: not a valid MOM6 grid property")
            return

        data = self.__dict__[property_name]

        # determine staggering
        if data.shape == self.tlon.shape:
            lons, lats = self.tlon, self.tlat
        elif data.shape == self.ulon.shape:
            lons, lats = self.ulon, self.ulat
        elif data.shape == self.vlon.shape:
            lons, lats = self.vlon, self.vlat
        elif data.shape == self.qlon.shape:
            lons, lats = self.qlon, self.qlat
        else:
            print("ERROR: cannot determine property staggering")
            return

        data = self.__dict__[property_name]

        fig, ax = plt.subplots()
        if iy:
            ax.set(xlabel="latitude", ylabel=property_name, title=property_name)
            ax.plot(lats[:, iy], data[:, iy])
        elif ix:
            ax.set(xlabel="longitude", ylabel=property_name, title=property_name)
            ax.plot(lons[ix, :], data[ix, :])
        ax.grid()

        fig.savefig("test.png")
        plt.show()

    def update_supergrid(self, xdat: np.array, ydat: np.array, grid_type=None) -> None:
        """
        Update the supergrid x and y coordinates. Running this method
        also updates the nominal grid coordinates and metrics.

        Parameters
        ----------
        xdat: np.array
            2-dimensional array of the new x coordinates.
        ydat: np.array
            2-dimensional array of the new y coordinates.
        grid_type: str
            The grid type of the passed in x and y arrays
        """

        # Keep the metric conventions the current supergrid was built with, so
        # that updating the coordinates of e.g. a projected grid does not
        # silently fall back to the smallangle default or the default radius.
        self.supergrid = SupergridBase._init_from_xy(
            xdat,
            ydat,
            grid_type,
            R=self.supergrid._R,
            dx_dy_calc_type=self.supergrid._dx_dy_calc_type,
        )

    def write_supergrid_file(
        self, file_path: str, author: Optional[str] = None
    ) -> xr.Dataset:
        """
        Write supergrid to a netcdf file. The supergrid file is to be read in by MOM6
        during runtime.

        Parameters
        ----------
        file_path: str
            Path to the supergrid file to be written.
        author: str, optional
            Name of the author. If provided, the name will appear in files as metadata.

        Returns
        -------
        xr.Dataset
            The supergrid dataset written to ``file_path``.
        """

        ds = self.supergrid.to_ds(name=self.name, author=author)
        ds.attrs["filename"] = os.path.basename(file_path)
        ds.to_netcdf(file_path, format="NETCDF3_64BIT")
        return ds

    # Deprecated names, kept for one release.
    @classmethod
    def from_supergrid(cls, path: str, name: Optional[str] = None):
        """Deprecated alias for :meth:`from_supergrid_file`."""
        warnings.warn(
            "Grid.from_supergrid() is deprecated; use Grid.from_supergrid_file(). "
            "It will be removed in a future release.",
            DeprecationWarning,
            stacklevel=2,
        )
        return cls.from_supergrid_file(path, name)

    @classmethod
    def from_esmf_mesh(cls, path: str, name: Optional[str] = None):
        """Deprecated alias for :meth:`from_esmf_mesh_file`."""
        warnings.warn(
            "Grid.from_esmf_mesh() is deprecated; use Grid.from_esmf_mesh_file(). "
            "It will be removed in a future release.",
            DeprecationWarning,
            stacklevel=2,
        )
        return cls.from_esmf_mesh_file(path, name)

    def write_supergrid(self, path: str, author: Optional[str] = None):
        """Deprecated alias for :meth:`write_supergrid_file`."""
        warnings.warn(
            "Grid.write_supergrid() is deprecated; use Grid.write_supergrid_file(). "
            "It will be removed in a future release.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.write_supergrid_file(path, author)

    def get_esmf_ready_tracer_ds(self):
        """This is to generate a ds that esmf/xesmf can use for regridding. It contains the tlat and tlon coordinates and the area variable (tarea) that can be used as weights for conservative regridding."""
        ds = xr.Dataset(
            {
                "lat": self.tlat,
                "lon": self.tlon,
                "tarea": self.tarea,
            }
        )
        ds.lon.attrs["units"] = "degrees_east"
        ds.lon.attrs["_FillValue"] = 1e20
        ds.lat.attrs["units"] = "degrees_north"
        ds.lat.attrs["_FillValue"] = 1e20
        ds = ds.set_coords(["lat", "lon"])
        return ds
