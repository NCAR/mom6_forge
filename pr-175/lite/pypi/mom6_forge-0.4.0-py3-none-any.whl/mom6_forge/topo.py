import os
import copy
import warnings
import numpy as np
import xarray as xr
from datetime import datetime
from typing import Optional
from scipy import interpolate
from scipy.ndimage import label, binary_fill_holes
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
from scipy.spatial import cKDTree
from mom6_forge.utils import (
    cell_area_rad,
    iterative_fill,
    compute_subsampling_factor,
    renamed_kwargs,
)
from mom6_forge.grid import Grid
from mom6_forge.git_utils import get_domain_dir, get_repo
from pathlib import Path
from mom6_forge.edit_command import *
from mom6_forge.command_manager import TopoCommandManager, CommandType
from mom6_forge._source_bathy import SourceBathy
from mom6_forge.channel_width import ChannelWidthList
from mom6_forge._supergrid import haversine, _DEFAULT_RADIUS
from mom6_forge._supergrid import _DEFAULT_RADIUS, SupergridBase

VALID_MASK_METHODS = ("naturalearth", "ocean_frac", "dataset", "manual")
VALID_DEPTH_METHODS = ("stats", "cressman", "xesmf")

# WW3 spectral discretization written into ww3_grid.inp.
WW3_NK = 25  # number of frequencies (wavenumbers)
WW3_NTH = 24  # number of directions
WW3_F1 = 0.04118  # lowest frequency [Hz]
WW3_FREQ_FACTOR = 1.1  # frequency increment factor
WW3_CFL_SAFETY = 0.8  # fraction of the CFL limit to actually use
WW3_MAX_DT_RATIO = 4  # most propagation sub-steps to take per global step
# Wavenumbers of the partitioned surface Stokes drift bands WW3 sends.
# TODO: MOM6 applies its own copy of these (SURFBAND_WAVENUMBERS in CESM's
# MOM_input.yaml) to the bands that arrive and never sees the list below, so if
# CESM retunes them this one goes stale with no error anywhere -- just a wrong
# Stokes profile. Read them off the CESM in use instead of keeping a copy.
WW3_STOKES_WAVENUMBERS = (0.04, 0.11, 0.33)  # [rad m-1]
# Sea-ice dissipation method (IC4), as in CESM's own WW3 grids
# (grid_inp.wgx3v7.260527): the Meylan, Horvat & Bitz (2021) fit in ice
# thickness and floe size. Without it WW3 uses method 1, an empirical fit whose
# first coefficient the CESM cap fills with the ice thickness.
WW3_IC4_METHOD = 10
_GRAVITY = 9.81  # [m s-2]


def ww3_timesteps_from_spacing(
    min_dx,
    cpl_dt,
    f_min=WW3_F1,
    safety=WW3_CFL_SAFETY,
    max_ratio=WW3_MAX_DT_RATIO,
):
    """WW3 time steps (seconds) for a grid whose smallest cell is ``min_dx`` meters.

    Two constraints set the steps:

    * ``dtcfl`` bounds x-y propagation: ``dtcfl <= min_dx / Cg``.
    * ``dtmax`` is the global step, over which propagation and the source terms
      are applied in sequence. ``dtmax`` is chosen as the largest whole-second
      divisor of ``cpl_dt`` that ``max_ratio`` or fewer propagation sub-steps
      can cover, so WW3 still lands on the coupling time without a short final
      step. CIME's ww3 buildnml rejects a ``dtmax`` whose integer part does
      not divide the coupling interval.

    ``dtcfl`` is also kept to a whole number of seconds that divides ``dtmax``.
    WW3 takes ``ceil(dtmax / dtcfl)`` sub-steps, so a fractional ``dtcfl``
    rounded down when it is written out would add a sub-step.

    Parameters
    ----------
    min_dx: float
        Smallest grid spacing in meters.
    cpl_dt: float
        Wave coupling interval in seconds (WAV_NCPL), a whole number.
    f_min: float, optional
        Lowest frequency in the spectrum [Hz].
    safety: float, optional
        Fraction of the bare CFL limit to use.
    max_ratio: int, optional
        Most propagation sub-steps per global step.

    Returns
    -------
    dict
        ``dtmax``, ``dtcfl``, ``dtcfli``, ``dtmin`` in seconds.
    """
    if min_dx <= 0:
        raise ValueError(f"min_dx must be positive, got {min_dx}")
    if cpl_dt <= 0:
        raise ValueError(f"cpl_dt must be positive, got {cpl_dt}")
    if cpl_dt != int(cpl_dt):
        raise ValueError(f"cpl_dt must be a whole number of seconds, got {cpl_dt}")
    if max_ratio < 1:
        raise ValueError(f"max_ratio must be at least 1, got {max_ratio}")

    cg_max = _GRAVITY / (4.0 * np.pi * f_min)  # deep-water group velocity [m/s]
    dtcfl_limit = safety * min_dx / cg_max

    # Split the coupling interval into n_global equal whole-second steps, taking
    # the fewest that max_ratio or fewer whole-second sub-steps can cover.
    cpl_dt = int(cpl_dt)
    for n_global in range(1, cpl_dt + 1):
        if cpl_dt % n_global:
            continue
        dtmax = cpl_dt // n_global
        n_sub = next(
            (
                n
                for n in range(1, max_ratio + 1)
                if dtmax % n == 0 and dtmax // n <= dtcfl_limit
            ),
            None,
        )
        if n_sub is not None:
            break
    else:
        raise ValueError(
            f"The smallest cell ({min_dx:.1f} m) needs a WW3 propagation step "
            f"under 1 s (limit {dtcfl_limit:.3f} s), which CESM cannot run."
        )
    dtcfl = dtmax // n_sub

    return {
        "dtmax": float(dtmax),
        "dtcfl": float(dtcfl),
        "dtcfli": float(dtcfl),
        "dtmin": float(min(10.0, dtcfl / 10.0)),
    }


def _number(edit, key):
    """edit[key] as a float, else a ValueError that names the edit and the field."""
    try:
        return float(edit[key])
    except (TypeError, ValueError):
        raise ValueError(
            f"{edit.get('op')!r} edit needs a number for {key!r}, got {edit[key]!r}."
        ) from None


class Topo:
    """
    Bathymetry Generator for MOM6 grids (mom6_forge.grid.Grid).
    """

    def __init__(
        self,
        grid,
        min_depth,
        channel_widths=None,
        version_control_dir="TopoLibrary",
        git=False,
    ):
        """
        MOM6 Simpler Models bathymetry constructor.

        Parameters
        ----------
        grid: mom6_forge.grid.Grid
            horizontal grid instance for which the bathymetry is to be created.
        min_depth: float
            Minimum water column depth. Columns with shallow depths are to be masked out.
        channel_widths: str | Path | ChannelWidthList, optional
            Channel width constraints. Can be a filepath to load from, a ChannelWidthList object, or None.
        version_control_dir: str, optional
            Directory in which to store version-controlled bathymetry data. Defaults to
            "TopoLibrary". Ignored if git is False.
        git: bool, optional
            If True, record every edit in a git repository under version_control_dir,
            which enables undo, redo, reset, branches and tags. If False (default),
            edits apply directly with no history and nothing is written to disk.
            TopoEditor works either way; without git it has no undo or redo.
        """

        self._grid = grid
        self._depth = xr.DataArray(
            np.full((grid.ny, grid.nx), np.nan, dtype=float),
            dims=["ny", "nx"],
            attrs={"units": "m"},
        )  # Initialize raw depth with NaNs
        self._user_mask: Optional[xr.DataArray] = (
            None  # Binary ocean/land mask (None = no mask applied)
        )
        self._min_depth = min_depth
        self._src = None  # SourceBathy object; set by set_src()
        self.land_fillval = 0.0  # Depth value for land cells
        initial_command = MinDepthEditCommand(
            self, attr="min_depth", new_value=min_depth
        )

        # Initialize channel widths
        if channel_widths is None:
            self.channel_widths = ChannelWidthList()
        elif isinstance(channel_widths, ChannelWidthList):
            self.channel_widths = channel_widths
        else:
            # Assume it's a filepath
            self.channel_widths = ChannelWidthList(filepath=channel_widths)

        if git:
            self._start_version_control(version_control_dir)
            self.apply_edit(initial_command)
        else:
            self.tcm = None
            # Apply the initial min_depth command directly without git recording
            initial_command()

    def _start_version_control(self, version_control_dir):
        """Open (or create) the git edit history for this grid under version_control_dir."""
        # Create a folder to store bathymetry objects in
        Path(version_control_dir).mkdir(exist_ok=True)
        (Path(version_control_dir) / ".gitignore").write_text("*")

        # Create the subfolder for this specific bathymetry
        self.domain_dir = Path(get_domain_dir(self._grid, base_dir=version_control_dir))
        self.domain_dir.mkdir(exist_ok=True)

        # Save the grid info there (there can only be 1 grid per bathymetry)
        self.grid_file_path = self.domain_dir / "grid.nc"
        self._grid.write_supergrid_file(self.grid_file_path)

        # Initialize the git repo and the TCM (requires that self.domain_dir exists)
        self.repo = get_repo(self.domain_dir)
        self.tcm = TopoCommandManager(self, command_registry=COMMAND_REGISTRY)

    def __getitem__(self, slices):
        """
        Get a subgrid copy based on the provided slices.

        Parameters
        ----------
        slices:
            A tuple of two slices, e.g., [A:B:C, D:E:F]
            The first slice A:B:C corresponds to the j-axis (y-axis) and the second
            slice D:E:F corresponds to the i-axis (x-axis). Examples:
            topo[0:10, 0:20] or topo[:, 0:20] or topo[0:10, :].

        Returns
        -------
        topo: Topo
            A new Topo object with the same grid but with the depth and grid subsetted according to the provided slices.
        """

        new_grid = self._grid[slices]
        new_topo = Topo(
            new_grid,
            self._min_depth,
            git=self.has_version_control,
            channel_widths=copy.deepcopy(self.channel_widths),
        )  # Create new topo with the same version control setting
        if self._depth is not None:
            new_topo._depth = self._depth[slices]
        return new_topo

    @classmethod
    def from_version_control(cls, folder_path: str | Path, channel_widths=None):
        """
        Create a bathymetry object from an existing version-controlled bathymetry folder.

        Parameters
        ----------
        folder_path: str | Path
            Path to an existing bathymetry folder created by mom6_forge with version control enabled.
        channel_widths: str | Path | ChannelWidthList, optional
            Channel width constraints. Can be a filepath to load from, a ChannelWidthList object, or None.
        """

        folder_path = Path(folder_path)
        assert folder_path.exists(), f"Cannot find bathymetry folder at {folder_path}."

        grid_file_path = folder_path / "grid.nc"
        assert grid_file_path.exists(), f"Cannot find grid file at {grid_file_path}."

        grid = Grid.from_supergrid_file(grid_file_path)

        # Build without git so loading adds nothing to the history, then attach the
        # history (the grid hash selects this folder) and replay it, min_depth included.
        topo = Topo(grid, 0.0, channel_widths=channel_widths)
        topo._start_version_control(folder_path.parent)
        topo.tcm.reapply_changes()
        return topo

    @classmethod
    @renamed_kwargs(topo_file_path="file_path")
    def from_topo_file(
        cls,
        grid,
        file_path,
        min_depth=0.0,
        varname="depth",
        version_control_dir="TopoLibrary",
        git=False,
        channel_widths=None,
    ):
        """
        Create a bathymetry object from an existing topog file.

        Parameters
        ----------
        grid: mom6_forge.grid.Grid
            horizontal grid instance for which the bathymetry is to be created.
        file_path: str
            Path to an existing MOM6 topog file.
        min_depth: float, optional
            Minimum water column depth (m). Columns with shallower depths are to be masked out.
        varname : str, optional
            Name of the variable representing ocean depth in the dataset. Default is "depth".
        git: bool, optional
            Passed through to Topo.__init__. See Topo docstring for details.
        version_control_dir: str, optional
            Directory for version control. Default is "TopoLibrary".
        channel_widths: str | Path | ChannelWidthList, optional
            Channel width constraints. Can be a filepath to load from, a ChannelWidthList object, or None.
        """

        topo = cls(
            grid,
            min_depth,
            version_control_dir=version_control_dir,
            channel_widths=channel_widths,
            git=git,
        )
        if topo.tcm is not None:
            topo.tcm.reapply_changes()
        topo.set_depth_via_topog_file(file_path, varname)
        return topo

    @classmethod
    def from_esmf_mesh_file(
        cls,
        file_path,
        radius=_DEFAULT_RADIUS,
        min_depth=0.0,
        version_control_dir="TopoLibrary",
        git=False,
    ):
        """
        Construct a topo object from the ESMF mesh + Mask, there is no depth associated with this

        Parameters
        ----------
        file_path: str or xr.Dataset
            Path to ESMF mesh file to read, or an already-opened Dataset.
        radius: float, optional
            Radius of the Earth (m). Default is _DEFAULT_RADIUS.
        min_depth: float, optional
            Minimum water column depth (m). Columns with shallower depths are to be masked out. Default is 0.0.
        git: bool, optional
            Passed through to Topo.__init__. See Topo docstring for details. Default is False.
        """

        supergrid, mask = SupergridBase.reconstruct_from_esmf_mesh(
            file_path, radius, return_mask=True
        )
        grid = Grid.from_supergrid_ds(supergrid.to_ds())
        topo = cls(grid, min_depth, version_control_dir=version_control_dir, git=git)
        topo.user_mask = mask
        return topo

    @property
    def masked_depth(self):
        """
        Computed depth array with masking applied (m). Positive below MSL.

        This is a computed property that applies land/ocean masking on-the-fly. When a user mask is set,
        returns masked depth: ocean cells enforced to at least min_depth+0.1, land cells set to _land_fillval.
        When mask is None, derives mask from raw depth (cells > min_depth are ocean).

        Note: Index-based assignment like `topo.masked_depth[j, i] = value` will not persist because
        this property is computed on-the-fly. To modify depth, use `topo.depth = new_array` or `topo.edit_depth()`.
        """

        # Enforce minimum depth criteria for ocean cells: if depth ≤ min_depth and mask is ocean, set to min_depth + 0.1 to ensure they are still treated as ocean. If mask is land and depth > min_depth, set to _land_fillval to ensure they are treated as land.
        masked_depth = xr.where(
            self.tmask,
            xr.where(
                self._depth > self._min_depth,
                self._depth,
                self._min_depth + 0.1,
            ),
            self._land_fillval,  # Land cells to _land_fillval
        )
        masked_depth = masked_depth.fillna(0)
        return masked_depth

    @property
    def src(self):
        """
        SourceBathy object representing the source bathymetry dataset sliced to the topo grid extent. This is set by set_src() when a new source bathymetry is specified, and can be accessed for any source dataset.
        """
        return self._src

    @src.setter
    def src(self, new_src):
        self._src = new_src

    @property
    def depth(self):
        return self._depth

    @property
    def has_version_control(self):
        return self.tcm is not None

    @depth.setter
    def depth(self, depth):
        """
        Set raw depth array. Preserves existing mask.

        Parameters
        ----------
        depth: np.array or xr.DataArray
            2-D Array of ocean depth (m).
        """
        if isinstance(depth, xr.DataArray):
            depth = depth.data
        else:
            assert isinstance(
                depth, np.ndarray
            ), "depth_raw must be a numpy array or xarray DataArray"

        assert depth.shape == (
            self._grid.ny,
            self._grid.nx,
        ), "Incompatible depth array shape"

        self.send_entire_depth_change_to_tcm(depth)

    @property
    def min_depth(self):
        """
        Minimum water column depth. Columns with shallow depths are to be masked out.
        """
        return self._min_depth

    @property
    def max_depth(self):
        """
        Maximum water column depth.
        """
        return self.depth.max().item()

    @min_depth.setter
    def min_depth(self, new_min_depth):
        self._min_depth = new_min_depth

    @property
    def land_fillval(self):
        """
        Depth value assigned to land cells when mask is applied. Default is 0.0 (dry).
        """
        return self._land_fillval

    @land_fillval.setter
    def land_fillval(self, new_land_fillval):
        assert isinstance(
            new_land_fillval, (int, float)
        ), "land_fillval must be a number"
        assert (
            new_land_fillval <= self._min_depth
        ), "land_fillval should be less than or equal to min_depth to ensure land cells are not mistakenly treated as ocean"
        self._land_fillval = float(new_land_fillval)

    @property
    def user_mask(self):
        """
        Optional binary ocean/land mask. 1 if ocean, 0 if land.
        When set, the depth property applies masking: ocean cells enforced greater than min_depth+0.1, land cells set to _land_fillval.
        """
        return self._user_mask

    @user_mask.setter
    def user_mask(self, new_mask):
        """
        Set the binary ocean/land mask.

        Parameters
        ----------
        new_mask: xr.DataArray or np.ndarray or None
            Binary mask (1=ocean, 0=land) with shape (ny, nx), or None to disable masking.
        """
        if new_mask is None:
            self.clear_user_mask()  # Clear the manual mask if None is passed
            return

        if isinstance(new_mask, xr.DataArray):
            new_mask = new_mask.data
        else:
            assert isinstance(
                new_mask, np.ndarray
            ), "mask must be a numpy array, xarray DataArray, or None"

        assert new_mask.shape == (
            self._grid.ny,
            self._grid.nx,
        ), "Incompatible mask shape"

        all_indices = list(np.ndindex(new_mask.shape))
        new_values = new_mask.ravel().tolist()
        old_values = (
            self.tmask.values.ravel().tolist()
        )  # effective mask (manual or raw depth mask)

        cmd = MaskEditCommand(
            self, all_indices, new_values, old_values=old_values, message="Set mask"
        )
        self.apply_edit(cmd)

    @property
    def tmask(self):
        """
        Ocean domain mask at T grid. 1 if ocean, 0 if land.

        This is a derived mask computed from the depth property. The computation depends on whether
        a user mask has been set:

        - If _user_mask is None: Returns a mask derived from raw depth (_depth).
          Cells with depth > min_depth are marked as ocean (1), otherwise land (0).
        - If _user_mask is set: Returns a mask set by the user. The depth property will apply this mask to the raw depth, ensuring that ocean cells are at least min_depth+0.1 and land cells are set to 0.

        This design means tmask is always consistent with the current depth state, whether
        driven by raw bathymetry or by a manually applied mask.
        """

        if self._user_mask is None:
            return self._compute_tmask_from_raw_depth()
        else:
            return self.user_mask

    def _compute_tmask_from_raw_depth(self):
        """
        If no user_mask is calculated, tmask is derived directly from raw depth: ocean (1) where depth > min_depth, else land (0).
        This is a separate helper to keep the logic clear and maintainable, it is only used if the user mask is not set (which may be the case for many users who just want to set depth and have the mask be automatically derived from it).
        """
        tmask_da = xr.DataArray(
            np.where(self._depth > self._min_depth, 1, 0),
            dims=["ny", "nx"],
            attrs={"name": "T mask"},
        )
        return tmask_da

    @property
    def umask(self):
        """
        Ocean domain mask on U grid. 1 if ocean, 0 if land.
        """
        tmask = self.tmask

        # Create empty mask DataArray for umask
        umask = xr.DataArray(
            np.ones(self._grid.ulat.shape, dtype=int),
            dims=["yh", "xq"],
            attrs={"name": "U mask"},
        )

        # Fill umask with mask values
        umask[:, :-1] &= tmask.values  # h-point translates to the left u-point
        umask[:, 1:] &= tmask.values  # h-point translates to the right u-point

        return umask

    @property
    def vmask(self):
        """
        Ocean domain mask on V grid. 1 if ocean, 0 if land.
        """
        tmask = self.tmask

        # Create empty mask DataArray for umask
        vmask = xr.DataArray(
            np.ones(self._grid.vlat.shape, dtype=int),
            dims=["yq", "xh"],
            attrs={"name": "V mask"},
        )

        # Fill vmask with mask values
        vmask[:-1, :] &= tmask.values  # h-point translates to the bottom v-point
        vmask[1:, :] &= tmask.values  # h-point translates to the top v-point

        return vmask

    @property
    def qmask(self):
        """
        Ocean domain mask on Q grid. 1 if ocean, 0 if land.
        """
        tmask = self.tmask

        # Create empty mask DataArray for umask
        qmask = xr.DataArray(
            np.ones(self._grid.qlat.shape, dtype=int),
            dims=["yq", "xq"],
            attrs={"name": "Q mask"},
        )

        # Fill qmask with mask values
        qmask[:-1, :-1] &= tmask.values  # top-left of h goes to top-left q
        qmask[:-1, 1:] &= tmask.values  # top-right
        qmask[1:, :-1] &= tmask.values  # bottom-left
        qmask[1:, 1:] &= tmask.values  # bottom-right

        # Corners of the qmask are always land -> regional cases
        qmask[0, 0] = 0
        qmask[0, -1] = 0
        qmask[-1, 0] = 0
        qmask[-1, -1] = 0

        return qmask

    @property
    def basintmask(self):
        """
        Ocean domain mask at T grid. Seperate number for each connected water cell, 0 if land.

        Labels are contiguous, starting at 1, and the basin of greatest total area
        carries the highest label. The remaining labels are in no particular order.

        On a zonally periodic grid (cyclic_x), the components touching the i=0 and
        i=nx-1 columns of a common row are merged, so a basin straddling the seam is
        labeled once rather than twice.
        """
        res, num_features = label(self.tmask)

        if num_features > 1:
            if self._grid.cyclic_x:
                res = self._merge_basins_across_cyclic_seam(res, num_features)
            res = self._promote_largest_basin(res)

        return xr.DataArray(res)

    def _promote_largest_basin(self, basins):
        """
        Relabel so that the basin of greatest total area carries the highest label.

        Only that one label moves: it trades places with whichever basin holds the
        highest label, leaving every other basin where it is. Land stays 0.
        """
        areas = np.bincount(basins.ravel(), weights=self._grid.tarea.data.ravel())
        areas[0] = 0.0  # land is not a basin, so it can never be the largest
        largest = int(np.argmax(areas))
        highest = areas.size - 1  # labels are contiguous, so this is the last one

        if largest == highest:
            return basins  # already there, no relabeling needed

        swap = np.arange(areas.size, dtype=basins.dtype)
        swap[[largest, highest]] = [highest, largest]
        return swap[basins]

    @staticmethod
    def _merge_basins_across_cyclic_seam(basins, num_features):
        """
        Give a common label to the basins that meet across the i=0 / i=nx-1 seam.

        Takes the labels from scipy.ndimage.label and treats each ocean pair at the
        two ends of a row as an edge between their labels, so the connected components
        of that graph are the basins of the periodic domain. Land is label 0 and has
        no edges, so it stays 0, and the merged labels come back contiguous.
        """
        west, east = basins[:, 0], basins[:, -1]
        seam = (west > 0) & (east > 0)
        joined = coo_matrix(
            (np.ones(seam.sum()), (west[seam], east[seam])),
            shape=(num_features + 1, num_features + 1),
        )
        _, merged = connected_components(joined, directed=False)
        return merged[basins]

    @property
    def supergridmask(self):
        """
        Ocean domain mask on supergrid. 1 if ocean, 0 if land.
        """

        supergridmask = xr.DataArray(
            np.zeros(self._grid._supergrid.x.shape, dtype=int),
            dims=["nyp", "nxp"],
            attrs={"name": "supergrid mask"},
        )
        supergridmask[::2, ::2] = self.qmask.values
        supergridmask[::2, 1::2] = self.vmask.values
        supergridmask[1::2, ::2] = self.umask.values
        supergridmask[1::2, 1::2] = self.tmask.values
        return supergridmask

    def apply_edit(self, cmd, skip_version_control=False, cmd_type=CommandType.COMMAND):
        """Apply an edit command aware of version control. If version control is enabled, the command is executed through the TopoCommandManager (TCM) to ensure it is recorded in the version history and can be undone/redone.
        If version control is disabled, the command is executed directly without recording.

        Parameters
        -----------
        cmd: Command
            The command to be applied.
        skip_version_control: bool
            If True, the command will be executed without recording in version control even if version control is enabled. This can be useful for programmatic changes that should not be part of the user-facing version history.
        cmd_type: CommandType
            The type of the command, used for version control categorization. Ignored if skip_version_control is True or if version control is disabled.
        """
        if skip_version_control or not self.has_version_control:
            cmd()
        else:
            self.tcm.execute(cmd, cmd_type=cmd_type)

    @property
    def can_undo(self):
        """True if there is an edit to undo. Always False without git."""
        return self.has_version_control and self.tcm.undo(check_only=True)

    @property
    def can_redo(self):
        """True if there is an undone edit to redo. Always False without git."""
        return self.has_version_control and self.tcm.redo(check_only=True)

    def undo(self):
        """Undo the latest edit. Returns the (n, 2) array of (j, i) cells that changed."""
        return self._history_step("undo")

    def redo(self):
        """Redo the latest undone edit. Returns the (n, 2) array of (j, i) cells that changed."""
        return self._history_step("redo")

    def reset(self):
        """
        Undo the edits made since the bathymetry was last set as a whole (set_flat,
        set_from_dataset, a full user_mask, ...). Recorded in git, so it survives a
        reload and can be redone. Returns the (n, 2) array of (j, i) cells that changed.
        """
        return self._history_step("reset")

    def _history_step(self, name):
        """Run tcm.undo, tcm.redo or tcm.reset and return the (j, i) cells it changed."""
        if not self.has_version_control:
            raise RuntimeError(
                "This Topo has no edit history; create it with git=True to undo, redo or reset."
            )
        before = self._cell_state()
        getattr(self.tcm, name)()
        return self._cells_changed_since(before)

    def apply_edits(self, edits):
        """
        Apply a list of JSON-able edits in order, each one history step when git is on.

        cells are (n, 2) (j, i) pairs. The ops are:
            {"op": "depth", "cells": cells, "value": float}   set depth (m, positive down)
            {"op": "land", "cells": cells}                     manual mask -> land
            {"op": "ocean", "cells": cells}                    manual mask -> ocean
            {"op": "clear_mask"}                               clear the manual mask
            {"op": "min_depth", "value": float}
            {"op": "fill_from_stats", "cells": cells, "statistic": "mean" | "max" | "min"}
            {"op": "erase_selected_basin", "cell": [j, i]}
            {"op": "erase_disconnected_basin", "cell": [j, i]}

        Every edit is checked before any is applied; a bad one raises ValueError. An
        edit that changes nothing is skipped and adds no history step.

        Returns the (n, 2) int array of (j, i) cells whose depth or mask changed.
        """
        steps = [self._edit_step(edit) for edit in edits]
        before = self._cell_state()
        for step in steps:
            step()
        return self._cells_changed_since(before)

    def _edit_step(self, edit):
        """Check one apply_edits dict and return a function that applies it."""
        op = edit.get("op")
        try:
            if op == "depth":
                cells, value = self._checked_cells(edit["cells"]), _number(
                    edit, "value"
                )
                return lambda: self._edit_cells(
                    DepthEditCommand, cells, self._depth.values, value
                )
            if op in ("land", "ocean"):
                cells, value = self._checked_cells(edit["cells"]), int(op == "ocean")
                return lambda: self._edit_cells(
                    MaskEditCommand, cells, self.tmask.values, value
                )
            if op == "clear_mask":

                def clear_mask():
                    if self._user_mask is not None:
                        self.clear_user_mask()

                return clear_mask
            if op == "min_depth":
                value = _number(edit, "value")

                def set_min_depth():
                    if value != self.min_depth:
                        self.apply_edit(MinDepthEditCommand(self, "min_depth", value))

                return set_min_depth
            if op == "fill_from_stats":
                cells, statistic = self._checked_cells(edit["cells"]), edit["statistic"]
                if self.stats is None:
                    raise ValueError(
                        "fill_from_stats needs topo.stats; call set_src and compute_stats first."
                    )
                if statistic not in ("mean", "max", "min"):
                    raise ValueError(
                        f"statistic must be 'mean', 'max' or 'min', not {statistic!r}."
                    )
                stat = self.stats[f"D_{statistic}"].values[cells[:, 0], cells[:, 1]]
                has_data = np.isfinite(stat)  # cells without source data are left alone
                return lambda: self._edit_cells(
                    DepthEditCommand,
                    cells[has_data],
                    self._depth.values,
                    stat[has_data],
                )
            if op in ("erase_selected_basin", "erase_disconnected_basin"):
                j, i = self._checked_cells([edit["cell"]])[0]
                return lambda: getattr(self, op)(i=int(i), j=int(j))
        except KeyError as missing:
            raise ValueError(
                f"{op!r} edit is missing the {missing} field: {edit}"
            ) from None
        raise ValueError(
            f"Unknown edit op {op!r}; expected one of depth, land, ocean, clear_mask, "
            "min_depth, fill_from_stats, erase_selected_basin, erase_disconnected_basin."
        )

    def _checked_cells(self, cells):
        """cells as an (n, 2) int array of (j, i) on this grid, else ValueError."""
        cells = np.asarray(cells)
        if cells.size == 0:
            return np.empty((0, 2), dtype=int)
        if (
            cells.ndim != 2
            or cells.shape[1] != 2
            or not np.issubdtype(cells.dtype, np.integer)
        ):
            raise ValueError(
                f"cells must be an (n, 2) array of integer (j, i) pairs, "
                f"got shape {cells.shape} and dtype {cells.dtype}."
            )
        off_grid = cells[((cells < 0) | (cells >= self._depth.shape)).any(axis=1)]
        if len(off_grid):
            raise ValueError(
                f"cells {off_grid[:5].tolist()} are off the (ny, nx) = "
                f"{self._depth.shape} grid."
            )
        return cells

    def _edit_cells(self, command, cells, current, new):
        """Apply a depth or mask command to the cells whose value changes, if any do."""
        new = np.broadcast_to(new, len(cells))
        old = current[cells[:, 0], cells[:, 1]]
        changed = old != new
        if changed.any():
            self.apply_edit(
                command(self, cells[changed], new[changed], old_values=old[changed])
            )

    def _cell_state(self):
        """Raw depth, masked depth and mask of every cell, stacked into one array."""
        return np.stack(
            [self._depth.values, self.masked_depth.values, self.tmask.values]
        )

    def _cells_changed_since(self, before):
        """(n, 2) int array of the (j, i) cells whose _cell_state differs from before."""
        after = self._cell_state()
        same = (before == after) | (np.isnan(before) & np.isnan(after))
        return np.argwhere(~same.all(axis=0))

    def set_src(
        self,
        bathymetry_path,
        longitude_coordinate_name,
        latitude_coordinate_name,
        vertical_coordinate_name,
        is_input_positive_below_msl=False,
        buf=0.5,
    ):
        """Set a :class:`SourceBathy` into a class object called src"""
        self.src = SourceBathy(
            self,
            Path(bathymetry_path),
            longitude_coordinate_name,
            latitude_coordinate_name,
            vertical_coordinate_name,
            is_input_positive_below_msl=is_input_positive_below_msl,
            buf=buf,
        )
        return self.src

    @property
    def stats(self):
        return self.src.stats if self.src is not None else None

    def clear_user_mask(self):
        cmd = ClearMaskCommand(
            self, message="Clear manual mask"
        )  # Resets back to reading from depth
        self.apply_edit(cmd)

    def point_is_ocean(self, lons, lats):
        """
        Given a list of coordinates, return a list of booleans indicating if the coordinates are in the ocean (True) or land (False)
        """
        assert len(lons) == len(
            lats
        ), "Lons & Lats must be the same length, they describe a set of points"

        is_ocean = []
        for i in range(len(lons)):
            match = np.where(
                (self._grid._supergrid.x == lons[i])
                & (self._grid._supergrid.y == lats[i])
            )
            is_ocean.append(self.supergridmask[match[0], match[1]].item())
        return is_ocean

    def send_entire_depth_change_to_tcm(self, depth, skip_version_control=False):
        """
        This function takes an entire depth change and adds it through the TopoCommandManager (TCM) or directly if skip_version_control is enabled.
        Modifies _depth, preserves mask.
        """
        # 1. Generate all affected indices (row-major order)
        all_indices = list(np.ndindex(self._depth.shape))  # list of (j, i) tuples

        # 2. Flatten the new values to match the indices
        if type(depth) == xr.DataArray:
            depth = depth.data
        new_values = depth.ravel().tolist()

        # 3. Flatten old values from raw depth
        old_values = (
            self._depth.values.ravel().tolist() if self._depth is not None else None
        )

        # 4. Build command
        depth_edit_command = DepthEditCommand(
            self, all_indices, new_values, old_values=old_values
        )

        self.apply_edit(depth_edit_command, skip_version_control=skip_version_control)

    def edit_depth(self, indices, values):
        """
        Edit depth at specific indices with version control.

        Parameters
        ----------
        indices : list of tuples
            List of (j, i) indices to modify.
        values : list or array-like
            New depth values for each index.
        """
        # Convert single index to list of indices
        if isinstance(indices, tuple):
            indices = [indices]

        # Get old values
        old_values = [self._depth.values[j, i] for j, i in indices]

        # Create and execute command
        cmd = DepthEditCommand(self, indices, values, old_values=old_values)
        self.apply_edit(cmd)

    def set_flat(self, D):
        """
        Create a flat bottom bathymetry with a given depth D.

        Parameters
        ----------
        D: float
            Bathymetric depth of the flat bottom to be generated.
        """

        depth = xr.DataArray(
            np.full((self._grid.ny, self._grid.nx), D),
            dims=["ny", "nx"],
            attrs={"units": "m"},
        )

        # Save to object
        self.send_entire_depth_change_to_tcm(depth)

    @renamed_kwargs(topog_file_path="file_path")
    def set_depth_via_topog_file(
        self, file_path, varname="depth", skip_version_control=False
    ):
        """
        Apply a bathymetry read from an existing topog file

        Parameters
        ----------
        file_path: str
            absolute path to an existing MOM6 topog file
        varname : str
            Name of the variable representing ocean depth in the dataset.
        """

        assert os.path.exists(file_path), f"Cannot find topog file at {file_path}."

        ds_topo = xr.open_dataset(file_path)
        assert (
            varname in ds_topo
        ), f"Cannot find the '{varname}' field in topog file {file_path}"
        depth = ds_topo[varname]

        if depth.shape[0] < self._grid.ny or depth.shape[1] < self._grid.nx:
            raise ValueError(
                f"Topography data in {file_path} is smaller than the grid size "
                f"({depth.shape[0]}x{depth.shape[1]} < {self._grid.ny}x{self._grid.nx}). "
            )
        elif depth.shape[0] > self._grid.ny or depth.shape[1] > self._grid.nx:
            assert (
                "geolat" in ds_topo and "geolon" in ds_topo
            ), f"Topog file {file_path} does not contain geolat and geolon fields, "
            "which are required to determine if the grid is a subgrid of the topog file, "
            "since the topography data is larger than the grid (in index space). "

            # Determine if the grid is a subgrid of the topog file
            geolat = ds_topo["geolat"]
            geolon = ds_topo["geolon"]

            # find the closest cell in the topog file to the (sub)grid's origin (southwest corner)
            topog_kdtree = cKDTree(
                np.column_stack((geolat.data.flatten(), geolon.data.flatten()))
            )
            _, indices = topog_kdtree.query(
                [self._grid.tlat[0, 0].item(), self._grid.tlon[0, 0].item()]
            )
            cj, ci = np.unravel_index(indices, geolon.shape)

            assert 0 <= cj <= geolat.shape[0] - self._grid.ny, (
                f"Topography data in {file_path} appears to only contain a subregion "
                f"of the grid, and does not contain enough rows to accommodate the grid size "
                f"({self._grid.ny}). "
            )
            assert 0 <= ci <= geolon.shape[1] - self._grid.nx, (
                f"Topography data in {file_path} appears to only contain a subregion "
                f"of the grid, and does not contain enough columns to accommodate the grid size "
                f"({self._grid.nx}). "
            )

            # Compare the coords of grid with the coords of the subregion of the topog
            # data where it may overlap with the grid
            grid_overlaps_topo = np.all(
                np.isclose(
                    geolat[cj : cj + self._grid.ny, ci : ci + self._grid.nx],
                    self._grid.tlat.data,
                    rtol=1e-5,
                )
            ) and np.all(
                np.isclose(
                    geolon[cj : cj + self._grid.ny, ci : ci + self._grid.nx],
                    self._grid.tlon.data,
                    rtol=1e-5,
                )
            )
            if not grid_overlaps_topo:
                raise ValueError(
                    f"The topography data in {file_path} is larger than the grid "
                    f"data which does not appear to be a subgrid of the topography data. "
                    f"Topography data shape: {depth.shape}, grid shape: "
                    f"({self._grid.ny}, {self._grid.nx}). "
                )

            # If the grid is a subgrid of the topog data, extract the subregion
            depth = depth[cj : cj + self._grid.ny, ci : ci + self._grid.nx]

        else:
            pass  # the depth array is the right size

        # Set all NaNs to land
        depth = depth.fillna(0)

        # Save to object (Build TCM Object)
        self.send_entire_depth_change_to_tcm(
            depth, skip_version_control=skip_version_control
        )

    def set_spoon(self, max_depth, dedge, rad_earth=6.378e6, expdecay=400000.0):
        """
        Create a spoon-shaped bathymetry. Same effect as setting the TOPO_CONFIG
        parameter to "spoon".

        Parameters
        ----------
        max_depth : float
            Maximum depth of model in the units of D.
        dedge : float
            The depth [Z ~> m], at the basin edge
        rad_earth : float, optional
            Radius of earth
        expdecay : float, optional
            A decay scale of associated with the sloping boundaries [m]
        """

        west_lon = self._grid.tlon[0, 0]
        south_lat = self._grid.tlat[0, 0]
        nx = self._grid.nx
        ny = self._grid.ny
        leny = self._grid.supergrid.leny

        D0 = (max_depth - dedge) / (
            (1.0 - np.exp(-0.5 * leny * rad_earth * np.pi / (180.0 * expdecay)))
            * (1.0 - np.exp(-0.5 * leny * rad_earth * np.pi / (180.0 * expdecay)))
        )

        new_values = dedge + D0 * (
            np.sin(
                np.pi * (self._grid.tlon[:, :] - west_lon) / self._grid.supergrid.lenx
            )
            * (
                1.0
                - np.exp(
                    (self._grid.tlat[:, :] - (south_lat + leny))
                    * rad_earth
                    * np.pi
                    / (180.0 * expdecay)
                )
            )
        )

        # Save to object (Build TCM Object)
        self.send_entire_depth_change_to_tcm(new_values)

    def set_bowl(self, max_depth, dedge, rad_earth=6.378e6, expdecay=400000.0):
        """
        Create a bowl-shaped bathymetry. Same effect as setting the TOPO_CONFIG parameter to "bowl".

        Parameters
        ----------
        max_depth : float
            Maximum depth of model in the units of D.
        dedge : float
            The depth [Z ~> m], at the basin edge
        rad_earth : float, optional
            Radius of earth
        expdecay : float, optional
            A decay scale of associated with the sloping boundaries [m]
        """

        west_lon = self._grid.tlon[0, 0]
        south_lat = self._grid.tlat[0, 0]
        len_lon = self._grid.supergrid.lenx
        len_lat = self._grid.supergrid.leny

        D0 = (max_depth - dedge) / (
            (1.0 - np.exp(-0.5 * len_lat * rad_earth * np.pi / (180.0 * expdecay)))
            * (1.0 - np.exp(-0.5 * len_lat * rad_earth * np.pi / (180.0 * expdecay)))
        )

        new_values = dedge + D0 * (
            np.sin(np.pi * (self._grid.tlon[:, :] - west_lon) / len_lon)
            * (
                (
                    1.0
                    - np.exp(
                        -(self._grid.tlat[:, :] - south_lat)
                        * rad_earth
                        * np.pi
                        / (180.0 * expdecay)
                    )
                )
                * (
                    1.0
                    - np.exp(
                        (self._grid.tlat[:, :] - (south_lat + len_lat))
                        * rad_earth
                        * np.pi
                        / (180.0 * expdecay)
                    )
                )
            )
        )

        # Save to object (Build TCM Object)
        self.send_entire_depth_change_to_tcm(new_values)

    def compute_stats(self, nx_sub, ny_sub, mask_hmin):
        """Compute per-cell depth statistics by uniform sub-sampling.

        Results are stored on ``stats`` so a second call with the
        same source file returns immediately without recomputation.
        (Originally created by Frank Bryan in Fortran for NCAR/tx2_3, reimplemented in Python)

        Parameters
        ----------
        src : SourceBathy (part of class)
        nx_sub, ny_sub : int
        mask_hmin : float

        Returns
        -------
        xr.Dataset  —  ``OCN_FRAC``, ``D_mean``, ``D_min``, ``D_max``, ``D2_mean``.
        """
        assert (
            self.src is not None
        ), "Source bathymetry must be loaded to compute topo stats"
        if (
            self.stats is not None
            and self.stats.attrs.get("nx_sub") == nx_sub
            and self.stats.attrs.get("ny_sub") == ny_sub
            and self.stats.attrs.get("mask_hmin") == mask_hmin
        ):
            return self.stats

        from mom6_forge.mapping import regrid_with_subsampling

        # Compute subsampling factor and generate sub-point grid
        ds, _ = regrid_with_subsampling(
            input_dataset=self.src.ds,
            qlon=self._grid.qlon.values,
            qlat=self._grid.qlat.values,
            nx_sub=nx_sub,
            ny_sub=ny_sub,
            regridding_method="nearest_s2d",
        )

        depth_sub = ds[self.src.depth_name].values  # (ny, nx, ny_sub, nx_sub)

        is_ocean = depth_sub > mask_hmin
        ocn_frac = is_ocean.sum(axis=(-2, -1)) / (nx_sub * ny_sub)

        depth_ocean = np.where(is_ocean, depth_sub, np.nan)
        with np.errstate(all="ignore"):
            D_mean = np.nanmean(depth_ocean, axis=(-2, -1))
            D_min = np.nanmin(depth_ocean, axis=(-2, -1))
            D_max = np.nanmax(depth_ocean, axis=(-2, -1))
            D2_mean = np.nanmean(depth_ocean**2, axis=(-2, -1))

        dims = ["ny", "nx"]
        self.src.stats = xr.Dataset(
            {
                "OCN_FRAC": xr.DataArray(
                    ocn_frac,
                    dims=dims,
                    attrs={
                        "long_name": "ocean fraction from sub-sampling",
                        "units": "1",
                    },
                ),
                "D_mean": xr.DataArray(
                    D_mean,
                    dims=dims,
                    attrs={"long_name": "mean ocean depth in cell", "units": "m"},
                ),
                "D_min": xr.DataArray(
                    D_min,
                    dims=dims,
                    attrs={"long_name": "minimum ocean depth in cell", "units": "m"},
                ),
                "D_max": xr.DataArray(
                    D_max,
                    dims=dims,
                    attrs={"long_name": "maximum ocean depth in cell", "units": "m"},
                ),
                "D2_mean": xr.DataArray(
                    D2_mean,
                    dims=dims,
                    attrs={
                        "long_name": "mean squared ocean depth in cell",
                        "units": "m2",
                    },
                ),
            },
            attrs={
                "nx_sub": nx_sub,
                "ny_sub": ny_sub,
                "mask_hmin": mask_hmin,
            },
        )
        return self.src.stats

    def set_depth_from_stats(self, statistic):
        """
        Set the topo depth to a statistic computed by compute_stats.

        Parameters
        ----------
        statistic : str
            Which depth statistic to use. Must be one of the "D_*" keys
            in self.src.stats (e.g. "mean", "min", "max").
        """

        assert (
            self.src is not None and self.src.stats is not None
        ), "Source bathymetry must be provided and must have topo stats computed, please call compute_stats first if you have not already"
        approved_list = []
        for key in self.src.stats.data_vars:
            if key.startswith("D_"):
                approved_list.append(key[2:])
        assert (
            statistic in approved_list
        ), f"Invalid statistic {statistic}, must be one of {approved_list}"

        self.send_entire_depth_change_to_tcm(self.src.stats[f"D_{statistic}"])

    def diagnose_resolution(self, radius=_DEFAULT_RADIUS):
        """
        Print resolution diagnostics comparing the model grid to a source bathymetry
        dataset, and recommend whether Cressman interpolation / stats-based masking
        is worthwhile.

        The recommendation threshold is a resolution ratio of 12x (model dx /
        dataset dx), equivalent to ~0.05° (~5 km) for GEBCO 15-arcsecond source
        data. This matches the criterion used by the tx2_3 global workflow
        (interp_smooth.f90) and might be the scale at which ocean-aware Cressman
        interpolation meaningfully improves coastal depth estimates over standard
        xesmf conservative regridding.

        Parameters
        ----------
        src : SourceBathy (provided internally by the class)
            Source bathymetry object.
        radius: float, optional
            Radius of the Earth in meters, used to convert source dataset lat/lon spacing to approximate physical spacing in meters at the domain's mid-latitude. Default is 6.371e6 m.

        Returns
        -------
        bool
            True if Cressman / stats-based masking is recommended (ratio >= 12x
            and the clipped source dataset has at most 1e6 points), False otherwise.
        """
        CRESSMAN_THRESHOLD = 12.0
        MAX_CRESSMAN_SRC_POINTS = 2e6

        # --- Model T-cell spacing in meters ---
        # sqrt(tarea) gives the geometric mean cell spacing (equiv. to sqrt(dxt * dyt))
        cell_dx_m = np.sqrt(self._grid.tarea.values)

        median_dx_m = float(np.median(cell_dx_m))
        min_dx_m = float(np.min(cell_dx_m))
        max_dx_m = float(np.max(cell_dx_m))

        # --- Source dataset spacing ---
        src = self.src

        dlon_deg = float(abs(src.lon[1] - src.lon[0]))
        dlat_deg = float(abs(src.lat[1] - src.lat[0]))
        R = radius
        dataset_dx_m = haversine(src.lat[0], src.lon[0], src.lat[0], src.lon[1], R)
        dataset_dy_m = haversine(src.lat[0], src.lon[0], src.lat[1], src.lon[0], R)

        ratio_median = median_dx_m / dataset_dx_m
        ratio_max = max_dx_m / dataset_dx_m

        # --- Print ---
        sep = "=" * 58
        print(sep)
        print("  Resolution Diagnostics")
        print(sep)
        print(f"\n  Source dataset ({src.path.name}):")
        print(f"    dlon = {dlon_deg * 3600:.1f} arcsec  ({dlon_deg:.6f}°)")
        print(f"    dlat = {dlat_deg * 3600:.1f} arcsec  ({dlat_deg:.6f}°)")
        print(f"    dx   ~ {dataset_dx_m:.0f} m)")
        print(f"    dy   ~ {dataset_dy_m:.0f} m")
        print(f"\n  Model grid (T-cell spacing):")
        print(f"    median = {median_dx_m / 1000:.2f} km")
        print(f"    min    = {min_dx_m / 1000:.2f} km")
        print(f"    max    = {max_dx_m / 1000:.2f} km")
        print(f"\n  Resolution ratio (model dx / dataset dx):")
        print(f"    median = {ratio_median:.1f}x")
        print(f"    max    = {ratio_max:.1f}x")
        print(f"\n  Cressman / stats-mask threshold: {CRESSMAN_THRESHOLD:.0f}x")
        n_src_lon, n_src_lat = src.lon.size, src.lat.size
        n_src = n_src_lon * n_src_lat
        use_stats_depth = bool(ratio_median >= CRESSMAN_THRESHOLD)
        if use_stats_depth and n_src > MAX_CRESSMAN_SRC_POINTS:
            print(
                f"  Ratio {ratio_median:.1f}x is above the threshold, but the source dataset"
            )
            print(
                f"    is large for this domain ({n_src_lon} x {n_src_lat} = {n_src:,} points > {MAX_CRESSMAN_SRC_POINTS:,.0f})."
            )
            print(f"  → RECOMMENDED: direct_xesmf_regrid()  (bilinear / conservative)")
            print(
                f"    Stats-based masking and Cressman interpolation are turned off to avoid"
            )
            print(
                f"    long runtimes. To use them anyway, pass mask_method='ocean_frac' and"
            )
            print(f"    depth_method='cressman' to set_from_dataset().")
            use_stats_depth = False
        elif use_stats_depth:
            print(f"  → RECOMMENDED: high_res_regrid()  (Cressman + stats mask)")
            print(
                f"    Each model cell spans ~{ratio_median:.0f} dataset pixels per side."
            )
            print(f"    Ocean-aware Cressman interpolation will meaningfully reduce")
            print(f"    land contamination of coastal depth estimates.")
        else:
            print(f"  → RECOMMENDED: direct_xesmf_regrid()  (bilinear / conservative)")
            print(
                f"    Ratio {ratio_median:.1f}x is below the threshold where Cressman"
            )
            print(f"    likely provides benefit over xesmf regridding.")
        print(sep)
        return use_stats_depth

    def generate_mask_from_stats_ocean_frac(
        self,
        mask_threshold=0.5,
    ):
        """
        Generate an ocean mask by uniform sub-sampling of the source bathymetry.

        Mirrors the algorithm in tx2_3's create_model_topo.f90. For each T-cell,
        distributes nx_sub x ny_sub interior points via bilinear interpolation of
        the Q-point corners and snaps each to the nearest source pixel. A cell is
        ocean if its ocean sub-point fraction (OCN_FRAC) meets or exceeds
        ``mask_threshold``.

        Parameters
        ----------
        mask_threshold : float, optional
            Minimum OCN_FRAC for a cell to be classified as ocean. Default 0.5.

        Returns
        -------
        xr.DataArray
            Binary ocean mask on the T-grid (1 = ocean, 0 = land),
            dims ``["ny", "nx"]``.

        Notes
        -----
        ``compute_stats`` must be called before this method. Per-cell depth
        statistics (D_mean, D_min, D_max, D2_mean) are stored on the source
        bathymetry object for use by this and other downstream methods.
        """

        assert (
            self.src is not None
        ), "Source bathymetry must be set before generating mask."
        assert (
            self.src.stats is not None
        ), f"Per-cell statistics must be computed before generating mask. Call compute_stats() first. src={self.src}"

        ocean_mask = (self.src.stats["OCN_FRAC"].values >= mask_threshold).astype(int)

        return xr.DataArray(
            ocean_mask,
            dims=["ny", "nx"],
            attrs={
                "long_name": "ocean mask from sub-sampling",
                "mask_threshold": mask_threshold,
            },
        )

    def set_from_dataset(
        self,
        bathymetry_path,
        longitude_coordinate_name,
        latitude_coordinate_name,
        vertical_coordinate_name,
        fill_channels=False,
        is_input_positive_below_msl=False,
        output_dir=Path(""),
        write_to_file=False,
        mask_method=None,
        depth_method=None,
        regridding_method="bilinear",
        **kwargs,
    ):
        """
        This is a high-level workflow function that runs multiple steps in sequence to set the bathymetry from a source dataset, with optional masking and depth method choices. It is designed to be opinionated and make recommendations based on resolution diagnostics, but users can override the defaults by specifying mask_method and depth_method.
        The workflow is as follows:
        1. Set the source dataset (this will not modify the depth or mask yet,
            it just loads the dataset and prepares it for regridding)
        2. Diagnose whether to use stats-based masking and Cressman interpolation based on resolution comparison between the source dataset and the model grid
        3. Apply a mask based on the user's choice or the resolution diagnostics recommendation (options are 'naturalearth', 'ocean_frac', 'dataset', 'manual', or None)
        4. Set the depth based on the user's choice or the resolution diagnostics recommendation (options are 'stats', 'xesmf', or None)
        5. Call ``fill_inland_lakes_and_channels()`` to finish processing the bathymetry (fill channels, apply mask, etc.)

        Parameters
        ----------
        bathymetry_path (str): Path to the netCDF file with the bathymetry
        longitude_coordinate_name (str): The name of the longitude coordinate in the bathymetry dataset at ``bathymetry_path``. For example, for GEBCO bathymetry: ``'lon'``.
        latitude_coordinate_name (str): The name of the latitude coordinate in the bathymetry dataset at ``bathymetry_path``. For example, for GEBCO bathymetry: ``'lat'``.
        vertical_coordinate_name (str): The name of the vertical coordinate (elevation) in the bathymetry dataset at ``bathymetry_path``. For example, for GEBCO bathymetry: ``'elevation'``.
        fill_channels (bool, optional): Whether to fill narrow channels in the final depth. Default is False.
        is_input_positive_below_msl (bool, optional): Whether the vertical coordinate in the source dataset is positive down (e.g. depth) rather than positive up (e.g. elevation). Default is False (positive up).
        output_dir (str or Path, optional): Directory to save intermediate files if needed (e.g. for Cressman interpolation). Default is current directory.
        write_to_file (bool, optional): Whether to write intermediate files to disk (e.g. for Cressman interpolation). Default is False.
        mask_method (str or None, optional): Method to use for masking land vs ocean. Options are 'naturalearth' (use natural earth land polygons), 'ocean_frac' (use ocean fraction from sub-sampling stats), 'dataset' (derive mask directly from raw depth from dataset), 'manual' (use a user-provided mask set via the user_mask property), or None to automatically choose based on resolution diagnostics. Default is None.
        depth_method (str or None, optional): Method to use for setting depth. Options are 'stats' (use a statistic from the sub-sampling stats), 'xesmf' (do a direct xesmf regrid of the source dataset depth), or None to automatically choose based on resolution diagnostics. Default is None.
        regridding_method (str, optional): The xESMF regridding method to use when depth_method is 'xesmf' (or when xesmf is chosen automatically). Default is 'bilinear'.
        **kwargs: Additional keyword arguments needed for specific mask or depth methods. For example, if mask_method is 'ocean_frac', then kwargs should include 'nx_sub', 'ny_sub', and 'mask_hmin' for the sub-sampling stats calculation.

        """
        # Set source
        self.set_src(
            bathymetry_path,
            longitude_coordinate_name,
            latitude_coordinate_name,
            vertical_coordinate_name,
            is_input_positive_below_msl,
        )

        # Diagnose wether to use stats-based masking and Cressman interpolation based on resolution comparison between the source dataset and the model grid
        use_stats_depth = self.diagnose_resolution()

        # Check necessary attributes for different conditions.
        # Note ocean_frac, stats-based masking, and stats-based depth all rely on the same sub-sampling stats, so we check for those together.
        if (
            (mask_method == "ocean_frac")
            or (mask_method is None and use_stats_depth)
            or (depth_method == "stats")
            or (depth_method is None and use_stats_depth)
        ):
            if kwargs.get("mask_hmin") is None:
                print(
                    "Masking depth threshold (mask_hmin) not provided in kwargs, defaulting to 0 m"
                )
                mask_hmin = 0.0
            else:
                mask_hmin = kwargs["mask_hmin"]

            if kwargs.get("nx_sub") is None or kwargs.get("ny_sub") is None:
                print(
                    "Sub-sampling factors (nx_sub, ny_sub) not provided in kwargs, computing based on source dataset and model grid resolution"
                )
                src_nj, src_ni = self.src.depth.shape
                ocn_ni, ocn_nj = self._grid.nx, self._grid.ny
                ny_sub, nx_sub = compute_subsampling_factor(
                    src_nj, src_ni, ocn_nj, ocn_ni
                )
            else:
                ny_sub = kwargs["ny_sub"]
                nx_sub = kwargs["nx_sub"]

        # Apply a mask if specified
        if mask_method is not None:
            if mask_method == "naturalearth":
                self.user_mask = self.generate_mask_from_naturalearth()
            elif mask_method == "ocean_frac":
                self.compute_stats(
                    nx_sub=nx_sub,
                    ny_sub=ny_sub,
                    mask_hmin=mask_hmin,
                )
                self.user_mask = self.generate_mask_from_stats_ocean_frac()
            elif mask_method == "dataset":
                self.clear_user_mask()  # ensure no user mask is set so that the mask is derived from the raw depth, which is directly from the dataset
            elif mask_method == "manual":
                assert (
                    self.user_mask is not None
                ), "Mask method set to 'manual' but no user mask has been set. Please set the user mask before calling set_from_dataset with mask_method='manual'"
            else:
                raise ValueError(
                    f"Invalid mask option {mask_method!r}, must be one of {VALID_MASK_METHODS}"
                )
        else:
            if use_stats_depth:
                print(
                    "Resolution diagnostics recommend using stats-based masking, which we will set because no mask option was specified"
                )
                self.compute_stats(
                    nx_sub=nx_sub,
                    ny_sub=ny_sub,
                    mask_hmin=mask_hmin,
                )
                self.user_mask = self.generate_mask_from_stats_ocean_frac()
            else:
                print(
                    "Resolution diagnostics recommend not using stats-based masking, so we'll use the natural earth mask"
                )
                self.user_mask = self.generate_mask_from_naturalearth()

        if depth_method is not None:
            if depth_method == "stats":
                if not use_stats_depth:
                    print(
                        "Resolution diagnostics recommend not using stats-based masking, but stats-based depth was requested"
                    )
                self.compute_stats(
                    nx_sub=nx_sub,
                    ny_sub=ny_sub,
                    mask_hmin=mask_hmin,
                )
                self.set_depth_from_stats(statistic="mean")
            elif depth_method == "cressman":
                self.direct_cressman_interp(
                    weights_path=(
                        Path(output_dir) / "cressman_weights.nc"
                        if write_to_file
                        else None
                    )
                )
            elif depth_method == "xesmf":
                if use_stats_depth:
                    print(
                        "Resolution diagnostics recommend using stats-based masking, but xesmf-based depth was requested, so we will do a direct xesmf regrid anyway because it was explicitly requested, but be aware that this may lead to significant land contamination of coastal depth estimates"
                    )
                self.set_depth_from_xesmf(
                    output_dir=output_dir,
                    write_to_file=write_to_file,
                    regridding_method=regridding_method,
                )
            else:
                raise ValueError(
                    f"Invalid depth option {depth_method!r}, must be one of {VALID_DEPTH_METHODS}"
                )
        else:
            if not use_stats_depth:
                print(
                    "Resolution diagnostics recommend not using stats-based depth method, so we'll do a direct xesmf regrid for depth because no depth option was specified"
                )
                self.set_depth_from_xesmf(
                    output_dir=output_dir,
                    write_to_file=write_to_file,
                    regridding_method=regridding_method,
                )
            else:
                print(
                    "Resolution diagnostics recommend using stats-based method, which we will set for depth as cressman method because no depth option was specified"
                )
                self.direct_cressman_interp(
                    weights_path=(
                        Path(output_dir) / "cressman_weights.nc"
                        if write_to_file
                        else None
                    )
                )

        # Tidy the dataset (fill channels, is_input_positive_below_msl, etc...)
        if fill_channels:
            self.fill_inland_lakes_and_channels()

        print(
            "Warning! This was an opionated workflow function that ran multiple steps in sequence. Please edit the mask manually if need be (Some depth methods, like cressman, are mask-aware and may need to be rerun)! "
        )

    def set_depth_from_xesmf(
        self,
        output_dir=Path(""),
        write_to_file=False,
        regridding_method="bilinear",
    ):
        """
        Regrid the source bathymetry onto the model grid using xESMF.

        This code was originally written by Ashley Barnes in regional_mom6
        (https://github.com/COSIMA/regional-mom6) and adapted for this package.

        Requires that ``set_src`` has been called first (or that the source dataset
        has been set via ``set_from_dataset``).

        Arguments:
            output_dir (str or Path, optional): Directory where intermediate files are
                written when ``write_to_file=True``. Default: current directory.
            write_to_file (Optional[bool]): Whether to write the source and unfinished
                destination grids to netCDF before regridding. Default: ``False``.
            regridding_method (Optional[str]): The xESMF regridding method to use.
                Default: ``'bilinear'``.

        """
        print(
            """**NOTE**
            If bathymetry setup fails (e.g. kernel crashes), restart the kernel and edit this cell.
            Call ``[topo_object_name].mpi_set_depth_from_xesmf()`` instead. Follow the given instructions for using mpi
            and ESMF_Regrid outside of a python environment. This breaks up the process, so be sure to call
            ``[topo_object_name].fill_inland_lakes_and_channels()`` after regridding with mpi."""
        )
        output_dir = Path(output_dir)
        self.src_bathymetry_dataset = self.src.ds
        self.destination_bathymetry = self._grid.get_esmf_ready_tracer_ds()
        self.destination_bathymetry["depth"] = xr.zeros_like(
            self.destination_bathymetry.tarea
        )
        self.destination_bathymetry.depth.attrs["units"] = "meters"
        self.destination_bathymetry.depth.attrs["coordinates"] = "lon lat"
        if write_to_file:
            self.src_bathymetry_dataset.to_netcdf(output_dir / "bathymetry_original.nc")
            self.destination_bathymetry.to_netcdf(
                output_dir / "bathymetry_unfinished.nc"
            )

        # Wrap the source in longitude whenever its slice covers the whole
        # circle: global and tripolar grids as well as polar caps, whose rim
        # crosses the antimeridian. Without it, destination cells between the
        # source's last and first column get no data.
        from mom6_forge.mapping import regrid_dataset_via_xesmf

        self.depth = regrid_dataset_via_xesmf(
            input_dataset=self.src_bathymetry_dataset,
            output_dataset=self.destination_bathymetry,
            regridding_method=regridding_method,
            write_to_file=write_to_file,
            output_path=output_dir / "bathymetry_unfinished.nc",
            periodic=self.src.is_periodic,
        )["depth"]
        if write_to_file:
            self.write_topo_file(
                output_dir / "bathymetry_unfinished.nc"
            )  # This is called unfinished because the regridding is not fully complete until the one-cell channels are filled

    def mpi_set_depth_from_xesmf(
        self,
        *,
        bathymetry_path,
        longitude_coordinate_name,
        latitude_coordinate_name,
        vertical_coordinate_name,
        is_input_positive_below_msl=False,
        output_dir=Path(""),
        verbose=True,
    ):
        """
        Prepare input files for MPI-parallel bathymetry regridding with ESMF_Regrid.

        Writes ``bathymetry_original.nc`` (source) and ``bathymetry_unfinished.nc``
        (destination grid shell) to ``output_dir``. The user then runs ``ESMF_Regrid``
        externally with MPI, and finally calls ``fill_inland_lakes_and_channels()`` to
        complete post-processing. Use this instead of ``set_depth_from_xesmf`` when the
        domain is too large to regrid within a single Python process.

        Arguments:
            bathymetry_path (str): Path to the netCDF file with the source bathymetry.
            longitude_coordinate_name (str): Name of the longitude coordinate in the
                source dataset (e.g. ``'lon'`` for GEBCO).
            latitude_coordinate_name (str): Name of the latitude coordinate in the
                source dataset (e.g. ``'lat'`` for GEBCO).
            vertical_coordinate_name (str): Name of the vertical/elevation coordinate in
                the source dataset (e.g. ``'elevation'`` for GEBCO).
            is_input_positive_below_msl (bool, optional): Set ``True`` if the source
                vertical coordinate is positive downwards (depth convention). Default: ``False``.
            output_dir (str or Path, optional): Directory where the two netCDF files are
                written. Default: current directory.
            verbose (bool, optional): Print step-by-step MPI regridding instructions.
                Default: ``True``.

        """
        if verbose:
            print(f"""
            *MANUAL REGRIDDING INSTRUCTIONS*

            Calling `[object_name].mpi_set_depth_from_xesmf` sets up the files necessary for regridding
            the bathymetry using mpirun and ESMF_Regrid. See below for the step-by-step instructions:

            1. There should be two files: `bathymetry_original.nc` and `bathymetry_unfinished.nc` located at
            {output_dir}.

            2. Open a terminal and change to this directory (e.g. `cd {output_dir}`).

            3. Request appropriate computational resources (see example script below), and run the command:

            `mpirun -np NUMBER_OF_CPUS ESMF_Regrid -s bathymetry_original.nc -d bathymetry_unfinished.nc -m bilinear --src_var depth --dst_var depth --netcdf4 --src_regional --dst_regional`

            4. Run Topo_object.fill_inland_lakes_and_channels() to finish processing the bathymetry.

            Example PBS script using NCAR's Casper Machine: https://gist.github.com/AidanJanney/911290acaef62107f8e2d4ccef9d09be

            For additional details see: https://xesmf.readthedocs.io/en/latest/large_problems_on_HPC.html
            """)

        output_dir = Path(output_dir)
        self.set_src(
            bathymetry_path=bathymetry_path,
            longitude_coordinate_name=longitude_coordinate_name,
            latitude_coordinate_name=latitude_coordinate_name,
            vertical_coordinate_name=vertical_coordinate_name,
            is_input_positive_below_msl=is_input_positive_below_msl,
        )
        self.src_bathymetry_dataset = self.src.ds
        self.destination_bathymetry = self._grid.get_esmf_ready_tracer_ds()
        self.destination_bathymetry["depth"] = xr.zeros_like(
            self.destination_bathymetry.tarea
        )
        self.destination_bathymetry.depth.attrs["units"] = "meters"
        self.destination_bathymetry.depth.attrs["coordinates"] = "lon lat"
        self.src_bathymetry_dataset.to_netcdf(output_dir / "bathymetry_original.nc")
        self.destination_bathymetry.to_netcdf(output_dir / "bathymetry_unfinished.nc")

        print(
            "Configuration complete. Ready for regridding with MPI. See documentation for more details."
        )

    def direct_cressman_interp(
        self,
        smooth_scl=2.0,
        cressman_exp=2.0,
        weights_path=None,
    ):
        """
        Assign ocean depths using Cressman distance-weighted interpolation.
        Mirrors ``interp_smooth.f90`` from the tx2_3 topography workflow.

        For each ocean T-cell a smoothing radius ``L = smooth_scl * sqrt(cell_area)``
        is computed. Source ocean points within ``L`` are averaged with weights

        .. math::

            w = \\left(\\frac{L^2 - r^2}{L^2 + r^2}\\right)^{c}

        where ``r`` is the great-circle arc distance and ``c = cressman_exp``.
        Only source points with positive depth (ocean) contribute, so depth
        estimates are never contaminated by land elevations.

        Weights are computed by :func:`~mom6_forge.mapping.compute_cressman_weights`,
        optionally saved to an ESMF-compatible netCDF, and applied through ``xe.Regridder`` —
        all orchestrated by :func:`~mom6_forge.mapping.regrid_dataset_via_cressman`.
        Cells that receive no source coverage are filled by iterative neighbour
        averaging (up to 100 passes).

        Parameters
        ----------
        smooth_scl : float
            Smoothing scale multiplier for the Cressman radius. Default ``2.0``.
        cressman_exp : float
            Exponent for the Cressman weight function. Default ``2.0``.
        weights_path : str or Path or None
            Where to save the ESMF weights netCDF. If ``None`` (default), the
            weights are kept in memory and nothing is written.
        """
        from mom6_forge.mapping import regrid_dataset_via_cressman

        # --- Regrid via mapping module (weights → file → cressman Regridder) ---

        dst_ds = self._grid.get_esmf_ready_tracer_ds()
        dst_ds["area"] = self._grid.tarea
        dst_ds["mask"] = self.tmask

        depth_dst, unfilled = regrid_dataset_via_cressman(
            self.src.ds,
            dst_ds,
            smooth_scl=smooth_scl,
            cressman_exp=cressman_exp,
            weights_path=weights_path,
        )

        depth_arr = iterative_fill(depth_dst["depth"].values, unfilled, self.tmask)

        self.send_entire_depth_change_to_tcm(
            xr.DataArray(
                depth_arr.astype(float), dims=["ny", "nx"], attrs={"units": "m"}
            )
        )

    def fill_inland_lakes_and_channels(self):
        """
        Fill in one-cell-wide channels and inland lakes. This removes more narrow inlets, but can also connect extra islands to land.
        """
        changed = True  ## keeps track of whether solution has converged or not

        forward = True  ## only useful for iterating through diagonal channel removal. Means iteration goes SW -> NE
        ocean_mask = self.tmask
        land_mask = np.abs(ocean_mask - 1)

        while changed == True:
            ## First fill in all lakes.
            ## scipy.ndimage.binary_fill_holes fills holes made of 0's within a field of 1's
            land_mask[:, :] = binary_fill_holes(land_mask.data)
            ## Get the ocean mask instead of land- easier to remove channels this way
            ocean_mask = np.abs(land_mask - 1)

            ## fill in all one-cell-wide horizontal channels
            newmask = xr.where(
                ocean_mask * (land_mask.shift(nx=1) + land_mask.shift(nx=-1)) == 2,
                1,
                0,
            )
            newmask += xr.where(
                ocean_mask * (land_mask.shift(ny=1) + land_mask.shift(ny=-1)) == 2,
                1,
                0,
            )
            ## Diagonal channels
            if forward == True:
                ## horizontal channels
                newmask += xr.where(
                    (ocean_mask * ocean_mask.shift(nx=1))
                    * (
                        land_mask.shift({"nx": 1, "ny": 1})
                        + land_mask.shift({"ny": -1})
                    )
                    == 2,
                    1,
                    0,
                )  ## up right & below
                newmask += xr.where(
                    (ocean_mask * ocean_mask.shift(nx=1))
                    * (
                        land_mask.shift({"nx": 1, "ny": -1})
                        + land_mask.shift({"ny": 1})
                    )
                    == 2,
                    1,
                    0,
                )  ## down right & above
                ## Vertical channels
                newmask += xr.where(
                    (ocean_mask * ocean_mask.shift(ny=1))
                    * (
                        land_mask.shift({"nx": 1, "ny": 1})
                        + land_mask.shift({"nx": -1})
                    )
                    == 2,
                    1,
                    0,
                )  ## up right & left
                newmask += xr.where(
                    (ocean_mask * ocean_mask.shift(ny=1))
                    * (
                        land_mask.shift({"nx": -1, "ny": 1})
                        + land_mask.shift({"nx": 1})
                    )
                    == 2,
                    1,
                    0,
                )  ## up left & right

                forward = False

            if forward == False:
                ## Horizontal channels
                newmask += xr.where(
                    (ocean_mask * ocean_mask.shift(nx=-1))
                    * (
                        land_mask.shift({"nx": -1, "ny": 1})
                        + land_mask.shift({"ny": -1})
                    )
                    == 2,
                    1,
                    0,
                )  ## up left & below
                newmask += xr.where(
                    (ocean_mask * ocean_mask.shift(nx=-1))
                    * (
                        land_mask.shift({"nx": -1, "ny": -1})
                        + land_mask.shift({"ny": 1})
                    )
                    == 2,
                    1,
                    0,
                )  ## down left & above
                ## Vertical channels
                newmask += xr.where(
                    (ocean_mask * ocean_mask.shift(ny=-1))
                    * (
                        land_mask.shift({"nx": 1, "ny": -1})
                        + land_mask.shift({"nx": -1})
                    )
                    == 2,
                    1,
                    0,
                )  ## down right & left
                newmask += xr.where(
                    (ocean_mask * ocean_mask.shift(ny=-1))
                    * (
                        land_mask.shift({"nx": -1, "ny": -1})
                        + land_mask.shift({"nx": 1})
                    )
                    == 2,
                    1,
                    0,
                )  ## down left & right

                forward = True

            newmask = xr.where(newmask > 0, 1, 0)
            changed = np.max(newmask) == 1
            land_mask += newmask

        ocean_mask = np.abs(land_mask - 1)

        # Reset the mask through Mask Edit
        self.user_mask = ocean_mask

    def _erase_ocean_cells(self, doomed, message="Mask Edit"):
        """
        Mask out (turn to land) the cells flagged in the boolean array `doomed`.

        Only ocean cells may be flagged, so that the edit records an old mask value
        of 1. Leaving land out also keeps the command proportional to the area
        erased rather than to the size of the domain.
        """
        indices = [tuple(idx) for idx in np.argwhere(doomed)]
        if not indices:
            return  # nothing to erase

        cmd = MaskEditCommand(
            self,
            indices,
            [0] * len(indices),
            old_values=[1] * len(indices),
            message=message,
        )
        self.apply_edit(cmd)

    def erase_selected_basin(self, i, j):
        """
        Erase the basin containing cell (i, j). A no-op if that cell is land.
        """
        basins = self.basintmask.data
        selected = basins[j, i]
        if selected == 0:
            return  # land cell: no basin to erase
        self._erase_ocean_cells(basins == selected, message="Erase selected basin")

    def erase_disconnected_basin(self, i, j):
        """
        Erase every basin but the one containing cell (i, j). A no-op if that cell is land.
        """
        basins = self.basintmask.data
        selected = basins[j, i]
        if selected == 0:
            return  # land cell: no basin to keep
        self._erase_ocean_cells(
            (basins != selected) & (basins > 0), message="Erase disconnected basins"
        )

    def keep_largest_basin(self):
        """
        Remove every disconnected ocean basin except the largest one.

        Basins are the connected components of the ocean mask (4-connectivity, and
        wrapping in x when the grid is cyclic). basintmask gives the basin of greatest
        total area the highest label, so that one is kept and every other basin is
        masked out as land. This is a no-op when the domain holds at most one basin.
        """
        basins = self.basintmask.data
        largest = basins.max()  # 0 if the domain is all land, flagging nothing below

        self._erase_ocean_cells(
            (basins != largest) & (basins > 0), message="Keep largest basin"
        )

    def apply_ridge(self, height, width, lon, ilat):
        """
        Apply a ridge to the bathymetry.

        Parameters
        ----------
        height : float
            Height of the ridge to be added.
        width : float
            Width of the ridge to be added.
        lon : float
            Longitude where the ridge is to be centered.
        ilat : pair of integers
            Initial and final latitude indices for the ridge.
        """

        ridge_lon = [
            self._grid.tlon[0, 0].data,
            lon - width / 2.0,
            lon,
            lon + width / 2.0,
            self._grid.tlon[0, -1].data,
        ]
        ridge_height = [0.0, 0.0, -height, 0.0, 0.0]
        interp_func = interpolate.interp1d(ridge_lon, ridge_height, kind=2)
        ridge_height_mapped = interp_func(self._grid.tlon[0, :])
        ridge_height_mapped = np.where(
            ridge_height_mapped <= 0.0, ridge_height_mapped, 0.0
        )
        affected_indices = []
        old_vals = []
        new_vals = []
        for j in range(ilat[0], ilat[1]):
            affected_indices.extend([(j, i) for i in range(self._grid.nx)])
            old_vals.extend(self.depth[j, :].values)
            new_vals.extend((self.depth[j, :] + ridge_height_mapped).values)
        depth_edit_command = DepthEditCommand(
            self, affected_indices, new_vals, old_values=old_vals
        )
        self.apply_edit(depth_edit_command)

    def generate_mask_from_landfrac_file(
        self,
        landfrac_filepath,
        landfrac_name,
        xcoord_name,
        ycoord_name,
        cutoff_frac=0.5,
        method="bilinear",
    ):
        """
        Given a dataset containing land fraction, generate and apply ocean mask.

        Parameters
        ----------
        landfrac_filepath : str
            Path the netcdf file containing the land fraction field.
        landfrac_name : str
            The field name corresponding to the land fraction  (e.g., "landfrac").
        xcoord_name : str
            The name of the x coordinate of the landfrac dataset (e.g., "lon").
        ycoord_name : str
            The name of the y coordinate of the landfrac dataset (e.g., "lat").
        cutoff_frac : float
            Cells with landfrac > cutoff_frac are deemed land cells.
        method : str
            Mapping method for determining the ocean mask (lnd -> ocn)
        """

        assert isinstance(landfrac_filepath, str), "landfrac_filepath must be a string"
        assert landfrac_filepath.endswith(
            ".nc"
        ), "landfrac_filepath must point to a netcdf file"
        ds = xr.open_dataset(landfrac_filepath)

        assert isinstance(landfrac_name, str), "landfrac_name must be a string"
        assert (
            landfrac_name in ds
        ), f"Couldn't find {landfrac_name} in {landfrac_filepath}"
        assert isinstance(xcoord_name, str), "xcoord_name must be a string"
        assert xcoord_name in ds, f"Couldn't find {xcoord_name} in {landfrac_filepath}"
        assert isinstance(ycoord_name, str), "ycoord_name must be a string"
        assert ycoord_name in ds, f"Couldn't find {ycoord_name} in {landfrac_filepath}"
        assert isinstance(
            cutoff_frac, float
        ), f"cutoff_frac={cutoff_frac} must be a float"
        assert (
            0.0 <= cutoff_frac <= 1.0
        ), f"cutoff_frac={cutoff_frac} must be between 0 and 1"

        valid_methods = [
            "bilinear",
            "conservative",
            "conservative_normed",
            "patch",
            "nearest_s2d",
            "nearest_d2s",
        ]
        assert (
            method in valid_methods
        ), f"{method} is not a valid mapping method. Choose from: {valid_methods}"

        ds_mapped = xr.Dataset(
            data_vars={}, coords={"lat": self._grid.tlat, "lon": self._grid.tlon}
        )

        import xesmf as xe

        regridder = xe.Regridder(
            ds, ds_mapped, method, periodic=self._grid.supergrid.is_cyclic_x
        )
        mask_mapped = regridder(ds.landfrac)

        # Convert land fraction to binary mask (1=ocean, 0=land)
        binary_mask = (mask_mapped <= cutoff_frac).astype(int)

        # Use MaskEditCommand for version-controlled mask application
        # Generate all affected indices
        all_indices = list(np.ndindex(binary_mask.shape))  # list of (j, i) tuples
        new_values = binary_mask.values.ravel().tolist()

        # Get old values (current mask or 0 if no mask set)
        old_mask = self.tmask
        old_values = (
            old_mask.values.ravel().tolist()
            if isinstance(old_mask, xr.DataArray)
            else old_mask.ravel().tolist()
        )

        # Build and execute command
        mask_edit_command = MaskEditCommand(
            self,
            all_indices,
            new_values,
            old_values=old_values,
            message="Apply Land Fraction Mask",
        )

        self.apply_edit(mask_edit_command)

        # legacy code set the depth of land cells to depth_fillval, but now that is handled in the depth property.

    def generate_mask_from_naturalearth(
        self,
        resolution="10",
        version="v5_1_2",
    ):
        """
        Generate and apply a land mask using regionmask's Natural Earth dataset. (Recommended by Fred Castruccio)

        Parameters
        ----------
        resolution : str
            Resolution of the Natural Earth land dataset. One of "10", "50", "110" (minutes).
        version : str
            Version of the Natural Earth dataset in regionmask. e.g. "v5_1_2".
        """

        import regionmask

        region_attr = f"natural_earth_{version}"
        land_attr = f"land_{resolution}"

        assert hasattr(
            regionmask.defined_regions, region_attr
        ), f"regionmask has no Natural Earth version '{version}'. Available: {dir(regionmask.defined_regions)}"

        ne = getattr(regionmask.defined_regions, region_attr)

        assert hasattr(
            ne, land_attr
        ), f"Natural Earth '{version}' has no resolution '{resolution}'. Available: {dir(ne)}"

        land = getattr(ne, land_attr)

        raw_mask = land.mask(self._grid.tlon.values, self._grid.tlat.values)

        # NaN = ocean (not masked by any land region), non-NaN = land
        binary_mask = raw_mask.isnull().astype(int)  # 1 = ocean, 0 = land

        return binary_mask.values

    def gen_topo_ds(self, title=None):
        """
        Write the TOPO_FILE (bathymetry file) in xarray Dataset.

        Parameters
        ----------
        title: str, optional
            File title.
        """
        ds = xr.Dataset()

        # global attrs:
        ds.attrs["date_created"] = datetime.now().isoformat()
        if title:
            ds.attrs["title"] = title
        else:
            ds.attrs["title"] = "MOM6 topography file"
        ds.attrs["min_depth"] = self.min_depth
        ds.attrs["max_depth"] = self.max_depth

        ds["y"] = xr.DataArray(
            self._grid.tlat,
            dims=["ny", "nx"],
            attrs={
                "long_name": "array of t-grid latitudes",
                "units": self._grid.tlat.units,
            },
        )

        ds["x"] = xr.DataArray(
            self._grid.tlon,
            dims=["ny", "nx"],
            attrs={
                "long_name": "array of t-grid longitutes",
                "units": self._grid.tlon.units,
            },
        )

        ds["mask"] = xr.DataArray(
            self.tmask.astype(np.int32),
            dims=["ny", "nx"],
            attrs={
                "long_name": "landsea mask at t points: 1 ocean, 0 land",
                "units": "nondim",
            },
        )

        # Write raw depth to file
        ds["depth_raw"] = xr.DataArray(
            self.depth.data,
            dims=["ny", "nx"],
            attrs={
                "long_name": "t-grid cell depth (raw, before masking)",
                "units": "m",
            },
        )

        # Write masked depth (from property) to file
        ds["depth"] = xr.DataArray(
            self.masked_depth.data,
            dims=["ny", "nx"],
            attrs={"long_name": "t-grid cell masked depth", "units": "m"},
        )

        return ds

    def write_topo_file(self, file_path, title=None):
        """
        Write the TOPO_FILE (bathymetry file) in netcdf format. The written file is
        to be read in by MOM6 during runtime.

        Parameters
        ----------
        file_path: str
            Path to TOPO_FILE to be written.
        title: str, optional
            File title.

        Returns
        -------
        xr.Dataset
            The bathymetry dataset written to ``file_path``.

        Note
        ----
        If channel_widths is not empty, remember to also write those constraints using
        channel_widths.write(channel_file_path).
        """

        if self.channel_widths.get_all():
            print(
                "Note: Channel widths are defined. Remember to write them with "
                "channel_widths.write(filepath)"
            )

        ds = self.gen_topo_ds(title=title)
        ds.to_netcdf(file_path, format="NETCDF3_64BIT")
        return ds

    def write_cice_grid_file(self, file_path):
        """
        Write the CICE grid file in netcdf format. The written file is
        to be read in by CICE during runtime.

        Parameters
        ----------
        file_path: str
            Path to CICE grid file to be written.

        Returns
        -------
        xr.Dataset
            The CICE grid dataset written to ``file_path``.
        """

        assert (
            "degrees" in self._grid.tlat.units and "degrees" in self._grid.tlon.units
        ), "Unsupported coord"

        ds = xr.Dataset()

        # global attrs:
        ds.attrs["title"] = "CICE grid file"

        ny = self._grid.ny
        nx = self._grid.nx

        ds["ulat"] = xr.DataArray(
            np.deg2rad(self._grid.qlat[1:, 1:].data),
            dims=["nj", "ni"],
            attrs={
                "long_name": "U grid center latitude",
                "units": "radians",
                "bounds": "latu_bounds",
            },
        )

        ds["ulon"] = xr.DataArray(
            np.deg2rad(self._grid.qlon[1:, 1:].data),
            dims=["nj", "ni"],
            attrs={
                "long_name": "U grid center longitude",
                "units": "radians",
                "bounds": "lonu_bounds",
            },
        )

        ds["tlat"] = xr.DataArray(
            np.deg2rad(self._grid.tlat.data),
            dims=["nj", "ni"],
            attrs={
                "long_name": "T grid center latitude",
                "units": "degrees_north",
                "bounds": "latt_bounds",
            },
        )

        ds["tlon"] = xr.DataArray(
            np.deg2rad(self._grid.tlon.data),
            dims=["nj", "ni"],
            attrs={
                "long_name": "T grid center longitude",
                "units": "degrees_east",
                "bounds": "lont_bounds",
            },
        )

        ds["htn"] = xr.DataArray(
            self._grid.dxCv.data * 100.0,
            dims=["nj", "ni"],
            attrs={
                "long_name": "T cell width on North side",
                "units": "cm",
                "coordinates": "TLON TLAT",
            },
        )

        ds["hte"] = xr.DataArray(
            self._grid.dyCu.data * 100,
            dims=["nj", "ni"],
            attrs={
                "long_name": "T cell width on East side",
                "units": "cm",
                "coordinates": "TLON TLAT",
            },
        )

        ds["angle"] = xr.DataArray(
            np.deg2rad(
                self._grid.angle_q.data[
                    1:, 1:
                ]  # Slice the q-grid from MOM6 (which is u-grid in CICE/POP) to CICE/POP convention, the top right of the t points
            ),
            dims=["nj", "ni"],
            attrs={
                "long_name": "angle grid makes with latitude line on U grid",
                "units": "radians",
                "coordinates": "ULON ULAT",
            },
        )

        ds["anglet"] = xr.DataArray(
            np.deg2rad(self._grid.angle.data),
            dims=["nj", "ni"],
            attrs={
                "long_name": "angle grid makes with latitude line on T grid",
                "units": "radians",
                "coordinates": "TLON TLAT",
            },
        )

        ds["kmt"] = xr.DataArray(
            self.tmask.astype(np.float32),
            dims=["nj", "ni"],
            attrs={
                "long_name": "mask of T grid cells",
                "units": "unitless",
                "coordinates": "TLON TLAT",
            },
        )

        ds.to_netcdf(
            file_path,
            format="NETCDF3_64BIT",
        )
        return ds

    # Edge names accepted by write_ww3_input's boundary_edges argument. The
    # spelling deliberately matches the one used for CrocoDash open boundary
    # segments ("south"/"north"/"west"/"east") so a caller can pass the same
    # list it uses to configure the ocean boundaries.
    _WW3_EDGE_NAMES = ("south", "north", "west", "east")

    def _normalize_ww3_boundary_edges(self, boundary_edges):
        """
        Validate write_ww3_input's boundary_edges argument.

        Parameters
        ----------
        boundary_edges : None, str or iterable of str
            None selects every edge of a non-cyclic (regional) grid and no
            edge of a cyclic-x grid, matching open_boundary=True. Edge names may
            be in any case and any order; a bare string is treated as a single
            edge (rather than as an iterable of characters).

        Raises
        ------
        ValueError
            If an edge name is not one of _WW3_EDGE_NAMES, or if the east or
            west edge is requested on a grid that is reentrant in x. The
            latter is rejected rather than silently dropped: a reentrant edge
            has no physical boundary, so asking for boundary forcing there
            means the caller and the grid disagree about the domain.

        Returns
        -------
        set of str
            The requested edges, lowercased and de-duplicated.
        """
        if boundary_edges is None:
            boundary_edges = (
                () if self._grid.supergrid.is_cyclic_x else self._WW3_EDGE_NAMES
            )
        if isinstance(boundary_edges, str):
            boundary_edges = (boundary_edges,)
        edges = {str(edge).strip().lower() for edge in boundary_edges}

        unknown = edges - set(self._WW3_EDGE_NAMES)
        if unknown:
            raise ValueError(
                f"Unknown WW3 boundary edge(s) {sorted(unknown)}; valid edges "
                f"are {list(self._WW3_EDGE_NAMES)}."
            )

        cyclic_edges = edges & {"east", "west"}
        if cyclic_edges and self._grid.supergrid.is_cyclic_x:
            raise ValueError(
                f"Cannot flag the {sorted(cyclic_edges)} edge(s) as WW3 boundary "
                "points: this grid is reentrant in x, so it has no physical "
                "east/west boundary."
            )

        return edges

    def _compute_ww3_mapsta(self, boundary_edges):
        """
        Compute the WW3 mapsta status-code array for this grid.

        Status codes follow WW3's convention: 0 = land, 1 = sea point,
        2 = active boundary point. Ocean cells on the requested perimeter
        edges are flagged as active boundary points; land cells stay land
        wherever they fall. Edges are named by index, not geography:
        south is j=0, north is j=ny-1, west is i=0, east is i=nx-1.

        ww3_grid does not take the perimeter verbatim: it keeps the 2s but
        demotes any perimeter sea point (1) to an excluded point (MAPSTA=-1)
        -- the south and north rows always, the west and east columns
        whenever the closure is 'NONE', i.e. on every non-cyclic grid
        (w3gridmd.F90, READMP perimeter pass). So an unlisted edge is not an
        ordinary sea point but a closed wall, and with no edges listed WW3
        runs on the grid minus its outer ring of sea cells.

        Either way the domain edge absorbs: coastal reflection is off unless
        REFCOAST is set, so energy propagating into an excluded point or into
        a zero-energy status-2 point is discarded alike. The difference is
        that a status-2 ring keeps the outermost active row on the full
        third-order stencil (w3pro3md requires all neighbours >= 1), and that
        it can be fed spectra via ww3_bounc / nest.ww3. Without nest.ww3 WW3
        warns, sets FLBPI=.FALSE. and leaves the ring at zero energy, so a
        caller that generates spectra for only some edges should list those.

        Parameters
        ----------
        boundary_edges : set of str
            Already validated by _normalize_ww3_boundary_edges. An empty set
            yields a plain land/sea mask with no boundary points; ww3_grid then
            excludes the perimeter sea cells and WW3 runs without open boundary
            forcing.

        Returns
        -------
        numpy.ndarray
            (ny, nx) integer array of WW3 mapsta status codes.
        """
        tmask = self.tmask.data  # (ny, nx), 1=ocean, 0=land
        mapsta = tmask.astype(int)

        # Row j=0 is the southernmost row (the files are written IDLA=1), and
        # column i=0 is the westernmost.
        is_boundary = np.zeros_like(mapsta, dtype=bool)
        if "south" in boundary_edges:
            is_boundary[0, :] = True
        if "north" in boundary_edges:
            is_boundary[-1, :] = True
        if "west" in boundary_edges:
            is_boundary[:, 0] = True
        if "east" in boundary_edges:
            is_boundary[:, -1] = True

        mapsta[is_boundary & (tmask == 1)] = 2
        return mapsta

    def ww3_min_grid_spacing(self):
        """Smallest cell spacing on the grid, in meters."""
        tlon = self._grid.tlon.data
        tlat = self._grid.tlat.data

        # Distances between actual neighbours along i and j. Both coordinates of
        # the second point must come from the neighbour: on a curvilinear grid
        # (e.g. polar stereographic) rows are not parallels and columns are not
        # meridians, so holding lat or lon fixed measures near-zero spurious
        # steps. haversine is periodic in longitude, so dateline crossings need
        # no wrapping.
        dx = haversine(
            tlat[:, :-1], tlon[:, :-1], tlat[:, 1:], tlon[:, 1:], _DEFAULT_RADIUS
        )
        dy = haversine(
            tlat[:-1, :], tlon[:-1, :], tlat[1:, :], tlon[1:, :], _DEFAULT_RADIUS
        )

        spacings = np.concatenate([dx.ravel(), dy.ravel()])
        spacings = spacings[np.isfinite(spacings) & (spacings > 0.0)]
        if spacings.size == 0:
            raise ValueError("Could not determine grid spacing for WW3 time steps.")
        return float(spacings.min())

    def ww3_timesteps(self, cpl_dt=1800.0):
        """WW3 time steps for this grid.

        See :func:`ww3_timesteps_from_spacing` for the CFL reasoning.

        Parameters
        ----------
        cpl_dt: float, optional
            Wave coupling interval in seconds (WAV_NCPL), 1800 s in CESM by
            default. ``dtmax`` is derived from it rather than taken as given.
        """
        return ww3_timesteps_from_spacing(self.ww3_min_grid_spacing(), cpl_dt)

    def write_ww3_input(
        self,
        file_dir,
        grid_alias,
        boundary_edges=None,
        open_boundary=None,
        cpl_dt=1800.0,
    ):
        """
        Write the text-based WW3 input files ww3_grid.inp, [grid_alias]_x.inp, [grid_alias]_y.inp,
        [grid_alias]_mapsta.inp, [grid_alias]_bottom.inp, which are to be read by the WW3
        mod_def creator before runtime to generate the WW3 grid files.

        Parameters
        ----------
        file_dir: str
            Directory to write the WW3 input files to.
        grid_alias: str
            The alias for the grid, which will be used in the file names of the WW3 input files.
        boundary_edges: None, str or iterable of str, optional
            Domain edges whose ocean cells become WW3 active boundary points
            (mapsta status 2): any of "south" (j=0), "north" (j=ny-1), "west"
            (i=0), "east" (i=nx-1). None (default) selects all four edges of a
            non-cyclic (regional) grid and no edge of a cyclic-x grid, so a
            global grid does not declare boundary points it has no data for; a
            zonally periodic band that is open to the south and north lists
            them explicitly. An empty list writes a plain land/sea mask; ww3_grid then excludes
            the perimeter sea cells. Spectral boundary data reach status-2
            points via ww3_bounc / nest.ww3; without it they stay at zero
            energy, so whatever generates the spectra should list the edges it
            covers.
        open_boundary: bool, optional
            Deprecated; use boundary_edges. True is the default edge set,
            False is no edges.
        cpl_dt: float, optional
            Wave coupling interval in seconds (WAV_NCPL), which the time steps
            are derived from. Defaults to the CESM value of 1800 s.

        Raises
        ------
        ValueError
            If boundary_edges names an unknown edge, names the east or west
            edge on a grid that is reentrant in x, or the grid is tripolar
            (the closure written has no 'TRPL' case). Raised before anything
            is written.
        """

        assert (
            "degrees" in self._grid.tlat.units and "degrees" in self._grid.tlon.units
        ), "Unsupported coord"
        if open_boundary is not None:
            warnings.warn(
                "open_boundary is deprecated; use boundary_edges.",
                DeprecationWarning,
                stacklevel=2,
            )
            if boundary_edges is not None:
                raise ValueError(
                    "Pass either boundary_edges or open_boundary, not both."
                )
            boundary_edges = None if open_boundary else ()
        # The closure written below has no 'TRPL' case, so a pole fold would be
        # written out as though it were an ordinary grid edge.
        if self._grid.supergrid.is_tripolar:
            raise ValueError("write_ww3_input does not support tripolar grids.")
        # Validate before creating the directory or writing any file.
        boundary_edges = self._normalize_ww3_boundary_edges(boundary_edges)

        file_dir = Path(file_dir)
        file_dir.mkdir(parents=True, exist_ok=True)

        nx = self._grid.nx
        ny = self._grid.ny

        def _write_rows(filename, fmt_cell, sep):
            """Write the nx*ny grid values to a WW3 text input file, southernmost
            row (j=0) first to match IDLA=1 in ww3_grid.inp."""
            with open(file_dir / filename, "w") as f:
                for j in range(ny):
                    f.write(sep.join(fmt_cell(j, i) for i in range(nx)) + "\n")

        tlon = self._grid.tlon.data  # (ny, nx), degrees
        tlat = self._grid.tlat.data  # (ny, nx), degrees
        # Define ocean cells from the land/sea mask so the depth and status files
        # stay consistent even if the mask has been edited.
        tmask = self.tmask.data  # (ny, nx), 1=ocean, 0=land
        depth_m = self.masked_depth.data

        x_file = f"{grid_alias}_x.inp"
        y_file = f"{grid_alias}_y.inp"
        bottom_file = f"{grid_alias}_bottom.inp"
        mapsta_file = f"{grid_alias}_mapsta.inp"

        # --- x/y coordinate files (longitudes/latitudes in degrees) ---
        _write_rows(x_file, lambda j, i: f"{tlon[j, i]:15.8f}", sep="")
        _write_rows(y_file, lambda j, i: f"{tlat[j, i]:15.8f}", sep="")

        # --- bottom depth file (positive depth in meters for ocean) ---
        # WW3 stores seabed as elevation ZB (negative-down); DW = WLV - ZB.
        # The preprocessor computes ZBIN = SBF * file_values, then flags a
        # cell as sea when ZBIN <= ZLIM. We write positive depths in meters
        # and set SBF=-1.0 in ww3_grid.inp so ZBIN comes out as the correct
        # negative-down elevation. Matches the convention in WW3 regtest
        # ww3_tp2.5 (regtests/ww3_tp2.5/input/depth.361x361.IDLA1.dat).
        _write_rows(bottom_file, lambda j, i: f"{depth_m[j, i]:.8f}", sep=" ")

        # --- map status file (0=land, 1=interior sea, 2=active boundary) ---
        mapsta = self._compute_ww3_mapsta(boundary_edges)
        _write_rows(mapsta_file, lambda j, i: str(int(mapsta[j, i])), sep=" ")

        # --- Write ww3_grid.inp ---
        # Use IDLA=1 (bottom-to-top) and IDFM=1 (free format) to match the
        # row ordering used above (j=0 is the southernmost row).
        with open(file_dir / "ww3_grid.inp", "w") as f:
            f.write(
                "$ -------------------------------------------------------------------- $\n"
                "$ WAVEWATCH III Grid preprocessor input file                           $\n"
                "$ -------------------------------------------------------------------- $\n"
                "$\n"
                "$ Grid name (C*30, in quotes)\n"
                "$\n"
            )
            grid_name = grid_alias.ljust(30)[:30]
            f.write(f"  '{grid_name}'\n")
            nk = WW3_NK  # number of frequencies (wavenumbers)
            nth = WW3_NTH  # number of directions
            dt = self.ww3_timesteps(cpl_dt)
            stk_wn = ", ".join(f"{k}" for k in WW3_STOKES_WAVENUMBERS)
            f.write(
                "$\n"
                "$ Frequency increment factor and first frequency (Hz) ---------------- $\n"
                "$ number of frequencies (wavenumbers) and directions, relative offset\n"
                "$ of first direction in terms of the directional increment [-0.5,0.5].\n"
                "$\n"
                f"  {WW3_FREQ_FACTOR}  {WW3_F1}  {nk}  {nth}  0.0\n"
                "$\n"
                "$ Set model flags ---------------------------------------------------- $\n"
                "$  - FLDRY         Dry run (input/output only, no calculation).\n"
                "$  - FLCX, FLCY    Activate X and Y component of propagation.\n"
                "$  - FLCTH, FLCK   Activate direction and wavenumber shifts.\n"
                "$  - FLSOU         Activate source terms.\n"
                "  F  T  T  T  F  T \n"
                "$\n"
                "$ Set time steps ----------------------------------------------------- $\n"
                "$ - Time step information (this information is always read)\n"
                "$     maximum global time step, maximum CFL time step for x-y and\n"
                "$     k-theta, minimum source term time step (all in seconds).\n"
                "$\n"
                f"  {dt['dtmax']:.2f}  {dt['dtcfl']:.2f}  {dt['dtcfli']:.2f}  {dt['dtmin']:.2f}\n"
                "$\n"
                "$ Start of namelist input section ------------------------------------ $\n"
                "$\n"
                "$ Gridded output selection ------------------------------------------- $\n"
                "$  - E3D          1-D frequency spectrum over bins I1E3D..I2E3D.\n"
                "$  - USSP/IUSSP   Export the surface Stokes drift split into this many\n"
                "$                 bands. MOM6 reads them when WAVE_METHOD is\n"
                "$                 SURFACE_BANDS; the legacy EFACTOR method ignores them.\n"
                "$  - STK_WN       Central wavenumbers of those bands. These must match\n"
                "$                 MOM6's SURFBAND_WAVENUMBERS.\n"
                "$  - STK_TAIL     Fold the high-frequency tail into the last band.\n"
                "$\n"
                "&OUTS\n"
                f"  E3D = 1, I1E3D = 1, I2E3D = {nk}\n"
                f"  USSP = 1, IUSSP = {len(WW3_STOKES_WAVENUMBERS)}, STK_TAIL = T\n"
                f"  STK_WN = {stk_wn}\n"
                "/\n"
                "$\n"
                "$ Li et al. (2016) Langmuir mixing parameterization ------------------- $\n"
                "$  - LMPENABLED    Accumulate the surface-layer averaged Stokes drift\n"
                "$                  (USSHX/USSHY), and with it the Langmuir multiplier\n"
                "$                  Sw_lamult, which stays 1 everywhere without it. Only\n"
                "$                  the legacy EFACTOR coupling reads Sw_lamult; under\n"
                "$                  SURFACE_BANDS MOM6 gets the Langmuir number from the\n"
                "$                  Stokes bands instead.\n"
                "$  - SDTAIL        Include the high-frequency tail in the Stokes drift.\n"
                "$  - HSLMODE       1 = surface layer depth from the coupler boundary\n"
                "$                  layer depth; 0 = constant 10 m (testing only).\n"
                "$\n"
                "&LMPN\n"
                "  LMPENABLED = T, SDTAIL = T, HSLMODE = 1\n"
                "/\n"
                "$\n"
                "$ Sea-ice dissipation, as in CESM's own WW3 grids -------------------- $\n"
                "$  - IC4METHOD     10 = Meylan, Horvat & Bitz (2021) fit in ice\n"
                "$                  thickness and floe size, floored at 0.1 m and a\n"
                "$                  2.5 m floe radius, so ice without them (DICE)\n"
                "$                  still dissipates. The default, 1, is an empirical\n"
                "$                  fit whose first coefficient the CESM cap fills\n"
                "$                  with the ice thickness.\n"
                "$  - ICNUMERICS    Add the ice term to the other source terms,\n"
                "$                  scaled by ice concentration.\n"
                "$\n"
                "&SIC4\n"
                f"  IC4METHOD = {WW3_IC4_METHOD}\n"
                "/\n"
                "&MISC\n"
                "  ICNUMERICS = T\n"
                "/\n"
                "\n"
                "END OF NAMELISTS\n"
                "$\n"
                "$ Define grid -------------------------------------------------------- $\n"
                "$\n"
            )
            closure = "SMPL" if self._grid.supergrid.is_cyclic_x else "NONE"
            f.write(f"  'CURV'  T  '{closure}'\n")
            f.write(f"  {nx}  {ny}\n")
            f.write(f"  21 1.0 0.0 1 1 '(....)' 'NAME' '{x_file}'\n")
            f.write(f"  22 1.0 0.0 1 1 '(....)' 'NAME' '{y_file}'\n")
            f.write(
                f"  -0.1 {self._min_depth:.2f} 23 -1. 1 1 '(....)' 'NAME' '{bottom_file}'\n"
            )
            f.write(f"  24 1 1 '(....)' 'NAME' '{mapsta_file}'\n")
            f.write(
                "$\n"
                "$  Close list by defining line with 0 points (mandatory)\n"
                "$\n"
                "    0.  0.  0.  0.  0  \n"
                "$ -------------------------------------------------------------------- $\n"
                "$ End of input file                                                    $\n"
                "$ -------------------------------------------------------------------- $\n"
            )

    def write_scrip_grid_file(self, file_path, title=None):
        """
        Write the SCRIP grid file. In latest CESM versions, SCRIP grid files are
        no longer required and are replaced by ESMF mesh files. However, SCRIP
        files are still needed to generate custom ocean-runoff mapping files.

        Parameters
        ----------
        file_path: str
            Path to SCRIP file to be written.
        title: str, optional
            File title.

        Returns
        -------
        xr.Dataset
            The SCRIP grid dataset written to ``file_path``.
        """

        ds = xr.Dataset()

        # global attrs:
        ds.attrs["Conventions"] = "SCRIP"
        ds.attrs["date_created"] = datetime.now().isoformat()
        if title:
            ds.attrs["title"] = title

        ds["grid_dims"] = xr.DataArray(
            np.array([self._grid.nx, self._grid.ny]).astype(np.int32),
            dims=["grid_rank"],
        )
        ds["grid_center_lat"] = xr.DataArray(
            self._grid.tlat.data.flatten(),
            dims=["grid_size"],
            attrs={"units": self._grid.supergrid.axis_units},
        )
        ds["grid_center_lon"] = xr.DataArray(
            self._grid.tlon.data.flatten(),
            dims=["grid_size"],
            attrs={"units": self._grid.supergrid.axis_units},
        )
        ds["grid_imask"] = xr.DataArray(
            self.tmask.data.astype(np.int32).flatten(),
            dims=["grid_size"],
            attrs={"units": "unitless"},
        )

        ds["grid_corner_lat"] = xr.DataArray(
            np.zeros((ds.sizes["grid_size"], 4)),
            dims=["grid_size", "grid_corners"],
            attrs={"units": self._grid.supergrid.axis_units},
        )
        ds["grid_corner_lon"] = xr.DataArray(
            np.zeros((ds.sizes["grid_size"], 4)),
            dims=["grid_size", "grid_corners"],
            attrs={"units": self._grid.supergrid.axis_units},
        )

        i_range = range(self._grid.nx)
        j_range = range(self._grid.ny)
        j, i = np.meshgrid(j_range, i_range, indexing="ij")
        k = j * self._grid.nx + i

        ds["grid_corner_lat"].data[k] = np.stack(
            (
                self._grid.qlat.data[j, i],
                self._grid.qlat.data[j, i + 1],
                self._grid.qlat.data[j + 1, i + 1],
                self._grid.qlat.data[j + 1, i],
            ),
            axis=-1,
        )

        ds["grid_corner_lon"].data[k] = np.stack(
            (
                self._grid.qlon.data[j, i],
                self._grid.qlon.data[j, i + 1],
                self._grid.qlon.data[j + 1, i + 1],
                self._grid.qlon.data[j + 1, i],
            ),
            axis=-1,
        )

        ds["grid_area"] = xr.DataArray(
            cell_area_rad(ds.grid_corner_lon.data, ds.grid_corner_lat.data),
            dims=["grid_size"],
            attrs={"units": "radians^2"},
        )

        ds.to_netcdf(
            file_path,
            format="NETCDF3_64BIT",
        )
        return ds

    def write_esmf_mesh_file(self, file_path, title=None):
        """
        Write the ESMF mesh file

        Parameters
        ----------
        file_path: str
            Path to ESMF mesh file to be written.
        title: str, optional
            File title.

        Returns
        -------
        xr.Dataset
            The ESMF mesh dataset written to ``file_path``.
        """

        ds = self._grid.supergrid.to_esmf_mesh(
            file_path, mask=self.tmask.data, title=title
        )
        self.mesh_path = file_path
        return ds

    # Deprecated names, kept for one release.
    @classmethod
    def from_esmf_mesh(
        cls,
        mesh_path,
        radius=_DEFAULT_RADIUS,
        min_depth=0.0,
        version_control_dir="TopoLibrary",
        git=False,
    ):
        """Deprecated alias for :meth:`from_esmf_mesh_file`."""
        warnings.warn(
            "Topo.from_esmf_mesh() is deprecated; use Topo.from_esmf_mesh_file(). "
            "It will be removed in a future release.",
            DeprecationWarning,
            stacklevel=2,
        )
        return cls.from_esmf_mesh_file(
            mesh_path, radius, min_depth, version_control_dir, git
        )

    def write_topo(self, file_path, title=None):
        """Deprecated alias for :meth:`write_topo_file`."""
        warnings.warn(
            "Topo.write_topo() is deprecated; use Topo.write_topo_file(). "
            "It will be removed in a future release.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.write_topo_file(file_path, title)

    def write_cice_grid(self, file_path):
        """Deprecated alias for :meth:`write_cice_grid_file`."""
        warnings.warn(
            "Topo.write_cice_grid() is deprecated; use Topo.write_cice_grid_file(). "
            "It will be removed in a future release.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.write_cice_grid_file(file_path)

    def write_scrip_grid(self, file_path, title=None):
        """Deprecated alias for :meth:`write_scrip_grid_file`."""
        warnings.warn(
            "Topo.write_scrip_grid() is deprecated; use Topo.write_scrip_grid_file(). "
            "It will be removed in a future release.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.write_scrip_grid_file(file_path, title)

    def write_esmf_mesh(self, file_path, title=None):
        """Deprecated alias for :meth:`write_esmf_mesh_file`."""
        warnings.warn(
            "Topo.write_esmf_mesh() is deprecated; use Topo.write_esmf_mesh_file(). "
            "It will be removed in a future release.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.write_esmf_mesh_file(file_path, title)
